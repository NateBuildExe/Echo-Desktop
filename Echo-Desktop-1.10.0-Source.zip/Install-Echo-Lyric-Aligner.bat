@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Echo - Local Lyric Alignment Setup

set "LOG_FILE=%~dp0Echo-Lyric-Aligner-Setup.log"
set "VENV_DIR=%~dp0.echo-lyric-venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"
set "PY_LAUNCHER="
set "PY_SELECTOR="
set "RESULT=1"

>"%LOG_FILE%" echo Echo local lyric alignment setup log
>>"%LOG_FILE%" echo Started: %DATE% %TIME%

echo.
echo  ECHO LOCAL LYRIC ALIGNMENT SETUP
echo  =================================
echo.
echo This installs Echo's optional local lyric-alignment engine.
echo It aligns lyric text you already have; it does not create missing lyrics.
echo Audio stays on this PC.
echo.
echo Setup log: "%LOG_FILE%"
echo.

where py >nul 2>nul
if not errorlevel 1 (
    set "PY_LAUNCHER=py"
    goto :find_launcher_python
)
where python >nul 2>nul
if not errorlevel 1 (
    set "PY_LAUNCHER=python"
    goto :find_direct_python
)
echo ERROR: Python was not found.
echo Install 64-bit Python from python.org, including the Python Launcher, then run this file again.
>>"%LOG_FILE%" echo ERROR: Python command was not found.
goto :failed

:find_launcher_python
echo [1/4] Looking for a supported 64-bit Python installation...
for %%V in (3.14 3.13 3.12 3.11 3.15 3.10 3.9) do (
    py -%%V -c "import sys,struct; raise SystemExit(0 if (sys.version_info >= (3,9) and sys.version_info < (3,16) and struct.calcsize('P') == 8) else 1)" >nul 2>nul
    if not errorlevel 1 if not defined PY_SELECTOR set "PY_SELECTOR=-%%V"
)
if not defined PY_SELECTOR (
    echo ERROR: No usable 64-bit Python 3.9-3.15 was found through the Python Launcher.
    >>"%LOG_FILE%" echo ERROR: No usable 64-bit Python 3.9-3.15 was found through py.exe.
    goto :failed
)
goto :python_selected

:find_direct_python
echo [1/4] Checking the Python command...
python -c "import sys,struct; raise SystemExit(0 if (sys.version_info >= (3,9) and sys.version_info < (3,16) and struct.calcsize('P') == 8) else 1)" >nul 2>nul
if errorlevel 1 (
    echo ERROR: The default Python is not supported or is not 64-bit.
    >>"%LOG_FILE%" echo ERROR: Direct python command is not supported or is not 64-bit.
    goto :failed
)

:python_selected
echo [2/4] Creating Echo's private Python environment...
echo Using: %PY_LAUNCHER% %PY_SELECTOR%
>>"%LOG_FILE%" echo Selected Python command: %PY_LAUNCHER% %PY_SELECTOR%
"%PY_LAUNCHER%" %PY_SELECTOR% -m venv "%VENV_DIR%" >>"%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo ERROR: Could not create Echo's Python environment.
    goto :show_log_failed
)
if not exist "%VENV_PY%" (
    echo ERROR: Python environment creation did not produce python.exe.
    goto :show_log_failed
)

echo [3/4] Installing lyric-align and faster-whisper...
echo This can take several minutes and needs an internet connection.
echo The progress and any errors will be saved in the setup log.
"%VENV_PY%" -m pip install --upgrade pip >>"%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo ERROR: Could not update pip.
    goto :show_log_failed
)
"%VENV_PY%" -m pip install --upgrade "lyric-align[asr]==0.4.2" "faster-whisper" >>"%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo ERROR: The lyric-alignment packages could not be installed.
    goto :show_log_failed
)

echo [4/4] Verifying the exact Python environment Echo will use...
"%VENV_PY%" -c "import sys; import faster_whisper; import lyric_align; print('Python:', sys.version); print('faster-whisper:', faster_whisper.__file__); print('lyric-align:', lyric_align.__file__)" >>"%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo ERROR: The packages were downloaded but could not be imported.
    goto :show_log_failed
)

echo.
echo SUCCESS: Echo's local lyric aligner is installed and verified.
echo Close and reopen Echo Desktop before using Align timestamps.
echo The first alignment run downloads the selected Whisper model once.
echo Your Python environment is stored in: .echo-lyric-venv
echo.
>>"%LOG_FILE%" echo Setup completed successfully: %DATE% %TIME%
set "RESULT=0"
goto :finish

:show_log_failed
echo.
echo ----- Setup log details -----
type "%LOG_FILE%"
echo ----- End of log details -----
>>"%LOG_FILE%" echo Setup failed: %DATE% %TIME%
goto :failed

:failed
echo.
echo SETUP FAILED. Echo's lyric aligner has NOT been installed.
echo Keep this window open and share the log if you need help:
echo "%LOG_FILE%"
set "RESULT=1"

:finish
echo.
echo Press any key to close this setup window.
pause >nul
endlocal & exit /b %RESULT%
