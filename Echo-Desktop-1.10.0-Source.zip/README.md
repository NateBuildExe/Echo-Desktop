# Echo Desktop 1.10.0

A dark, offline-first desktop music player for a personal local music library. Echo is an offline-first local music player with online metadata and lyrics lookup. The YouTube Music experiment remains removed.

## What's new in 1.10.0

- Fixes the lyric-align installer by creating a private `.echo-lyric-venv`, explicitly installing and verifying `faster-whisper` and `lyric-align`, and making Echo use that exact Python interpreter. The installer keeps its window open, reports failures, and writes `Echo-Lyric-Aligner-Setup.log`.
- Adds optional local lyric timestamp alignment for lyric text already available from a provider or supplied by the user. The bundled Python runner uses `faster-whisper` for audio word timing and `lyric-align` to match the known lines.
- Auto language mode uses Whisper's language detection; explicit English, Hindi, Urdu, and Punjabi choices are also available. Tiny is the faster model; Base is a slower alternative that may match better on some recordings.
- Automatically retries without voice-activity filtering when sustained singing is poorly detected. Unmatched lines remain untimed text instead of being assigned invented times or removed.
- Adds a live lyric-alignment progress bar that reports model loading, audio scanning, lyric matching, and matched-line totals.
- Hides the full-screen lyrics scrollbar by clipping its track outside the viewport without disabling mouse-wheel, touchpad, or touch scrolling.
- SoundCloud keyword search is not yet included: its official search API requires registered app credentials; oEmbed only resolves a URL already known to the app.
- This tool aligns existing lyrics; it does not generate missing copyrighted song lyrics from commercial recordings. Audio remains on the local PC.

- Fixes the Search view's no-results failure caused by an undefined query variable, binds directly to the global search field, and supports multi-word, accent-insensitive matching across title, artist, album, genre, album artist, and filename. Devanagari song metadata also gets a Hinglish search alias where transliteration is available.
- Prepares one shuffled listening order and uses it consistently for Next, Previous, and the queue panel. Previous now returns to the prior queue item even after the current track has played for more than three seconds.
- Adds a lyric timing correction tool per track: a millisecond offset for globally early/late lyrics and a timing-rate adjustment for gradual drift. The saved lyric text and original LRC timestamps remain intact; reset timing is available.
- Makes full-screen lyrics scroll independently from top to bottom, pauses auto-follow when the user scrolls, and allows clicking a timestamped lyric line to seek directly to that point.
- Keeps the full-screen lyrics timeline synchronized with the player and adds an accessible Show/Hide timeline toggle.
- Makes the track thumbnail play button the only playback target in song rows; clicking titles, metadata, or blank row space no longer starts playback. Clicking the current track's thumbnail toggles pause/resume without rebuilding a shuffled queue.
- Widens the metadata editor and accepts a longer alternate-query field. Catalog search now always includes title-only MusicBrainz lookups for the main and alternate title, and checks the US Apple/iTunes storefront in addition to the India storefront.
- Fixes the non-opening artwork fullscreen action by handling clicks on the permanent Now Playing artwork container in the capture phase, rather than relying on an individual replaceable image button. The fullscreen view now renders inside a dedicated fixed, top-level overlay layer.
- Keeps the blurred visualizer layer visible behind the artwork and shows ambient motion while paused; live audio uses the Web Audio analyser where available.
- Displays Devanagari Hindi lyrics in Roman Hinglish by default, with a Settings toggle. The original lyrics and LRC timestamps remain unchanged.
- Adds multi-provider synced lyrics lookup: YouLy+ / LyricsPlus (aggregated lyric sources), KuGou line-synced lyrics through the Better Lyrics API, and LRCLIB fallback. Results identify their provider and synchronization level, and are ranked by timing detail before you choose one.
- Uses responsive playlist columns so duration and row actions no longer overlap.
- Moves Settings directly beneath Home, Search, and Your Library.
- Adds a visible progress message while importing files or folders, plus a final summary of tracks added, duplicates skipped, and failures.
- Protects imports from hanging indefinitely while probing unusual or damaged audio files.
- Improves duplicate detection for newly imported files by including last-modified information when available.
- Adds keyboard shortcuts and documents them in Settings: Space, Left/Right, Ctrl+O, Ctrl+L, Ctrl+Q, and Escape.
- Remembers a sort order chosen directly in Your Library as the next default.
- Shows an approximate on-device storage usage figure and track count in Settings when supported by Chromium.
- Disables the Now Playing Like action when no track is loaded.

- Corrects home-page spacing so the hero content has consistent breathing room and the import button no longer sits against the lower edge.
- Adds a dedicated Settings entry in the left navigation. Settings include Midnight/AMOLED themes, four accent colours, artwork visualizer controls, default library sorting, and a remember-volume preference. Preferences are saved locally in the existing settings store.
- Adds a compact rounded seek/timeline control and play/pause button to full-screen artwork; the timeline stays synchronized with the regular player.
- Adds an actual Web Audio frequency visualizer behind the artwork, positioned along the bottom and softly blurred. The visualizer supports spectrum bars or a wave-style line, an enable switch, and glow strength. It responds to local audio only and does not upload audio.

- Improves metadata retrieval by separating MusicBrainz recording searches from the detailed recording lookups that provide releases, genres, tags, and artwork references.
- Adds an Apple/iTunes Search API fallback and combines matching results from both catalogs when available.
- Fetches artwork from a selected MusicBrainz release or a valid Apple catalog artwork URL. Artwork is staged in the editor until Save changes is pressed.
- Improves service error reporting so an unavailable catalog is not silently presented as a simple no-match result.
- Gives the right-side synced-lyrics panel a longer reading area and larger active-line styling.
- Adds a full-screen artwork view from the Now Playing artwork panel.
- Adds a full-screen lyrics view with the active synchronized lyric centred and updated during playback. The LYR player button also opens this view.
- Replaces queue Move Up buttons with a draggable grip and visible drop indicators. Reordering does not restart the currently playing track.
- Keeps the existing library database name, schema version, stable local origin, and Electron version unchanged.

## Metadata and artwork

1. Import a song as usual. Echo does not automatically contact the internet.
2. Open the track's **Edit** panel and choose **Fetch metadata online**.
3. Echo searches MusicBrainz and the Apple/iTunes catalog using the title, artist, and any alternate queries you add in the expanded search field. SoundCloud is not included until official API credentials are available; the public oEmbed endpoint is not a track-search API.
4. MusicBrainz recording summaries are enriched with a separate recording lookup to obtain linked releases and additional metadata. Echo also runs title-only searches for the main and first alternate title. Apple/iTunes searches the India and US storefronts and checks the alternate query where supplied.
5. Choose the correct candidate. Echo stages the matching title, artist, album, year, available genre, and artwork.
6. Review the fields and press **Save changes** to store them in your local library.

MusicBrainz documents search and entity lookup as separate Web Service operations. Its API is throttled by Echo to respect the service's request-rate guidance. The Apple/iTunes Search API provides catalog search results including track, artist, collection, release-date, genre, and artwork fields. These catalogs will not have every song, and matches should be checked before saving.

- [MusicBrainz Web Service](https://musicbrainz.org/doc/MusicBrainz_API)
- [MusicBrainz Search](https://musicbrainz.org/doc/MusicBrainz_API/Search)
- [Apple iTunes Search API](https://performance-partners.apple.com/search-api)
- [Cover Art Archive](https://musicbrainz.org/doc/Cover_Art_Archive/API)

## Lyrics

1. In the Edit panel, choose **Fetch lyrics online**.
2. Select the correct result. Prefer timestamped lyrics when available.
3. Review the lyrics in the editor and press **Save changes**.
4. You can still import `.lrc` / `.txt` files or paste/write lyrics manually.

The right-side lyrics display now has more vertical room. Use the expand icon beside **LYRICS**, or the **LYR** button in the bottom player, to open full-screen lyrics. The current synchronized line stays centred while the song plays. You can scroll from the first line to the last, pause automatic follow while browsing, and click a timestamped line to jump to it. The rounded timeline at the bottom can be hidden or shown from the top control.

Hindi text is transliterated to Hinglish for display by default, with a switch in Settings. This is a best-effort phonetic conversion; unusual names and poetic/slang spellings may need manual review. The original lyric text and LRC timestamps are preserved. Only timestamped LRC lines can follow playback; plain text cannot be synchronized without added timing. In a track's Edit panel, Timing offset shifts all lines earlier or later, while Timing drift / speed corrects gradual timing drift through a recording. Reset timing returns both controls to their defaults. Irregular errors in individual lines still require choosing another LRC version or editing those timestamps manually.

Echo searches three lyric sources when you press **Fetch lyrics online**:

- **YouLy+ / LyricsPlus backend** — an aggregated source that can return structured timed lines, including word/syllable timing data where available. Echo uses the documented `/v2/lyrics/get` endpoint on the primary `lyricsplus.prjktla.my.id` host, then tries the documented/published mirrors `lyricsplus.binimum.org`, `lyricsplus-seven.vercel.app`, and `lyricsplus.prjktla.workers.dev` if necessary.
- **KuGou** — queried through the Better Lyrics API's documented `/kugou/getLyrics` route. It provides line-synced LRC-style lyrics and is used as an independent fallback.
- **LRCLIB** — the existing crowdsourced source remains available for synced or plain-text alternatives.

Echo shows the provider name and timing type on each candidate so you can compare results before applying them. LyricsPlus word/syllable data is currently normalized to line-start timestamps in Echo; the player does not yet animate each word individually. The LyricsPlus query uses the published source preference order and duration in seconds; its KPOE line/word timestamps are interpreted as milliseconds. The sources may return no result, a cached result, or a different version (live/remaster/radio edit), so check the duration and match before saving. Public endpoints may be temporarily unavailable or rate-limited.

Provider documentation: [YouLy+](https://github.com/ibratabian17/YouLyPlus), [LyricsPlus backend API](https://github.com/ibratabian17/lyricsplus), [Better Lyrics providers](https://lyrics-api-docs.boidu.dev/docs/providers), [Better Lyrics KuGou endpoint](https://lyrics-api-docs.boidu.dev/reference/get-lyrics), and [LRCLIB API](https://lrclib.net/docs).

Lyrics are supplied by third-party services and remain subject to their respective terms and rights holders. Echo does not grant rights to redistribute lyric text.

## Full-screen artwork and queue

- Click the Now Playing artwork or its Expand control to open the artwork view. The artwork uses a normal pointer cursor, and the overlay is mounted in a dedicated top-level fixed layer. The view includes a floating rounded timeline, elapsed/total time, play/pause control, and a blurred audio-reactive visualizer near the bottom. Close it with the X button or Escape.
- Use the Settings entry in the left navigation to switch between Midnight and AMOLED themes, choose the accent colour, configure the visualizer, set the default library sort, and remember the playback volume. These preferences are stored locally.
- Open the queue using the list icon in the player. Grab the dotted handle beside a song and drag it above or below another song to change the order.
- Queue reordering changes the listening order without restarting the current track. When shuffle is enabled, the one prepared shuffled order is what the queue panel displays and what Next/Previous follow.

## What is sent online

Echo sends only the text metadata needed for lookup: song title and artist for metadata search; title, artist, album, and duration for lyrics search. It does **not** upload the audio file or generate an audio fingerprint. When fetching album artwork, Echo downloads the selected image from the catalog source. Metadata and lyrics are separate actions: fetching metadata never changes lyrics, and fetching lyrics never changes metadata. Nothing is committed until you save the edit form.

## Install on Windows 10/11

### First install

1. Extract `Echo-Desktop-1.10.0-Source.zip` to a normal folder, such as `Documents\Echo Desktop`. Do not run it from inside the ZIP viewer.
2. Install **Node.js 22 LTS or newer** from [nodejs.org](https://nodejs.org/). The installer includes npm.
3. Connect to the internet for first-time setup; npm downloads the pinned Electron runtime.
4. Double-click `Start-Echo-Desktop.bat` in the extracted folder.
5. Echo opens after setup completes.

### Update from 1.9.8 or earlier source builds

1. Close Echo Desktop.
2. Make a backup copy of the entire existing Echo project folder.
3. Extract the 1.10.0 source ZIP over the existing project folder and allow updated files to replace their older copies.
4. **Keep the existing `node_modules` folder.** Electron remains pinned to 45.3.2, so the existing runtime should not need to be downloaded again.
5. Run `Start-Echo-Desktop.bat`.

The local library continues to use `http://127.0.0.1:43127`, the same IndexedDB database name, and schema version 2. Do not clear Echo's app/site data. Your imported songs, playlists, artwork, and lyrics remain in the same local database.

### Later launches

Double-click `Start-Echo-Desktop.bat`. Local playback and previously saved metadata, artwork, and lyrics work offline. Online metadata and lyrics lookup need an internet connection and run only when you press their respective buttons.

## Local music features

- Use **Import music** to select one or many audio files.
- Use **Import folder** in Your Library to add a whole folder.
- In Your Library, choose **Select songs** to select multiple tracks, add them to a playlist together, or remove several stored Echo copies together.
- Use **Sort by** to switch between Date added (newest first), A–Z, and Most played.
- Edit a track to update title, artist, album, album artist, release year, genre, or artwork.
- Fetch metadata and artwork online, or upload artwork manually.
- Fetch lyrics online, import `.lrc` / `.txt`, or paste/write lyrics.
- Timed `.lrc` lines synchronize during local playback and can be viewed in full screen.
- Create playlists, like tracks, and use the local queue, drag-to-reorder, shuffle, repeat, previous/next, seek, and volume controls.

Imported audio and metadata are stored in the current Windows user's local Chromium IndexedDB database. Keep a separate backup of original audio files.

## Tests

With Node.js installed, open a terminal in the project folder and run:

```powershell
npm test
```

The smoke checks use mocked service responses to validate MusicBrainz and Apple/iTunes lookup, lyrics providers, streamed lyric-alignment progress IPC, the full-screen lyrics scroll clipping, full-screen artwork, queue drag-and-drop handlers, Settings, the visualizer/timeline, the local asset server, Content Security Policy, and Electron security settings. They do not make live catalogue requests or replace testing on the actual Windows PC. They do not make live catalog requests or replace testing on the actual Windows PC.

## Troubleshooting

- **`node` or `npm` is not recognized:** Install Node.js 22 LTS or newer, then reopen the terminal.
- **First-time setup fails:** Check internet access and run `Start-Echo-Desktop.bat` again.
- **No metadata results:** Check the title and artist spelling. Try a shorter title. MusicBrainz and the Apple/iTunes catalog do not contain every recording.
- **Artwork not found:** The selected catalog result may not have an available image. Upload artwork manually instead.
- **No lyrics results:** Check the selected title/artist/album. Echo queries YouLy+ / LyricsPlus, KuGou, and LRCLIB, but catalog coverage and service availability vary. Try another spelling, album, or version.
- **Alignment seems stuck:** The status text identifies the current phase. The first model load may take longer because it downloads the selected local model; audio scanning then advances the progress percentage.
- **Lyrics appear out of sync:** Choose the correct timestamped version and check its duration. Use Timing offset for a constant delay, or Timing drift / speed when the error gradually grows through the song. For isolated bad lines, edit the timestamps or choose another `.lrc` version.
- **Metadata or lyrics search fails:** Check your internet connection. Public services may temporarily rate-limit requests; wait before trying again.
- **Queue drag does not start:** Grab the dotted handle at the left edge of a queue row and drag it onto another row.
- **Echo reports port 43127 is in use:** Close another Echo instance or the application using that port.
- **Local track will not play:** Try MP3, M4A/AAC, WAV, OGG/Opus, or FLAC; codec support can vary.
- **Library appears empty after updating:** Confirm you launched under the same Windows user account and did not clear Chromium site data. The library remains under the same stable local origin.

## Security and privacy

- Echo's UI is served by a loopback-only local HTTP server; it is not exposed to your local network.
- Electron uses context isolation, disables Node integration in the renderer, and enables the renderer sandbox.
- The renderer can invoke only three narrowly-scoped lookup operations through IPC: metadata search, selected artwork retrieval, and lyrics search.
- Network requests run in the Electron main process. The renderer's Content Security Policy does not permit remote scripts, frames, or direct external connections.
- This is a personal desktop project, not an official MusicBrainz, Apple, Cover Art Archive, YouLy+, LyricsPlus, KuGou, Better Lyrics, or LRCLIB application.

## Project notes

- This ZIP contains source code, not a compiled or signed Windows `.exe` installer.
- Electron remains pinned to 45.3.2 to allow reuse of an existing `node_modules` installation.


## Echo 1.9.7 patch

Lyrics lookup now combines YouLy+ / LyricsPlus, KuGou (through Better Lyrics), and LRCLIB. Results are normalized into Echo candidates with provider labels and sync quality ranking. LyricsPlus word/syllable data is imported at line-start level; individual word highlighting is not implemented yet.

The Now Playing cover itself is now a button that opens full-screen artwork (including a fallback when artwork is missing). Full-screen artwork includes an explicit Visualizer On/Off control. The visualizer reinitialises its Web Audio analyser when needed, follows live audio while playing, and displays an ambient preview while paused or when Web Audio analysis is unavailable.


### Keyboard shortcuts and import feedback

- **Space:** play/pause (when focus is not on a control or text field).
- **Left / Right:** seek backward/forward by five seconds.
- **Ctrl + O:** import songs.
- **Ctrl + L:** open Search and focus the library search field.
- **Ctrl + Q:** open the queue.
- **Esc:** close an open dialog or full-screen view.
- Multi-file and folder imports show progress and a final added/duplicate/failed summary. Metadata probing has a timeout so a damaged file cannot stall the import operation indefinitely.
- Choosing a sort order in Your Library now saves that choice as the default.

### Final pre-test notes

This is a source update, not the final Windows installer. Keep `node_modules` when updating. The automated test suite checks source wiring and mocked online responses; it cannot validate the native Windows file picker, audio codec support, or actual artwork rendering on the target computer.


### Storage awareness

Settings shows an estimate of local browser storage used by Echo when the Chromium Storage API is available, along with the imported track count. The estimate can include other data stored for the same app origin; it is a guide, not a per-track accounting report. Keep original audio files backed up separately.


### Search, queue, lyrics and row playback

- Search reacts directly to typing and Enter. It matches all query words across local metadata and filenames, including transliterated aliases when available.
- Shuffle prepares a single ordered queue for the session; Queue, Next, and Previous all use that same list. Previous follows the queue rather than restarting the current track after three seconds.
- Full-screen lyrics can be scrolled manually from the opening to closing lines. Manual scrolling temporarily disables Follow active. Clicking a timed line seeks playback to that line.
- The lyrics timeline is independently showable/hideable. Per-track timing controls support a constant offset and gradual drift-rate correction; neither rewrites the original LRC text or timestamps.
- In library and playlist song lists, only the thumbnail play button starts or pauses a track. Song titles and row whitespace are not playback controls.
- Metadata lookup includes more title-only catalogue searches and always adds the US storefront check; the alternate query can include up to 500 characters of alternate spellings, translations, featured artists, or release names.


## Local lyric-align setup fix (1.10.0)

Run `Install-Echo-Lyric-Aligner.bat` from the Echo folder once. It selects a 64-bit Python 3.9–3.15 installation (preferring the documented 3.14, 3.13, 3.12, or 3.11 versions; it attempts 3.15 when those are unavailable), creates `.echo-lyric-venv`, installs `lyric-align[asr]` and `faster-whisper`, and tests the imports using the exact Python executable Echo will launch. The installer writes `Echo-Lyric-Aligner-Setup.log` and intentionally waits for a key press before closing, whether setup succeeds or fails. After a successful setup, close and reopen Echo. The first actual alignment still downloads the selected Whisper model.

## Optional local lyric alignment (1.10.0)

Echo can realign lyric text you already have (from a provider or your own text) against the local audio using the optional `lyric-align` + `faster-whisper` engine. Run `Install-Echo-Lyric-Aligner.bat` on 64-bit Windows with Python 3.9+; the first use downloads a Whisper Tiny or Base model (your choice). Audio remains local. The alignment result is staged in the lyrics editor for review, and low-confidence unmatched lines stay untimed. This does not generate missing copyrighted song lyrics. See `INSTALLATION-GUIDE.txt`.
