(() => {
  'use strict';

  const DB_NAME = 'echo-desktop-library';
  const DB_VERSION = 2;
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const audio = $('#audio-engine');
  const state = {
    db: null,
    songs: [],
    playlists: [],
    currentSongId: null,
    queueIds: [],
    shuffleQueueBase: null,
    currentView: 'home',
    currentPlaylistId: null,
    searchTerm: '',
    librarySort: 'dateAdded',
    selectionMode: false,
    selectedSongIds: new Set(),
    pendingBulkPlaylistAdd: false,
    draggingQueueId: null,
    currentEditorSongId: null,
    pendingArtworkBlob: null,
    metadataMatches: [],
    lyricsMatches: [],
    shuffle: false,
    repeat: 0,
    currentLyrics: [],
    activeAudioUrl: null,
    isSeeking: false,
    lyricsTimelineVisible: true,
    lyricsTimingPreview: null,
    fullscreenLyricsAutoFollow: true,
    lastFullscreenLyricKey: '',
    urlCache: new WeakMap(),
    settings: { theme: 'midnight', accent: 'violet', defaultLibrarySort: 'dateAdded', visualizerEnabled: true, visualizerStyle: 'bars', visualizerOpacity: 68, hinglishLyrics: true, rememberVolume: true, volume: 0.8 },
    renderedArtworkSongId: undefined,
    renderedArtworkBlob: undefined,
    renderedArtworkTitle: undefined,
    renderedArtworkArtist: undefined,
    audioContext: null,
    audioSource: null,
    audioAnalyser: null,
    visualizerData: null,
    visualizerRaf: 0
  };

  const makeId = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const formatTime = (seconds) => {
    if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${String(s).padStart(2, '0')}`;
  };
  const formatBytes = (bytes) => {
    const value = Number(bytes);
    if (!Number.isFinite(value) || value < 0) return 'Unavailable';
    if (value < 1024) return `${Math.round(value)} B`;
    const units = ['KB', 'MB', 'GB', 'TB'];
    let scaled = value / 1024;
    let unit = units[0];
    for (let index = 0; index < units.length && scaled >= 1024; index++) {
      unit = units[index + 1] || units[index];
      if (index < units.length - 1) scaled /= 1024;
    }
    return `${scaled.toFixed(scaled >= 100 ? 0 : scaled >= 10 ? 1 : 2)} ${unit}`;
  };
  const formatLrcTime = (seconds) => {
    const safe = Math.max(0, Number(seconds) || 0);
    const m = Math.floor(safe / 60);
    const s = (safe % 60).toFixed(2).padStart(5, '0');
    return `[${String(m).padStart(2, '0')}:${s}]`;
  };
  const currentSong = () => state.songs.find(song => song.id === state.currentSongId) || null;
  const findSong = (id) => state.songs.find(song => song.id === id) || null;
  const songTitleFromFile = (name) => {
    const noExt = name.replace(/\.[^.]+$/, '');
    const split = noExt.split(' - ');
    return split.length > 1 ? { artist: split[0].trim(), title: split.slice(1).join(' - ').trim() } : { artist: 'Unknown artist', title: noExt.trim() };
  };
  const audioMimeType = (file) => {
    if (String(file?.type || '').startsWith('audio/')) return file.type;
    const extension = String(file?.name || '').split('.').pop().toLowerCase();
    return ({ mp3: 'audio/mpeg', wav: 'audio/wav', flac: 'audio/flac', m4a: 'audio/mp4', aac: 'audio/aac', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg' })[extension] || 'application/octet-stream';
  };

  function openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('songs')) db.createObjectStore('songs', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('playlists')) db.createObjectStore('playlists', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings', { keyPath: 'key' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('Could not open local library database.'));
    });
  }

  function dbRequest(storeName, mode, operation) {
    return new Promise((resolve, reject) => {
      const tx = state.db.transaction(storeName, mode);
      const store = tx.objectStore(storeName);
      let request;
      let result;
      try { request = operation(store); } catch (error) { reject(error); return; }
      if (request) {
        request.onsuccess = () => { result = request.result; };
        request.onerror = () => reject(request.error || tx.error || new Error('Database request failed.'));
      }
      tx.oncomplete = () => resolve(request ? result : true);
      tx.onerror = () => reject(tx.error || request?.error || new Error('Database transaction failed.'));
      tx.onabort = () => reject(tx.error || request?.error || new Error('Database transaction was aborted.'));
    });
  }

  async function loadLibrary() {
    [state.songs, state.playlists] = await Promise.all([
      dbRequest('songs', 'readonly', store => store.getAll()),
      dbRequest('playlists', 'readonly', store => store.getAll())
    ]);
    state.songs.sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
    state.playlists.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
    renderSidebar();
    renderView();
    updatePlayerUI();
  }

  async function saveSong(song) {
    await dbRequest('songs', 'readwrite', store => store.put(song));
    const index = state.songs.findIndex(item => item.id === song.id);
    if (index >= 0) state.songs[index] = song;
    else state.songs.unshift(song);
    state.songs.sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
  }

  async function saveSettings() {
    if (!state.db) return;
    await dbRequest('settings', 'readwrite', store => store.put({ key: 'preferences', value: { ...state.settings } }));
  }

  function applySettings() {
    const root = document.documentElement;
    root.dataset.theme = state.settings.theme === 'amoled' ? 'amoled' : 'midnight';
    root.dataset.accent = ['violet', 'blue', 'rose', 'emerald'].includes(state.settings.accent) ? state.settings.accent : 'violet';
    root.style.setProperty('--visualizer-opacity', String(Math.max(0.1, Math.min(1, Number(state.settings.visualizerOpacity) / 100))));
    state.librarySort = ['dateAdded', 'title', 'mostPlayed'].includes(state.settings.defaultLibrarySort) ? state.settings.defaultLibrarySort : 'dateAdded';
    const visualizerLayer = $('.artwork-visualizer-layer');
    if (visualizerLayer) visualizerLayer.classList.toggle('is-disabled', !state.settings.visualizerEnabled);
    syncArtworkVisualizerControls();
    if (state.settings.visualizerEnabled && $('#artwork-visualizer')) activateArtworkVisualizer();
    else stopArtworkVisualizer();
  }

  function updateSettingFromControl(control, persist = false) {
    const key = control.dataset.setting;
    if (!key || !Object.hasOwn(state.settings, key)) return;
    const value = control.type === 'checkbox' ? control.checked : control.type === 'range' ? Number(control.value) : control.value;
    state.settings[key] = value;
    if (key === 'hinglishLyrics') renderLyrics();
    if (key === 'rememberVolume' && !value) {
      state.settings.volume = 0.8;
      audio.volume = 0.8;
      $('#volume').value = '0.8';
      $('#volume').style.setProperty('--progress', '80%');
    }
    applySettings();
    const output = $(`[data-setting-value="${key}"]`);
    if (output) output.textContent = key === 'visualizerOpacity' ? `${value}%` : String(value);
    const volumeLabel = $('.settings-volume-value');
    if (volumeLabel && key === 'rememberVolume') volumeLabel.textContent = `${Math.round(audio.volume * 100)}%`;
    if ($('#artwork-visualizer') && ['visualizerEnabled', 'visualizerStyle', 'visualizerOpacity', 'accent'].includes(key)) {
      const layer = $('.artwork-visualizer-layer');
      if (layer) layer.classList.toggle('is-disabled', !state.settings.visualizerEnabled);
      syncArtworkVisualizerControls();
      if (state.settings.visualizerEnabled) activateArtworkVisualizer();
      else stopArtworkVisualizer();
    }
    if (persist) saveSettings().catch(error => { console.error(error); toast('Could not save settings.'); });
  }

  async function savePlaylist(playlist) {
    await dbRequest('playlists', 'readwrite', store => store.put(playlist));
    const index = state.playlists.findIndex(item => item.id === playlist.id);
    if (index >= 0) state.playlists[index] = playlist;
    else state.playlists.push(playlist);
    state.playlists.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
  }

  function getObjectUrl(blob) {
    if (!blob) return '';
    if (!state.urlCache.has(blob)) state.urlCache.set(blob, URL.createObjectURL(blob));
    return state.urlCache.get(blob);
  }

  function artMarkup(song, className = '') {
    if (song?.artworkBlob) return `<img class="${className}" src="${getObjectUrl(song.artworkBlob)}" alt="Artwork for ${escapeHtml(song.title)}">`;
    return `<div class="${className} art-fallback"><svg><use href="#i-music"/></svg></div>`;
  }

  function playlistCoverMarkup(playlist, compact = false) {
    const firstFour = (playlist?.trackIds || []).slice(0, 4).map(findSong).filter(Boolean);
    const cells = Array.from({ length: 4 }, (_, index) => {
      const song = firstFour[index];
      if (song?.artworkBlob) {
        return `<img class="playlist-mosaic-cell" src="${getObjectUrl(song.artworkBlob)}" alt="${escapeHtml(song.title)} artwork">`;
      }
      const symbol = song ? escapeHtml((song.title || '♫').trim().charAt(0).toUpperCase() || '♫') : '♫';
      return `<div class="playlist-mosaic-cell mosaic-fallback ${song ? 'has-song' : 'empty'}"><span>${symbol}</span></div>`;
    }).join('');
    return `<div class="playlist-cover playlist-mosaic${compact ? ' compact' : ''}" role="img" aria-label="Playlist cover made from the first four songs in ${escapeHtml(playlist?.name || 'this playlist')}">${cells}</div>`;
  }


  function toast(message, duration = 2900) {
    const item = document.createElement('div');
    item.className = 'toast';
    item.textContent = message;
    item.setAttribute('role', 'status');
    $('#toast-region').append(item);
    if (duration > 0) window.setTimeout(() => item.remove(), duration);
    return item;
  }

  function renderSidebar() {
    $$('.nav-item[data-view]').forEach(button => button.classList.toggle('active', button.dataset.view === state.currentView && !state.currentPlaylistId));
    $('#liked-count').textContent = state.songs.filter(song => song.liked).length;
    const host = $('#sidebar-playlists');
    host.innerHTML = state.playlists.map((playlist, index) => `
      <button class="sidebar-playlist ${state.currentPlaylistId === playlist.id ? 'active' : ''}" data-action="open-playlist" data-id="${playlist.id}" title="${escapeHtml(playlist.name)}">
        <span class="playlist-glyph">${playlistCoverMarkup(playlist, true)}</span><span>${escapeHtml(playlist.name)}</span>
      </button>`).join('');
  }

  function pageHeader(eyebrow, title, description, actions = '') {
    return `<div class="page-heading"><div><div class="eyebrow">${eyebrow}</div><h1>${title}</h1><p>${description}</p></div><div class="heading-actions">${actions}</div></div>`;
  }

  function emptyState(title, description, actionLabel = 'Import music', action = 'import-songs', secondary = '') {
    return `<div class="empty-state"><div class="empty-icon"><svg><use href="#i-music"/></svg></div><h3>${title}</h3><p>${description}</p><div class="empty-actions"><button class="button primary-button" data-action="${action}"><svg><use href="#i-upload"/></svg>${actionLabel}</button>${secondary}</div></div>`;
  }

  function trackRows(songs, contextIds = songs.map(song => song.id), playlistId = null, selectable = false) {
    if (!songs.length) return `<div class="queue-empty">No songs here yet.</div>`;
    return `<div class="track-list">${songs.map((song, index) => `
      <div class="track-row ${playlistId ? 'has-remove-action' : ''} ${song.id === state.currentSongId ? 'playing' : ''} ${state.selectedSongIds.has(song.id) ? 'selected-for-bulk' : ''}" data-row-song="${song.id}" data-context="${contextIds.join(',')}">
        <div class="track-index">${selectable && state.selectionMode
          ? `<input class="song-select" type="checkbox" data-select-song="${song.id}" aria-label="Select ${escapeHtml(song.title)}" ${state.selectedSongIds.has(song.id) ? 'checked' : ''}>`
          : (song.id === state.currentSongId ? '♫' : String(index + 1).padStart(2, '0'))}</div>
        <button class="track-thumb-button" type="button" data-action="play-row-song" data-id="${song.id}" data-context="${contextIds.join(',')}" title="Play ${escapeHtml(song.title)}" aria-label="Play ${escapeHtml(song.title)}"><span class="track-thumb-media">${artMarkup(song, 'track-thumb')}</span><span class="track-thumb-play"><svg><use href="#i-play"/></svg></span></button>
        <div class="track-main"><strong>${escapeHtml(song.title)}</strong><span>${escapeHtml(song.artist || 'Unknown artist')}</span></div>
        <div class="track-album">${escapeHtml(song.album || song.fileName || 'Local file')}</div>
        <div class="track-duration">${formatTime(song.duration)}</div>
        <div class="track-actions"><button class="icon-button" data-action="add-to-queue" data-id="${song.id}" title="Add to queue"><svg><use href="#i-plus"/></svg></button><button class="icon-button" data-action="add-to-playlist" data-id="${song.id}" title="Add to playlist"><svg><use href="#i-library"/></svg></button><button class="icon-button" data-action="edit-song" data-id="${song.id}" title="Edit song"><svg><use href="#i-more"/></svg></button>${playlistId ? `<button class="icon-button" data-action="remove-from-playlist" data-id="${song.id}" data-playlist-id="${playlistId}" title="Remove from playlist">×</button>` : ''}</div>
      </div>`).join('')}</div>`;
  }

  function renderHome() {
    const recent = [...state.songs].sort((a, b) => (b.lastPlayedAt || 0) - (a.lastPlayedAt || 0)).slice(0, 5);
    const countText = state.songs.length === 1 ? '1 song in your library' : `${state.songs.length} songs in your library`;
    const playlistCards = state.playlists.slice(0, 3).map((playlist, index) => `
      <div class="playlist-card" data-action="open-playlist" data-id="${playlist.id}">
        ${playlistCoverMarkup(playlist)}
        <strong>${escapeHtml(playlist.name)}</strong><span>${playlist.trackIds.length} ${playlist.trackIds.length === 1 ? 'song' : 'songs'}</span>
      </div>`).join('');

    $('#view-content').innerHTML = `
      <div class="hero"><div class="hero-copy"><div class="hero-kicker">YOUR SOUND. YOUR SPACE.</div><h2>Every track has<br/>a place here.</h2><p>Your personal music space. Your songs, artwork, lyrics, and playlists stay on this device.</p><button class="button primary-button" data-action="import-songs"><svg><use href="#i-upload"/></svg>Bring in your music</button></div></div>
      <div class="stat-strip"><div class="stat-card"><strong>${state.songs.length}</strong><span>${countText}</span></div><div class="stat-card"><strong>${state.playlists.length}</strong><span>Personal playlists</span></div><div class="stat-card"><strong>${state.songs.filter(song => song.liked).length}</strong><span>Tracks you love</span></div></div>
      <div class="section-head"><h2>Your playlists</h2><button class="text-button" data-action="new-playlist">Create playlist +</button></div>
      <div class="playlist-grid"><div class="playlist-card create-card" data-action="new-playlist"><div><div class="create-plus"><svg><use href="#i-plus"/></svg></div><strong>New playlist</strong></div></div>${playlistCards || ''}</div>
      <div class="track-section"><div class="section-head"><h2>Recently played</h2><button class="text-button" data-view="library">View library</button></div>${recent.length ? trackRows(recent, recent.map(song => song.id)) : emptyState('Your library is waiting', 'Import music from your computer to start building your offline collection. You can add artwork and synced lyrics to every track.', 'Import music', 'import-songs', '<button class="button secondary-button" data-action="import-folder">Import a folder</button>')}</div>`;
  }

  function renderLibrary() {
    const songs = [...state.songs];
    if (state.librarySort === 'title') {
      songs.sort((a, b) => (a.title || a.fileName || '').localeCompare(b.title || b.fileName || '', undefined, { sensitivity: 'base' }));
    } else if (state.librarySort === 'mostPlayed') {
      songs.sort((a, b) => (Number(b.plays) || 0) - (Number(a.plays) || 0) || (b.lastPlayedAt || 0) - (a.lastPlayedAt || 0));
    } else {
      songs.sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
    }

    const selectionActions = state.selectionMode
      ? `<button class="button secondary-button" data-action="select-all-songs">${state.songs.length && state.songs.every(song => state.selectedSongIds.has(song.id)) ? 'Clear selection' : 'Select all'}</button><button class="button secondary-button" data-action="add-selected-to-playlist" ${state.selectedSongIds.size ? '' : 'disabled'}>Add to playlist (${state.selectedSongIds.size})</button><button class="button secondary-button danger-button" data-action="delete-selected-songs" ${state.selectedSongIds.size ? '' : 'disabled'}>Delete selected</button><button class="button secondary-button" data-action="toggle-selection">Done</button>`
      : `<button class="button secondary-button" data-action="toggle-selection">Select songs</button>`;
    const headingActions = `${selectionActions}<button class="button secondary-button" data-action="import-folder"><svg><use href="#i-library"/></svg>Import folder</button><button class="button primary-button" data-action="import-songs"><svg><use href="#i-upload"/></svg>Import songs</button>`;
    const sortBar = `<div class="library-toolbar"><label for="library-sort">Sort by</label><select id="library-sort" aria-label="Sort library"><option value="dateAdded" ${state.librarySort === 'dateAdded' ? 'selected' : ''}>Date added</option><option value="title" ${state.librarySort === 'title' ? 'selected' : ''}>A–Z</option><option value="mostPlayed" ${state.librarySort === 'mostPlayed' ? 'selected' : ''}>Most played</option></select><span class="library-selection-count">${state.selectionMode ? `${state.selectedSongIds.size} selected` : `${songs.length} tracks`}</span></div>`;
    $('#view-content').innerHTML = `${pageHeader('YOUR COLLECTION', 'Your Library', `${state.songs.length} songs stored on this device`, headingActions)}${sortBar}${songs.length ? trackRows(songs, songs.map(song => song.id), null, true) : emptyState('No music imported yet', 'Choose audio files or a whole folder. Your local music stays on this computer.', 'Import music', 'import-songs', '<button class="button secondary-button" data-action="import-folder">Import a folder</button>')}`;
  }

  function renderLiked() {
    const songs = state.songs.filter(song => song.liked).sort((a, b) => (b.lastPlayedAt || 0) - (a.lastPlayedAt || 0));
    $('#view-content').innerHTML = `${pageHeader('YOUR COLLECTION', 'Liked Songs', `${songs.length} tracks saved to your favourites`, songs.length ? '<button class="button primary-button" data-action="play-list" data-ids="liked"><svg><use href="#i-play"/></svg>Play liked songs</button>' : '')}${songs.length ? trackRows(songs, songs.map(song => song.id)) : emptyState('A little room for favourites', 'Tap the heart on any track to keep it close.', 'Browse your library', 'go-library')}`;
  }

  function renderSearch() {
    const rawTerm = state.searchTerm.trim();
    const normalizedTerm = normalizeLibrarySearch(rawTerm);
    const terms = normalizedTerm.split(/\s+/).filter(Boolean);
    const matches = terms.length
      ? state.songs.filter(song => {
          const haystack = searchableSongText(song);
          return terms.every(term => haystack.includes(term));
        })
      : [];
    const summary = terms.length
      ? `${matches.length} result${matches.length === 1 ? '' : 's'} for “${escapeHtml(rawTerm)}”`
      : 'Search titles, artists, albums, genres, or filenames in your local library.';
    const body = terms.length
      ? (matches.length
          ? trackRows(matches, matches.map(song => song.id))
          : emptyState('No matches found', 'Try a different song title, artist, album, or filename.', 'Clear search', 'clear-search'))
      : emptyState('Find a track in your library', 'Import audio files to build your collection, then search them here.', 'Import music', 'import-songs');
    $('#view-content').innerHTML = `${pageHeader('FIND A TRACK', 'Search', 'Find music stored on this device.')}<div class="search-summary">${summary}</div>${body}`;
  }
  function renderPlaylist() {
    const playlist = state.playlists.find(item => item.id === state.currentPlaylistId);
    if (!playlist) { state.currentPlaylistId = null; state.currentView = 'home'; renderSidebar(); renderView(); return; }
    const songs = playlist.trackIds.map(id => findSong(id)).filter(Boolean);
    const actions = `<button class="button secondary-button" data-action="rename-playlist" data-id="${playlist.id}"><svg><use href="#i-edit"/></svg>Edit</button><button class="button secondary-button danger-button" data-action="delete-playlist" data-id="${playlist.id}"><svg><use href="#i-trash"/></svg>Delete</button><button class="button primary-button" data-action="play-list" data-ids="playlist"><svg><use href="#i-play"/></svg>Play playlist</button>`;
    $('#view-content').innerHTML = `${pageHeader('PLAYLIST', escapeHtml(playlist.name), `${songs.length} ${songs.length === 1 ? 'song' : 'songs'} · stored locally`, actions)}<div class="section-head"><h2>Tracks</h2><button class="text-button" data-action="browse-add-to-playlist" data-id="${playlist.id}">Add tracks +</button></div>${songs.length ? trackRows(songs, songs.map(song => song.id), playlist.id) : emptyState('This playlist is ready for a soundtrack', 'Add tracks from your library using the + button on a song.', 'Browse library', 'go-library')}`;
  }

  function renderSettings() {
    const s = state.settings;
    $('#view-content').innerHTML = `
      ${pageHeader('PREFERENCES', 'Settings', 'Make Echo feel right for your listening space.')}
      <div class="settings-page-grid">
        <section class="settings-card">
          <div class="settings-card-heading"><span class="settings-icon"><svg><use href="#i-settings"/></svg></span><div><h2>Appearance</h2><p>Choose the look and colour of Echo.</p></div></div>
          <label class="settings-field"><span><strong>Theme</strong><small>Pick a dark surface style.</small></span><select data-setting="theme"><option value="midnight" ${s.theme === 'midnight' ? 'selected' : ''}>Midnight</option><option value="amoled" ${s.theme === 'amoled' ? 'selected' : ''}>AMOLED black</option></select></label>
          <label class="settings-field"><span><strong>Accent colour</strong><small>Used for buttons, highlights and progress.</small></span><select data-setting="accent"><option value="violet" ${s.accent === 'violet' ? 'selected' : ''}>Violet</option><option value="blue" ${s.accent === 'blue' ? 'selected' : ''}>Blue</option><option value="rose" ${s.accent === 'rose' ? 'selected' : ''}>Rose</option><option value="emerald" ${s.accent === 'emerald' ? 'selected' : ''}>Emerald</option></select></label>
        </section>
        <section class="settings-card">
          <div class="settings-card-heading"><span class="settings-icon"><svg><use href="#i-music"/></svg></span><div><h2>Artwork visualizer</h2><p>Control the blurred audio-reactive glow in full-screen artwork.</p></div></div>
          <label class="settings-field"><span><strong>Enable visualizer</strong><small>Ambient motion appears while paused; the spectrum follows your music during playback.</small></span><input type="checkbox" data-setting="visualizerEnabled" ${s.visualizerEnabled ? 'checked' : ''}></label>
          <label class="settings-field"><span><strong>Visualizer style</strong><small>Choose how the audio is drawn.</small></span><select data-setting="visualizerStyle"><option value="bars" ${s.visualizerStyle === 'bars' ? 'selected' : ''}>Soft spectrum bars</option><option value="wave" ${s.visualizerStyle === 'wave' ? 'selected' : ''}>Wave line</option></select></label>
          <label class="settings-field settings-range-field"><span><strong>Glow strength</strong><small>Adjust the visualizer's opacity.</small></span><span class="settings-range-control"><input type="range" min="10" max="100" step="1" value="${Number(s.visualizerOpacity) || 68}" data-setting="visualizerOpacity"><output data-setting-value="visualizerOpacity">${Number(s.visualizerOpacity) || 68}%</output></span></label>
        </section>
        <section class="settings-card">
          <div class="settings-card-heading"><span class="settings-icon"><svg><use href="#i-library"/></svg></span><div><h2>Library</h2><p>Set how your collection is organised.</p></div></div>
          <label class="settings-field"><span><strong>Default sort order</strong><small>Used whenever you open Your Library.</small></span><select data-setting="defaultLibrarySort"><option value="dateAdded" ${s.defaultLibrarySort === 'dateAdded' ? 'selected' : ''}>Date added</option><option value="title" ${s.defaultLibrarySort === 'title' ? 'selected' : ''}>A–Z</option><option value="mostPlayed" ${s.defaultLibrarySort === 'mostPlayed' ? 'selected' : ''}>Most played</option></select></label>
        </section>
        <section class="settings-card">
          <div class="settings-card-heading"><span class="settings-icon"><svg><use href="#i-music"/></svg></span><div><h2>Lyrics display</h2><p>Choose how Hindi lyrics appear while listening.</p></div></div>
          <label class="settings-field"><span><strong>Show Hindi lyrics in Hinglish</strong><small>Convert Devanagari lyrics to Roman letters for display. Your saved lyrics and timestamps remain unchanged.</small></span><input type="checkbox" data-setting="hinglishLyrics" ${s.hinglishLyrics !== false ? 'checked' : ''}></label>
        </section>
        <section class="settings-card">
          <div class="settings-card-heading"><span class="settings-icon"><svg><use href="#i-volume"/></svg></span><div><h2>Playback</h2><p>Manage playback preferences.</p></div></div>
          <label class="settings-field"><span><strong>Remember volume</strong><small>Keep your preferred volume between sessions.</small></span><input type="checkbox" data-setting="rememberVolume" ${s.rememberVolume ? 'checked' : ''}></label>
          <div class="settings-field"><span><strong>Current volume</strong><small>${s.rememberVolume ? 'Saved for your next session.' : 'Volume resets to 80% when Echo restarts.'}</small></span><strong class="settings-volume-value">${Math.round(audio.volume * 100)}%</strong></div>
        </section>
        <section class="settings-card">
          <div class="settings-card-heading"><span class="settings-icon"><svg><use href="#i-library"/></svg></span><div><h2>Storage & privacy</h2><p>Your imported audio and edits stay in this Windows user profile.</p></div></div>
          <div class="settings-field"><span><strong>Library size</strong><small>Estimated browser storage used by Echo and other local site data.</small></span><strong id="storage-usage" class="storage-usage-value">Checking…</strong></div>
          <div class="settings-field"><span><strong>Imported tracks</strong><small>Audio copies stored in your local Echo library.</small></span><strong>${state.songs.length}</strong></div>
          <div class="settings-field"><span><strong>Online lookup</strong><small>Only title, artist, album and duration are sent when you request a lookup.</small></span><strong>On demand</strong></div>
        </section>
        <section class="settings-card">
          <div class="settings-card-heading"><span class="settings-icon"><svg><use href="#i-clock"/></svg></span><div><h2>Keyboard shortcuts</h2><p>Control playback and move around Echo without reaching for the mouse.</p></div></div>
          <div class="shortcut-list">
            <div><span>Play / pause</span><kbd>Space</kbd></div>
            <div><span>Seek backward / forward 5 seconds</span><kbd>← / →</kbd></div>
            <div><span>Import songs</span><kbd>Ctrl + O</kbd></div>
            <div><span>Search library</span><kbd>Ctrl + L</kbd></div>
            <div><span>Open queue</span><kbd>Ctrl + Q</kbd></div>
            <div><span>Close overlay / dialog</span><kbd>Esc</kbd></div>
          </div>
        </section>
        <section class="settings-card settings-about-card">
          <div class="settings-card-heading"><span class="settings-icon"><svg><use href="#i-home"/></svg></span><div><h2>About Echo</h2><p>Personal music space · local-first library</p></div></div>
          <div class="settings-about-line"><span>Version</span><strong>1.9.7</strong></div>
          <div class="settings-about-line"><span>Music storage</span><strong>On this device</strong></div>
          <div class="settings-about-line"><span>Online services</span><strong>Metadata and lyrics only</strong></div>
        </section>
      </div>`;
    refreshStorageEstimate();
  }

  async function refreshStorageEstimate() {
    const output = $('#storage-usage');
    if (!output) return;
    if (!navigator.storage?.estimate) { output.textContent = 'Not available'; return; }
    output.textContent = 'Checking…';
    try {
      const estimate = await navigator.storage.estimate();
      if (!output.isConnected) return;
      const usage = formatBytes(estimate.usage);
      const quota = formatBytes(estimate.quota);
      output.textContent = estimate.usage == null ? 'Not available' : `${usage} / ${quota}`;
      output.title = 'Browser estimate for this app origin; it may include other local site data.';
    } catch {
      if (output.isConnected) output.textContent = 'Not available';
    }
  }

  function renderView() {
    if (state.currentPlaylistId) renderPlaylist();
    else if (state.currentView === 'home') renderHome();
    else if (state.currentView === 'library') renderLibrary();
    else if (state.currentView === 'liked') renderLiked();
    else if (state.currentView === 'search') renderSearch();
    else if (state.currentView === 'settings') renderSettings();
    else renderHome();
    renderSidebar();
    updatePlayerUI();
  }

  async function readDuration(file) {
    return new Promise(resolve => {
      const url = URL.createObjectURL(file);
      const temp = document.createElement('audio');
      let settled = false;
      let timer = 0;
      const finish = duration => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        temp.onloadedmetadata = null;
        temp.onerror = null;
        temp.removeAttribute('src');
        URL.revokeObjectURL(url);
        resolve(Number.isFinite(duration) && duration > 0 ? duration : 0);
      };
      temp.preload = 'metadata';
      temp.onloadedmetadata = () => finish(temp.duration);
      temp.onerror = () => finish(0);
      timer = window.setTimeout(() => finish(0), 12000);
      temp.src = url;
    });
  }

  async function importFiles(fileList) {
    const files = Array.from(fileList || []).filter(file => file && (String(file.type || '').startsWith('audio/') || /\.(mp3|wav|flac|m4a|aac|ogg|opus|oga)$/i.test(file.name || '')));
    if (!files.length) { toast('No supported audio files were selected.'); return; }
    let added = 0;
    let duplicates = 0;
    let failed = 0;
    const progressToast = toast(`Preparing to import ${files.length} track${files.length === 1 ? '' : 's'}…`, 0);
    for (let index = 0; index < files.length; index++) {
      const file = files[index];
      progressToast.textContent = `Importing ${index + 1} of ${files.length}: ${file.name}`;
      const fileModifiedAt = Number(file.lastModified) || 0;
      const duplicate = state.songs.some(song => song.fileName === file.name && song.fileSize === file.size && (!song.fileModifiedAt || !fileModifiedAt || song.fileModifiedAt === fileModifiedAt));
      if (duplicate) { duplicates++; continue; }
      const meta = songTitleFromFile(file.name);
      const duration = await readDuration(file);
      const mimeType = audioMimeType(file);
      const song = {
        id: makeId(), title: meta.title || file.name, artist: meta.artist, album: '', fileName: file.name,
        fileSize: file.size, fileModifiedAt, mimeType, blob: file.slice(0, file.size, mimeType),
        artworkBlob: null, lyricsText: '', lyrics: [], duration, liked: false, plays: 0,
        addedAt: Date.now(), lastPlayedAt: 0
      };
      try {
        await saveSong(song);
        added++;
      } catch (error) {
        failed++;
        console.error('Could not import audio file:', error);
        if (error?.name === 'QuotaExceededError') {
          progressToast.remove();
          toast('Your Echo library is out of storage space. Remove some imported tracks and try again.');
          break;
        }
      }
    }
    if (progressToast.isConnected) progressToast.remove();
    renderSidebar(); renderView();
    const summary = [
      added ? `${added} added` : '',
      duplicates ? `${duplicates} duplicate${duplicates === 1 ? '' : 's'} skipped` : '',
      failed ? `${failed} failed` : ''
    ].filter(Boolean).join(' · ');
    if (summary) toast(`Import finished: ${summary}.`);
    else toast('No tracks could be imported. Check that the selected files are supported audio formats.');
  }

  function parseLrc(text) {
    const result = [];
    const lines = String(text || '').split(/\r?\n/);
    const pattern = /\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?\]/g;
    for (const line of lines) {
      const matches = [...line.matchAll(pattern)];
      const lyricText = line.replace(pattern, '').trim();
      for (const match of matches) {
        const fraction = match[3] ? Number(`0.${match[3]}`) : 0;
        const time = Number(match[1]) * 60 + Number(match[2]) + fraction;
        if (lyricText) result.push({ time, text: lyricText });
      }
    }
    return result.sort((a, b) => a.time - b.time);
  }

  function lyricTimeForSong(song, line) {
    const offsetSeconds = (Number(song?.lyricsOffsetMs) || 0) / 1000;
    const rate = Math.max(0.85, Math.min(1.15, (Number(song?.lyricsRate) || 100) / 100));
    return Math.max(0, (Number(line?.time) || 0) * rate + offsetSeconds);
  }

  function normalizeLibrarySearch(value) {
    return String(value ?? '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
      .toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  }

  function searchableSongText(song) {
    const rawFields = [song.title, song.artist, song.album, song.fileName, song.albumArtist, song.genre];
    const romanFields = rawFields.map(value => {
      const text = String(value || '');
      return /[\u0900-\u097f]/.test(text) ? (window.echoHinglish?.toHinglish(text) || '') : '';
    });
    return normalizeLibrarySearch([...rawFields, ...romanFields].join(' '));
  }

  function lyricDisplayText(text) {
    const source = String(text ?? '');
    if (!state.settings.hinglishLyrics || !/[\u0900-\u097F]/.test(source)) return source;
    return window.echoHinglish?.toHinglish(source) || source;
  }

  function renderLyrics() {
    const song = currentSong();
    const host = $('#lyrics-display');
    if (!song) {
      host.innerHTML = '<p class="lyrics-empty">Your lyrics will appear here. Add an .LRC file or sync a text file line by line.</p>';
      renderFullscreenLyrics(null, [], -1);
      return;
    }
    const lyrics = song.lyrics?.length ? song.lyrics : parseLrc(song.lyricsText || '');
    state.currentLyrics = lyrics;
    if (!lyrics.length) {
      const plain = String(song.lyricsText || '').split(/\r?\n/).filter(line => line.trim());
      host.innerHTML = plain.length ? plain.map(line => `<p>${escapeHtml(lyricDisplayText(line))}</p>`).join('') : '<p class="lyrics-empty">No lyrics yet. Use “Edit / sync” to import an .LRC or add timed lyrics.</p>';
      renderFullscreenLyrics(song, [], -1);
      return;
    }
    const time = audio.currentTime || 0;
    let active = lyrics.findIndex((line, index) => time >= lyricTimeForSong(song, line) && (index === lyrics.length - 1 || time < lyricTimeForSong(song, lyrics[index + 1])));
    if (active < 0) active = time < lyricTimeForSong(song, lyrics[0]) ? -1 : lyrics.length - 1;
    const activeChanged = state.lastActiveLyric !== `${song.id}:${active}`;
    state.lastActiveLyric = `${song.id}:${active}`;
    const start = Math.max(0, active - 3);
    const end = Math.min(lyrics.length, Math.max(7, active + 4));
    const visible = lyrics.slice(start, end);
    host.innerHTML = visible.map((line, localIndex) => `<p class="${start + localIndex === active ? 'active-lyric' : ''}">${escapeHtml(lyricDisplayText(line.text))}</p>`).join('');
    const activeElement = $('.active-lyric', host);
    if (activeElement && activeChanged) activeElement.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    renderFullscreenLyrics(song, lyrics, active);
  }

  function renderFullscreenLyrics(song, lyrics, active) {
    const host = $('#fullscreen-lyrics-lines');
    if (!host) return;
    const title = $('#fullscreen-lyrics-title');
    const subtitle = $('#fullscreen-lyrics-subtitle');
    if (title) title.textContent = song?.title || 'Lyrics';
    if (subtitle) subtitle.textContent = song ? (song.artist || 'Unknown artist') : 'Nothing is playing';
    if (!song) {
      host.innerHTML = '<div class="fullscreen-lyric-empty">Play a song with lyrics to see them here.</div>';
      return;
    }
    const oldScrollTop = host.parentElement?.scrollTop || 0;
    if (lyrics.length) {
      host.innerHTML = lyrics.map((line, index) => {
        const isActive = index === active;
        const className = isActive ? 'is-active' : index < active ? 'is-past' : 'is-upcoming';
        const seekTime = lyricTimeForSong(song, line);
        return `<button type="button" class="fullscreen-lyric-line ${className}" data-action="seek-lyric" data-time="${seekTime.toFixed(3)}" data-lyric-index="${index}" aria-label="Jump to ${formatTime(seekTime)}: ${escapeHtml(lyricDisplayText(line.text))}">${escapeHtml(lyricDisplayText(line.text))}</button>`;
      }).join('');
      const scrollHost = host.parentElement;
      if (scrollHost) {
        const key = `${song.id}:${active}`;
        if (state.fullscreenLyricsAutoFollow && key !== state.lastFullscreenLyricKey) {
          const activeLine = host.querySelector('.is-active');
          if (activeLine) {
            const viewportRect = scrollHost.getBoundingClientRect();
            const lineRect = activeLine.getBoundingClientRect();
            const lineTop = scrollHost.scrollTop + lineRect.top - viewportRect.top;
            const targetTop = Math.max(0, lineTop - (scrollHost.clientHeight - lineRect.height) / 2);
            scrollHost.scrollTo({ top: targetTop, behavior: 'smooth' });
          }
        } else {
          scrollHost.scrollTop = oldScrollTop;
        }
        state.lastFullscreenLyricKey = key;
      }
      return;
    }
    const plain = String(song.lyricsText || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean);
    host.innerHTML = plain.length
      ? plain.map((line, index) => `<div class="fullscreen-lyric-line ${index === 0 ? 'is-active' : 'is-upcoming'}">${escapeHtml(lyricDisplayText(line))}</div>`).join('')
      : '<div class="fullscreen-lyric-empty">No lyrics saved for this track yet.</div>';
    if (host.parentElement) host.parentElement.scrollTop = oldScrollTop;
  }

  async function playSong(id, contextIds = null) {
    const song = findSong(id);
    if (!song) { toast('That track is no longer in your library.'); return; }
    if (contextIds?.length) {
      const base = [...new Set(contextIds.filter(songId => findSong(songId)))];
      if (!base.includes(id)) base.unshift(id);
      if (state.shuffle) {
        state.shuffleQueueBase = base;
        state.queueIds = buildShuffledQueue(base, id);
      } else {
        state.shuffleQueueBase = null;
        state.queueIds = base;
      }
    } else if (!state.queueIds.includes(id)) {
      // A single-track navigation (Next/Previous) must never rebuild the fixed shuffle order.
      state.queueIds.unshift(id);
      if (state.shuffleQueueBase && !state.shuffleQueueBase.includes(id)) state.shuffleQueueBase.unshift(id);
    }
    audio.pause();
    if (state.activeAudioUrl) URL.revokeObjectURL(state.activeAudioUrl);
    state.currentSongId = id;
    state.activeAudioUrl = URL.createObjectURL(song.blob);
    audio.src = state.activeAudioUrl;
    audio.load();
    $('#seek').value = '0';
    $('#seek').style.setProperty('--progress', '0%');
    $('#current-time').textContent = '0:00';
    song.lastPlayedAt = Date.now(); song.plays = (song.plays || 0) + 1;
    await saveSong(song);
    try { await ensureVisualizerAudioGraph(); await audio.play(); } catch (error) { toast('This audio format could not be played by the built-in player.'); }
    updatePlayerUI(); renderView();
    if ($('.modal')?.dataset.modalType === 'queue') openQueue();
  }

  async function togglePlay() {
    if (!currentSong()) {
      const first = state.songs[0];
      if (first) await playSong(first.id, state.songs.map(song => song.id));
      else toast('Import music from your computer to start listening.');
      return;
    }
    if (audio.paused) {
      try { await ensureVisualizerAudioGraph(); await audio.play(); }
      catch { toast('Could not start playback. Check that the audio file is supported.'); }
    } else audio.pause();
    updatePlayButton();
  }

  function getPlayableQueue() {
    return state.queueIds.map(id => findSong(id)).filter(Boolean).map(song => song.id);
  }

  function buildShuffledQueue(ids, currentId = state.currentSongId) {
    const unique = [...new Set(ids.filter(id => findSong(id)))];
    const rest = unique.filter(id => id !== currentId);
    for (let index = rest.length - 1; index > 0; index--) {
      const randomIndex = Math.floor(Math.random() * (index + 1));
      [rest[index], rest[randomIndex]] = [rest[randomIndex], rest[index]];
    }
    return currentId && unique.includes(currentId) ? [currentId, ...rest] : rest;
  }

  function syncShuffleButton() {
    const button = $('#shuffle-btn');
    if (!button) return;
    button.classList.toggle('selected', state.shuffle);
    button.setAttribute('aria-pressed', String(state.shuffle));
    button.title = state.shuffle ? 'Shuffle on · fixed queue' : 'Shuffle off';
  }

  function toggleShuffle() {
    if (!state.shuffle) {
      const base = getPlayableQueue();
      if (currentSong() && !base.includes(state.currentSongId)) base.unshift(state.currentSongId);
      state.shuffleQueueBase = [...base];
      state.shuffle = true;
      state.queueIds = buildShuffledQueue(base, state.currentSongId);
      toast('Shuffle on. A fixed shuffled queue is ready.');
    } else {
      state.shuffle = false;
      const restored = (state.shuffleQueueBase || getPlayableQueue()).filter(id => findSong(id));
      if (currentSong() && !restored.includes(state.currentSongId)) restored.unshift(state.currentSongId);
      state.queueIds = restored;
      state.shuffleQueueBase = null;
      toast('Shuffle off. Original queue restored.');
    }
    syncShuffleButton();
    if ($('.modal')?.dataset.modalType === 'queue') openQueue();
  }

  function nextTrack(manual = false) {
    const ids = getPlayableQueue();
    if (!ids.length) return;
    if (state.repeat === 2 && !manual && currentSong()) { audio.currentTime = 0; audio.play(); return; }
    const index = ids.indexOf(state.currentSongId);
    if (index >= 0 && index < ids.length - 1) playSong(ids[index + 1]);
    else if ((state.repeat === 1 || manual) && ids.length) playSong(ids[0]);
    else updatePlayButton();
  }

  function previousTrack() {
    if (!currentSong()) return;
    const ids = getPlayableQueue();
    const index = ids.indexOf(state.currentSongId);
    // Queue navigation always follows the prepared order. This means Previous
    // reliably returns to the last queue entry, even after several seconds.
    if (index > 0) playSong(ids[index - 1]);
    else audio.currentTime = 0;
  }

  async function ensureVisualizerAudioGraph() {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return false;
    if (!state.audioContext) {
      try {
        state.audioContext = new AudioContextClass();
        state.audioAnalyser = state.audioContext.createAnalyser();
        state.audioAnalyser.fftSize = 256;
        state.audioAnalyser.smoothingTimeConstant = 0.86;
        state.audioSource = state.audioContext.createMediaElementSource(audio);
        state.audioSource.connect(state.audioAnalyser);
        state.audioAnalyser.connect(state.audioContext.destination);
        state.visualizerData = new Uint8Array(state.audioAnalyser.frequencyBinCount);
      } catch (error) {
        console.warn('Echo visualizer could not initialise:', error);
        state.audioContext = null;
        state.audioAnalyser = null;
        state.audioSource = null;
        state.visualizerData = null;
        return false;
      }
    }
    if (state.audioContext.state === 'suspended') {
      try { await state.audioContext.resume(); } catch { return false; }
    }
    return Boolean(state.audioAnalyser);
  }

  function syncArtworkVisualizerControls() {
    const enabled = !!state.settings.visualizerEnabled;
    const layer = $('.artwork-visualizer-layer');
    if (layer) layer.classList.toggle('is-disabled', !enabled);
    const button = $('#fullscreen-visualizer-toggle');
    if (button) {
      button.classList.toggle('is-on', enabled);
      button.setAttribute('aria-pressed', String(enabled));
      button.innerHTML = `<svg><use href="#i-wave"/></svg><span>Visualizer ${enabled ? 'On' : 'Off'}</span>`;
    }
    const status = $('#artwork-visualizer-status');
    if (status) {
      status.textContent = !enabled ? 'VISUALIZER OFF' : (audio.paused ? 'PLAY TO ACTIVATE' : 'AUDIO VISUALIZER');
    }
  }

  function stopArtworkVisualizer() {
    if (state.visualizerRaf) cancelAnimationFrame(state.visualizerRaf);
    state.visualizerRaf = 0;
    syncArtworkVisualizerControls();
  }

  async function activateArtworkVisualizer() {
    if (!$('#artwork-visualizer') || !state.settings.visualizerEnabled) return;
    if (audio.paused) { startArtworkVisualizer(true); return; }
    const ready = state.audioAnalyser ? true : await ensureVisualizerAudioGraph();
    if (!$('#artwork-visualizer') || !state.settings.visualizerEnabled) return;
    // Keep the artwork presentation visibly alive even on systems where Web Audio
    // analyser creation is blocked; when available, real track frequencies take over.
    startArtworkVisualizer(!ready);
  }

  function startArtworkVisualizer(forceAmbient = false) {
    const canvas = $('#artwork-visualizer');
    if (!canvas || !state.settings.visualizerEnabled) return;
    stopArtworkVisualizer();
    const context = canvas.getContext('2d');
    if (!context) return;
    const status = $('#artwork-visualizer-status');
    const hasLiveAudio = !forceAmbient && !audio.paused && Boolean(state.audioAnalyser);
    if (status) status.textContent = hasLiveAudio ? 'AUDIO VISUALIZER' : 'AMBIENT MODE · PLAY TO SYNC';
    const draw = timestamp => {
      if (!canvas.isConnected || !state.settings.visualizerEnabled) { stopArtworkVisualizer(); return; }
      const width = Math.max(1, canvas.clientWidth);
      const height = Math.max(1, canvas.clientHeight);
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      const pixelWidth = Math.round(width * ratio);
      const pixelHeight = Math.round(height * ratio);
      if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
        canvas.width = pixelWidth;
        canvas.height = pixelHeight;
      }
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      context.clearRect(0, 0, width, height);
      const live = !forceAmbient && !audio.paused && Boolean(state.audioAnalyser);
      if (live) state.audioAnalyser.getByteFrequencyData(state.visualizerData);
      const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#b86cff';
      const time = (Number(timestamp) || performance.now()) / 1000;
      context.lineCap = 'round';
      context.lineJoin = 'round';
      context.strokeStyle = accent;
      context.fillStyle = accent;
      context.shadowColor = accent;
      context.shadowBlur = 30;
      if (state.settings.visualizerStyle === 'wave') {
        context.beginPath();
        const points = Math.max(100, Math.floor(width / 3));
        for (let i = 0; i < points; i++) {
          const x = i / (points - 1) * width;
          const dataIndex = Math.min((state.visualizerData?.length || 1) - 1, Math.floor((i / (points - 1)) ** 1.8 * ((state.visualizerData?.length || 1) - 1)));
          const signal = live ? (state.visualizerData[dataIndex] || 0) / 255 : (0.18 + (0.5 + 0.5 * Math.sin(time * 1.35 + i * 0.075)) * 0.24);
          const y = height * 0.82 - Math.max(0.04, signal) * height * 0.72;
          if (i === 0) context.moveTo(x, y); else context.lineTo(x, y);
        }
        context.lineWidth = 3.5;
        context.globalAlpha = live ? 0.92 : 0.58;
        context.stroke();
      } else {
        const count = Math.min(72, Math.max(36, Math.floor(width / 17)));
        const gap = 3;
        const barWidth = Math.max(2, (width - gap * (count - 1)) / count);
        for (let i = 0; i < count; i++) {
          const position = i / Math.max(1, count - 1);
          const dataIndex = Math.min((state.visualizerData?.length || 1) - 1, Math.floor(position ** 2.05 * ((state.visualizerData?.length || 1) - 1)));
          const liveLevel = live ? Math.pow((state.visualizerData[dataIndex] || 0) / 255, 0.78) : 0;
          const ambientLevel = 0.16 + (0.5 + 0.5 * Math.sin(time * (0.9 + (i % 9) * 0.11) + i * 0.42)) * 0.22;
          const level = live ? liveLevel : ambientLevel;
          const barHeight = Math.max(8, (0.08 + level * 0.86) * height);
          const x = i * (barWidth + gap);
          const y = height - barHeight;
          context.globalAlpha = live ? 0.48 + level * 0.48 : 0.62;
          context.beginPath();
          if (typeof context.roundRect === 'function') context.roundRect(x, y, barWidth, barHeight, Math.min(6, barWidth / 2));
          else context.rect(x, y, barWidth, barHeight);
          context.fill();
        }
      }
      context.globalAlpha = 1;
      state.visualizerRaf = requestAnimationFrame(draw);
    };
    draw();
  }

  function updatePlayButton() {
    const hasTrack = Boolean(currentSong());
    const playing = hasTrack && !audio.paused;
    const button = $('#play-btn');
    button.innerHTML = `<svg><use href="#i-${playing ? 'pause' : 'play'}"/></svg>`;
    button.title = playing ? 'Pause' : 'Play';
    button.disabled = !hasTrack;
    button.setAttribute('aria-label', button.title);
    for (const fullscreenButtonId of ['fullscreen-play-btn', 'fullscreen-lyrics-play-btn']) {
      const fullscreenButton = $(`#${fullscreenButtonId}`);
      if (fullscreenButton) {
        fullscreenButton.innerHTML = `<svg><use href="#i-${playing ? 'pause' : 'play'}"/></svg>`;
        fullscreenButton.title = playing ? 'Pause' : 'Play';
      }
    }
  }

  function renderNowArtwork(song) {
    const artHost = $('#now-art');
    const songId = song?.id ?? null;
    const artworkBlob = song?.artworkBlob ?? null;
    const hasButton = Boolean($('.now-art-open', artHost));
    const hasEmptyState = Boolean($('.empty-art-inner', artHost));
    const alreadyRendered = state.renderedArtworkSongId === songId &&
      state.renderedArtworkBlob === artworkBlob &&
      state.renderedArtworkTitle === (song?.title ?? null) &&
      state.renderedArtworkArtist === (song?.artist ?? null) &&
      (song ? hasButton : hasEmptyState);
    if (alreadyRendered) return;

    state.renderedArtworkSongId = songId;
    state.renderedArtworkBlob = artworkBlob;
    state.renderedArtworkTitle = song?.title ?? null;
    state.renderedArtworkArtist = song?.artist ?? null;
    if (song) {
      artHost.classList.toggle('empty-art', !artworkBlob);
      const cover = artworkBlob
        ? artMarkup(song, 'now-art-image')
        : '<div class="now-art-placeholder"><span class="brand-mark large"><i></i><i></i><i></i><i></i><i></i></span><span>Local music.<br/>Your atmosphere.</span></div>';
      artHost.innerHTML = `<button class="now-art-open" type="button" data-song-id="${escapeHtml(song.id)}" title="Open artwork full screen" aria-label="Open artwork full screen for ${escapeHtml(song.title)}">${cover}<span class="art-fullscreen-button" aria-hidden="true"><svg><use href="#i-expand"/></svg><span>Expand</span></span></button>`;
    } else {
      artHost.classList.add('empty-art');
      artHost.innerHTML = '<div class="empty-art-inner"><span class="brand-mark large"><i></i><i></i><i></i><i></i><i></i></span><span>Your next favourite<br/>starts here.</span></div>';
    }
  }

  function updatePlayerUI() {
    const song = currentSong();
    const title = song?.title || 'Nothing playing';
    const artist = song?.artist || (song ? 'Unknown artist' : 'Import something you love');
    $('#now-title').textContent = title;
    $('#now-artist').textContent = artist;
    $('#bar-title').textContent = song?.title || 'Choose a song';
    $('#bar-artist').textContent = song?.artist || 'Your local library';
    $('#now-format').textContent = song ? (song.fileName || 'LOCAL FILE').split('.').pop().toUpperCase() + ' · LOCAL' : 'LOCAL FILE';
    $('#now-duration').textContent = song ? formatTime(song.duration) : '--:--';
    $('#total-time').textContent = song ? formatTime(song.duration) : '0:00';
    $('#now-like').disabled = !song;
    $('#bar-like').disabled = !song;
    $('#now-like').classList.toggle('liked', !!song?.liked);
    $('#bar-like').classList.toggle('liked', !!song?.liked);
    renderNowArtwork(song);
    $('#bar-art').innerHTML = song?.artworkBlob ? artMarkup(song, '') : '<svg><use href="#i-music"/></svg>';
    const duration = Number.isFinite(audio.duration) ? audio.duration : (song?.duration || 0);
    const current = Number.isFinite(audio.currentTime) ? audio.currentTime : 0;
    $('#current-time').textContent = formatTime(current);
    $('#total-time').textContent = song ? formatTime(duration) : '0:00';
    const fullscreenCurrent = $('#fullscreen-current-time');
    const fullscreenTotal = $('#fullscreen-total-time');
    const fullscreenSeek = $('#fullscreen-seek');
    const fullscreenLyricsSeek = $('#fullscreen-lyrics-seek');
    if (fullscreenCurrent) fullscreenCurrent.textContent = formatTime(current);
    if (fullscreenTotal) fullscreenTotal.textContent = song ? formatTime(duration) : '0:00';
    const lyricsCurrent = $('#fullscreen-lyrics-current-time');
    const lyricsTotal = $('#fullscreen-lyrics-total-time');
    if (lyricsCurrent) lyricsCurrent.textContent = formatTime(current);
    if (lyricsTotal) lyricsTotal.textContent = song ? formatTime(duration) : '0:00';
    if (!state.isSeeking) {
      const progress = duration > 0 ? Math.max(0, Math.min(100, current / duration * 100)) : 0;
      $('#seek').value = String(Math.round(progress * 10));
      $('#seek').style.setProperty('--progress', `${progress}%`);
      if (fullscreenSeek) { fullscreenSeek.value = String(Math.round(progress * 10)); fullscreenSeek.style.setProperty('--progress', `${progress}%`); }
      if (fullscreenLyricsSeek) { fullscreenLyricsSeek.value = String(Math.round(progress * 10)); fullscreenLyricsSeek.style.setProperty('--progress', `${progress}%`); }
    }
    renderLyrics();
    updatePlayButton();
    syncShuffleButton();
  }

  async function toggleLike(id = state.currentSongId) {
    const song = findSong(id);
    if (!song) return;
    song.liked = !song.liked;
    await saveSong(song);
    renderSidebar(); renderView(); updatePlayerUI();
    toast(song.liked ? 'Added to Liked Songs.' : 'Removed from Liked Songs.');
  }

  function showModal(content, wide = false) {
    const root = $('#modal-root');
    root.classList.remove('fullscreen-root');
    root.innerHTML = `<div class="modal-backdrop"><div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">${content}</div></div>`;
    $('.modal-backdrop', root).addEventListener('mousedown', event => { if (event.target.classList.contains('modal-backdrop')) closeModal(); });
    return $('.modal', root);
  }
  function closeModal() { stopArtworkVisualizer(); const root = $('#modal-root'); root.classList.remove('fullscreen-root'); root.innerHTML = ''; state.pendingBulkPlaylistAdd = false; state.draggingQueueId = null; }

  function openArtworkFullscreen(songId = state.currentSongId) {
    const song = findSong(songId) || currentSong();
    if (!song) { toast('Play a track first to open its artwork.'); return; }
    stopArtworkVisualizer();
    const root = $('#modal-root');
    root.classList.add('fullscreen-root');
    const artworkUrl = song.artworkBlob ? getObjectUrl(song.artworkBlob) : '';
    const artworkMarkup = artworkUrl
      ? `<img class="fullscreen-artwork-image" src="${artworkUrl}" alt="Artwork for ${escapeHtml(song.title)}" />`
      : '<div class="fullscreen-artwork-placeholder"><svg><use href="#i-music"/></svg><span>Artwork not added yet</span></div>';
    const backdropMarkup = artworkUrl ? `<img class="fullscreen-artwork-backdrop" src="${artworkUrl}" alt="" aria-hidden="true" />` : '';
    root.innerHTML = `
      <div class="fullscreen-stage artwork-fullscreen" role="dialog" aria-modal="true" aria-label="Full-screen album artwork" tabindex="-1">
        ${backdropMarkup}
        <div class="artwork-visualizer-layer ${state.settings.visualizerEnabled ? '' : 'is-disabled'}"><canvas id="artwork-visualizer" aria-hidden="true"></canvas><div class="artwork-visualizer-status" id="artwork-visualizer-status">${state.settings.visualizerEnabled ? (audio.paused ? 'PLAY TO ACTIVATE' : 'AUDIO VISUALIZER') : 'VISUALIZER OFF'}</div></div>
        <button id="fullscreen-visualizer-toggle" class="fullscreen-visualizer-toggle ${state.settings.visualizerEnabled ? 'is-on' : ''}" data-action="toggle-visualizer" aria-pressed="${String(!!state.settings.visualizerEnabled)}"><svg><use href="#i-wave"/></svg><span>Visualizer ${state.settings.visualizerEnabled ? 'On' : 'Off'}</span></button>
        <button id="fullscreen-close-artwork" class="fullscreen-close" data-action="close-modal" aria-label="Close full screen"><svg><use href="#i-close"/></svg></button>
        ${artworkMarkup}
        <div class="fullscreen-artwork-copy"><h2>${escapeHtml(song.title)}</h2><p>${escapeHtml(song.artist || 'Unknown artist')}</p></div>
        <div class="fullscreen-timeline-pill" aria-label="Playback timeline">
          <span id="fullscreen-current-time">${formatTime(audio.currentTime || 0)}</span>
          <input id="fullscreen-seek" class="range" type="range" min="0" max="1000" value="0" aria-label="Seek through song" />
          <span id="fullscreen-total-time">${formatTime(Number.isFinite(audio.duration) ? audio.duration : song.duration || 0)}</span>
          <button id="fullscreen-play-btn" class="fullscreen-timeline-play" data-action="toggle-play" title="Play or pause"><svg><use href="#i-${audio.paused ? 'play' : 'pause'}"/></svg></button>
        </div>
      </div>`;
    syncArtworkVisualizerControls();
    updatePlayerUI();
    // Wait until the fullscreen canvas has a measured size before its first draw.
    requestAnimationFrame(() => {
      if ($('#artwork-visualizer')) activateArtworkVisualizer();
    });
    $('#fullscreen-close-artwork')?.focus({ preventScroll: true });
  }

  function openLyricsFullscreen() {
    stopArtworkVisualizer();
    state.fullscreenLyricsAutoFollow = true;
    state.lastFullscreenLyricKey = '';
    const root = $('#modal-root');
    root.classList.add('fullscreen-root');
    root.innerHTML = `
      <div class="fullscreen-stage lyrics-fullscreen ${state.lyricsTimelineVisible ? '' : 'timeline-hidden'}" role="dialog" aria-modal="true" aria-label="Full-screen lyrics">
        <div class="fullscreen-topline"><div class="fullscreen-brand">ECHO <span>LYRICS</span></div><div class="fullscreen-lyrics-actions"><button class="button secondary-button lyrics-timeline-toggle" data-action="toggle-lyrics-timeline" aria-pressed="${String(state.lyricsTimelineVisible)}"><svg><use href="#i-clock"/></svg>${state.lyricsTimelineVisible ? 'Hide timeline' : 'Show timeline'}</button><button class="button secondary-button lyrics-follow-toggle" data-action="follow-lyrics"><svg><use href="#i-wave"/></svg>Follow active</button><button class="fullscreen-close inline-close" data-action="close-modal" aria-label="Close full screen"><svg><use href="#i-close"/></svg></button></div></div>
        <div class="fullscreen-lyrics-info"><h2 id="fullscreen-lyrics-title">Lyrics</h2><p id="fullscreen-lyrics-subtitle">Now playing</p></div>
        <div class="fullscreen-lyrics-scroll-clip"><div class="fullscreen-lyrics-center" id="fullscreen-lyrics-scroll"><div id="fullscreen-lyrics-lines" class="fullscreen-lyrics-lines"></div></div></div>
        <div class="fullscreen-lyrics-timeline" id="fullscreen-lyrics-timeline" aria-label="Playback timeline">
          <span id="fullscreen-lyrics-current-time">${formatTime(audio.currentTime || 0)}</span>
          <input id="fullscreen-lyrics-seek" class="range" type="range" min="0" max="1000" value="0" aria-label="Seek through song from lyrics" />
          <span id="fullscreen-lyrics-total-time">${formatTime(Number.isFinite(audio.duration) ? audio.duration : currentSong()?.duration || 0)}</span>
          <button id="fullscreen-lyrics-play-btn" class="fullscreen-timeline-play" data-action="toggle-play" title="Play or pause"><svg><use href="#i-${audio.paused ? 'play' : 'pause'}"/></svg></button>
        </div>
        <div class="fullscreen-bottom-note">SYNCED LYRICS · SELECT A LINE TO JUMP TO IT</div>
      </div>`;
    $('#fullscreen-lyrics-scroll')?.addEventListener('wheel', () => { state.fullscreenLyricsAutoFollow = false; }, { passive: true });
    $('#fullscreen-lyrics-scroll')?.addEventListener('touchmove', () => { state.fullscreenLyricsAutoFollow = false; }, { passive: true });
    $('#fullscreen-lyrics-scroll')?.addEventListener('pointerdown', event => { if (event.target === event.currentTarget) state.fullscreenLyricsAutoFollow = false; }, { passive: true });
    renderLyrics();
    updatePlayerUI();
    $('.lyrics-fullscreen .fullscreen-close')?.focus({ preventScroll: true });
  }


  function openSongEditor(id) {
    const song = findSong(id);
    if (!song) return;
    state.currentEditorSongId = id;
    state.pendingArtworkBlob = null;
    state.metadataMatches = [];
    state.lyricsMatches = [];
    const modal = showModal(`
      <div class="modal-head"><div><h2>Edit track details</h2><p>Choose manual editing or fetch matching information online. Nothing is applied until you save.</p></div><button class="icon-button" data-action="close-modal"><svg><use href="#i-close"/></svg></button></div>
      <form id="song-edit-form">
        <section class="editor-section">
          <div class="editor-section-head"><div><h3>Metadata</h3><p>Edit manually or search online for this track.</p></div><button class="button secondary-button" type="button" data-action="fetch-metadata">Fetch metadata online</button></div>
          <div class="field metadata-extra-search"><label for="metadata-extra-query">Broaden metadata search (optional)</label><input id="metadata-extra-query" maxlength="500" placeholder="Alternate title, transliteration, featured artist, or spelling" /><div class="hint">Use this for alternate spellings, regional titles, remix names, or featured artists. Separate multiple alternatives with semicolons.</div></div>
          <div class="cover-preview" id="cover-preview">${song.artworkBlob ? artMarkup(song, '') : '<div class="cover-placeholder"><svg><use href="#i-music"/></svg></div>'}<div><strong style="font-size:11px">Album artwork</strong><div class="hint">Upload your own image or fetch artwork from a matching release.</div></div></div>
          <div class="field"><label for="cover-file">Upload artwork manually</label><input id="cover-file" type="file" accept="image/png,image/jpeg,image/webp" /></div>
          <div class="form-grid"><div class="field"><label for="edit-title">Song title</label><input id="edit-title" maxlength="160" value="${escapeHtml(song.title)}" required /></div><div class="field"><label for="edit-artist">Artist</label><input id="edit-artist" maxlength="160" value="${escapeHtml(song.artist)}" /></div></div>
          <div class="form-grid"><div class="field"><label for="edit-album">Album / collection</label><input id="edit-album" maxlength="160" value="${escapeHtml(song.album || '')}" placeholder="Optional" /></div><div class="field"><label for="edit-album-artist">Album artist</label><input id="edit-album-artist" maxlength="160" value="${escapeHtml(song.albumArtist || '')}" placeholder="Optional" /></div></div>
          <div class="form-grid"><div class="field"><label for="edit-year">Release year</label><input id="edit-year" inputmode="numeric" maxlength="4" value="${escapeHtml(song.year || '')}" placeholder="e.g. 2024" /></div><div class="field"><label for="edit-genre">Genre</label><input id="edit-genre" maxlength="60" value="${escapeHtml(song.genre || '')}" placeholder="Optional" /></div></div>
          <div id="metadata-fetch-results" class="fetch-results" aria-live="polite"></div>
        </section>
        <section class="editor-section lyrics-editor-section">
          <div class="editor-section-head"><div><h3>Lyrics</h3><p>Fetch online lyrics, import a file, or write them yourself.</p></div><button class="button secondary-button" type="button" data-action="fetch-lyrics">Fetch lyrics online</button></div>
          <div id="lyrics-fetch-results" class="fetch-results" aria-live="polite"></div>
          <div class="field"><label for="lyrics-file">Import lyrics file (.LRC or .TXT)</label><input id="lyrics-file" type="file" accept=".lrc,.txt,text/plain" /><div class="hint">Timed .LRC files synchronize with playback. Plain text can be synced line by line below.</div></div>
          <div class="field"><label for="lyrics-editor">Paste / write lyrics</label><textarea id="lyrics-editor" spellcheck="false" placeholder="Paste lyrics here. Use the button below to timestamp the current line.">${escapeHtml(song.lyricsText || '')}</textarea></div>
          <div class="lyric-align-panel">
            <div class="lyric-align-heading"><strong>Auto-sync known lyrics</strong><span>Local · Audio stays on this PC</span></div>
            <div class="form-grid lyric-align-controls"><div class="field"><label for="lyrics-align-language">Vocal language</label><select id="lyrics-align-language"><option value="auto">Auto detect</option><option value="en">English</option><option value="hi">Hindi</option><option value="ur">Urdu</option><option value="pa">Punjabi</option></select></div><div class="field"><label for="lyrics-align-model">Alignment model</label><select id="lyrics-align-model"><option value="tiny">Fast · Tiny (recommended for older PCs)</option><option value="base">Balanced · Base (more accurate, slower)</option></select></div><div class="field lyric-align-action"><label>&nbsp;</label><button class="button secondary-button" type="button" data-action="auto-align-lyrics">Align timestamps</button></div></div>
            <div class="hint">Use this when lyrics have no timestamps or existing timestamps are inaccurate. Echo aligns the text already in the editor against your local song and stages a new LRC for review. The live status shows model loading, audio scanning, lyric matching, and how many lines matched. First-time setup: run <b>Install-Echo-Lyric-Aligner.bat</b> from the Echo folder. Unmatched lines stay untimed for review.</div>
            <div id="lyrics-align-status" class="lyrics-align-status" aria-live="polite"></div>
          </div>
          <div class="field lyrics-offset-field"><label for="lyrics-offset">Timing offset</label><input id="lyrics-offset" type="range" min="-15000" max="15000" step="25" value="${Math.max(-15000, Math.min(15000, Number(song.lyricsOffsetMs) || 0))}" /><div class="lyrics-offset-readout"><span>Earlier</span><strong id="lyrics-offset-value">${Number(song.lyricsOffsetMs) || 0} ms</strong><span>Later</span></div><div class="hint">Negative moves every line earlier; positive moves every line later.</div>
          <label for="lyrics-rate">Timing drift / speed</label><input id="lyrics-rate" type="range" min="85" max="115" step="0.1" value="${Math.max(85, Math.min(115, Number(song.lyricsRate) || 100))}" /><div class="lyrics-offset-readout"><span>Faster</span><strong id="lyrics-rate-value">${(Number(song.lyricsRate) || 100).toFixed(1)}%</strong><span>Slower</span></div><div class="hint">Use this when timing gradually drifts through the song. Below 100% moves later lines progressively earlier; above 100% moves later lines progressively later.</div>
          <div class="lyric-tools"><button class="button secondary-button" type="button" data-action="reset-lyrics-timing">Reset timing</button></div></div>
          <div class="lyric-tools"><button class="button secondary-button" type="button" data-action="stamp-lyric">Stamp current playback time</button><button class="button secondary-button" type="button" data-action="clear-lyrics">Clear lyrics</button></div>
          <div class="hint">Tip: Put the cursor on a line, then press “Stamp current playback time”. Repeat while the song plays to create synced lyrics.</div>
        </section>
        <div class="modal-actions"><button class="button secondary-button danger-button" type="button" data-action="remove-song" data-id="${song.id}">Remove track</button><span style="flex:1"></span><button class="button secondary-button" type="button" data-action="close-modal">Cancel</button><button class="button primary-button" type="submit">Save changes</button></div>
      </form>` , true);
    modal.classList.add('metadata-editor-modal');
    $('#lyrics-file', modal).addEventListener('change', async event => {
      const file = event.target.files?.[0];
      if (!file) return;
      $('#lyrics-editor', modal).value = await file.text();
      toast(`Loaded ${file.name}. Save to keep the lyrics.`);
    });
    $('#song-edit-form', modal).addEventListener('submit', async event => {
      event.preventDefault();
      song.title = $('#edit-title', modal).value.trim() || song.title;
      song.artist = $('#edit-artist', modal).value.trim() || 'Unknown artist';
      song.album = $('#edit-album', modal).value.trim();
      song.albumArtist = $('#edit-album-artist', modal).value.trim();
      song.year = $('#edit-year', modal).value.trim().slice(0, 4);
      song.genre = $('#edit-genre', modal).value.trim();
      song.lyricsText = $('#lyrics-editor', modal).value;
      song.lyrics = parseLrc(song.lyricsText);
      song.lyricsOffsetMs = Math.max(-15000, Math.min(15000, Number($('#lyrics-offset', modal).value) || 0));
      song.lyricsRate = Math.max(85, Math.min(115, Number($('#lyrics-rate', modal).value) || 100));
      const cover = $('#cover-file', modal).files?.[0];
      if (cover) song.artworkBlob = cover.slice(0, cover.size, cover.type);
      else if (state.pendingArtworkBlob) song.artworkBlob = state.pendingArtworkBlob;
      await saveSong(song);
      state.pendingArtworkBlob = null;
      closeModal(); renderView(); updatePlayerUI();
      toast('Track details saved on this device.');
    });
  }

  function blobFromBase64(base64, mimeType) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index++) bytes[index] = binary.charCodeAt(index);
    return new Blob([bytes], { type: mimeType || 'image/jpeg' });
  }

  async function fetchMetadataOnline() {
    const modal = $('.modal');
    const host = $('#metadata-fetch-results', modal);
    const button = $('[data-action="fetch-metadata"]', modal);
    const title = $('#edit-title', modal).value.trim();
    const artist = $('#edit-artist', modal).value.trim();
    const extraQuery = $('#metadata-extra-query', modal)?.value.trim() || '';
    if (!title) { toast('Enter a song title first.'); return; }
    button.disabled = true;
    host.innerHTML = '<div class="fetch-status">Searching a wider MusicBrainz and Apple Music catalog…</div>';
    try {
      const matches = await window.echoDesktop.fetchMetadata({ title, artist, extraQuery });
      state.metadataMatches = matches || [];
      if (!state.metadataMatches.length) {
        host.innerHTML = '<div class="fetch-status">No matches were found in either catalog. Check the title or artist spelling, try a shorter title, or keep editing manually.</div>';
        return;
      }
      host.innerHTML = `<div class="fetch-results-heading">${state.metadataMatches.length} possible match${state.metadataMatches.length === 1 ? '' : 'es'} — choose the correct release</div>${state.metadataMatches.map((match, index) => `
        <div class="fetch-match">
          <div class="fetch-match-copy"><strong>${escapeHtml(match.title)} — ${escapeHtml(match.artist)}</strong><span>${escapeHtml(match.album || 'Album not listed')}${match.year ? ` · ${escapeHtml(match.year)}` : ''}${match.country ? ` · ${escapeHtml(match.country)}` : ''}</span><small>${match.genre ? `Genre: ${escapeHtml(match.genre)} · ` : ''}${escapeHtml(match.provider || 'Online catalog')} match</small></div>
          <button class="button secondary-button" type="button" data-action="apply-metadata-match" data-index="${index}">Use match</button>
        </div>`).join('')}`;
    } catch (error) {
      host.innerHTML = `<div class="fetch-status is-error">${escapeHtml(error.message || 'Metadata search failed.')}</div>`;
    } finally {
      button.disabled = false;
    }
  }

  async function applyMetadataMatch(index) {
    const match = state.metadataMatches[Number(index)];
    if (!match) return;
    state.pendingArtworkBlob = null;
    const originalSong = findSong(state.currentEditorSongId);
    const originalPreview = $('#cover-preview');
    if (originalPreview && originalSong) {
      originalPreview.innerHTML = `${originalSong.artworkBlob ? artMarkup(originalSong, '') : '<div class="cover-placeholder"><svg><use href="#i-music"/></svg></div>'}<div><strong style="font-size:11px">Album artwork</strong><div class="hint">Upload your own image or fetch artwork from a matching release.</div></div>`;
    }
    $('#edit-title').value = match.title || $('#edit-title').value;
    $('#edit-artist').value = match.artist || $('#edit-artist').value;
    if (match.album) $('#edit-album').value = match.album;
    if (match.year) $('#edit-year').value = match.year;
    if (match.genre) $('#edit-genre').value = match.genre;
    if ((match.albumArtist || match.artist) && !$('#edit-album-artist').value.trim()) $('#edit-album-artist').value = match.albumArtist || match.artist;
    const host = $('#metadata-fetch-results');
    const selectedButton = host?.querySelector(`[data-action="apply-metadata-match"][data-index="${Number(index)}"]`);
    if (selectedButton) selectedButton.textContent = 'Selected';
    if (match.releaseId || match.artworkUrl) {
      host.insertAdjacentHTML('beforeend', '<div class="fetch-status">Checking for album artwork…</div>');
      try {
        const artwork = await window.echoDesktop.fetchMetadataArtwork({ releaseId: match.releaseId || '', artworkUrl: match.artworkUrl || '' });
        if (artwork?.base64) {
          state.pendingArtworkBlob = blobFromBase64(artwork.base64, artwork.mimeType);
          const preview = $('#cover-preview');
          if (preview) {
            const imageUrl = getObjectUrl(state.pendingArtworkBlob);
            preview.innerHTML = `<img src="${imageUrl}" alt="Fetched album artwork"><div><strong style="font-size:11px">Artwork found</strong><div class="hint">Fetched artwork is staged. Save changes to keep it locally.</div></div>`;
          }
          host.insertAdjacentHTML('beforeend', `<div class="fetch-status">Album artwork found from ${escapeHtml(match.provider || 'the selected catalog')}. Review the fields and save when ready.</div>`);
        } else {
          host.insertAdjacentHTML('beforeend', '<div class="fetch-status">No front-cover image was available for this release. You can upload one manually.</div>');
        }
      } catch {
        host.insertAdjacentHTML('beforeend', '<div class="fetch-status">Artwork could not be retrieved. You can upload one manually.</div>');
      }
    } else {
      host.insertAdjacentHTML('beforeend', '<div class="fetch-status">Metadata selected. No release artwork link was available.</div>');
    }
    toast('Metadata staged. Review it, then save your changes.');
  }

  async function fetchLyricsOnline() {
    const modal = $('.modal');
    const host = $('#lyrics-fetch-results', modal);
    const button = $('[data-action="fetch-lyrics"]', modal);
    const title = $('#edit-title', modal).value.trim();
    const artist = $('#edit-artist', modal).value.trim();
    const album = $('#edit-album', modal).value.trim();
    const song = findSong(state.currentEditorSongId);
    if (!title) { toast('Enter a song title first.'); return; }
    button.disabled = true;
    host.innerHTML = '<div class="fetch-status">Searching YouLy+ / LyricsPlus, KuGou and LRCLIB for matching lyrics…</div>'; 
    try {
      const matches = await window.echoDesktop.fetchLyrics({ title, artist, album, duration: song?.duration || 0 });
      state.lyricsMatches = matches || [];
      if (!state.lyricsMatches.length) {
        host.innerHTML = '<div class="fetch-status">No lyrics matches were found. You can import a file or write them manually.</div>';
        return;
      }
      host.innerHTML = `${state.lyricsMatches.length} possible lyric match${state.lyricsMatches.length === 1 ? '' : 'es'} — choose the correct version${state.lyricsMatches.map((match, index) => {
        const synced = Boolean(match.syncedLyrics && parseLrc(match.syncedLyrics).length);
        const content = match.syncedLyrics || match.plainLyrics;
        const excerpt = content ? content.split(/\r?\n/).slice(0, 2).join(' / ').slice(0, 130) : (match.instrumental ? 'Instrumental track' : 'No lyric text available');
        const syncDescription = match.syncLevel === 'word'
          ? 'Word/syllable-timed source · Echo imports line start times'
          : match.syncLevel === 'line' || synced
            ? 'Line-synced timestamps'
            : match.instrumental ? 'Instrumental' : 'Plain lyrics · not synchronized';
        return `<div class="fetch-match lyrics-match"><div class="fetch-match-copy"><strong>${escapeHtml(match.title)} — ${escapeHtml(match.artist)}</strong><span>${escapeHtml(match.album || 'Album not listed')}${match.duration ? ` · ${formatTime(match.duration)}` : ''}</span><small><b>${escapeHtml(match.provider || match.source || 'Lyrics provider')}</b> · ${syncDescription}${match.durationDifference !== null ? ` · ${Math.round(match.durationDifference)}s duration difference` : ''} · Hinglish display for Hindi</small><p>${escapeHtml(lyricDisplayText(excerpt))}</p></div><button class="button secondary-button" type="button" data-action="apply-lyrics-match" data-index="${index}">${match.instrumental ? 'Use match' : synced ? 'Use synced lyrics' : 'Use plain lyrics'}</button></div>`;
      }).join('')}`;
    } catch (error) {
      host.innerHTML = `<div class="fetch-status is-error">${escapeHtml(error.message || 'Lyrics search failed.')}</div>`;
    } finally {
      button.disabled = false;
    }
  }

  function applyLyricsMatch(index) {
    const match = state.lyricsMatches[Number(index)];
    if (!match) return;
    const hasUsableTimestamps = Boolean(match.syncedLyrics && parseLrc(match.syncedLyrics).length);
    const lyrics = hasUsableTimestamps ? match.syncedLyrics : (match.plainLyrics || match.syncedLyrics || '');
    if (!lyrics && !match.instrumental) { toast('This result does not include lyrics.'); return; }
    $('#lyrics-editor').value = lyrics;
    if (match.instrumental) toast('This match is marked instrumental.');
    else if (!hasUsableTimestamps) toast('These lyrics do not contain usable timestamps, so they cannot follow playback yet. Try another result labelled Synced, or add timestamps manually.');
    else if (match.syncLevel === 'word') toast('LyricsPlus word/syllable-timed source staged. Echo currently follows line start times; Hindi lines display in Hinglish. Review and save.');
    else toast(`Synced lyrics from ${match.provider || match.source || 'the selected provider'} staged. Hindi lines display in Hinglish. Review and save.`);
  }

  async function autoAlignKnownLyrics() {
    const modal = $('.modal');
    const editor = $('#lyrics-editor', modal);
    const button = $('[data-action="auto-align-lyrics"]', modal);
    const status = $('#lyrics-align-status', modal);
    const song = findSong(state.currentEditorSongId);
    if (!editor || !button || !status || !song) return;

    // Strip old timing tags so the aligner can rebuild the timeline from scratch.
    const knownLyrics = editor.value
      .replace(/\[(?:ar|ti|al|by|offset|re|ve|length):[^\]]*\]/gi, '')
      .split(/\r?\n/)
      .map(line => line.replace(/\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?\]/g, '').trim())
      .join('\n')
      .trim();
    if (!knownLyrics) {
      status.textContent = 'Fetch lyrics from a provider or paste lyrics you already have, then align their timestamps.';
      toast('Add the lyric text first. Echo aligns existing text; it does not generate missing song lyrics.');
      return;
    }
    if (!song.blob) {
      toast('The imported audio could not be found in Echo’s local library.');
      return;
    }

    const renderProgress = (percent, message, mode = 'working') => {
      const value = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
      status.innerHTML = `<div class="lyric-align-progress ${mode}" role="status" aria-live="polite"><div class="lyric-align-progress-track" role="progressbar" aria-label="Lyric alignment progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${value}"><span style="width:${value}%"></span></div><div class="lyric-align-progress-copy"><span>${escapeHtml(message || 'Aligning lyrics…')}</span><strong>${value}%</strong></div></div>`;
    };

    button.disabled = true;
    renderProgress(1, 'Starting the local alignment process…');
    const stopProgress = window.echoDesktop.onAlignmentProgress?.(progress => {
      if (!progress) return;
      renderProgress(progress.percent, progress.message, progress.status || 'working');
    });
    try {
      renderProgress(3, 'Preparing the song audio on this computer…');
      const audioData = new Uint8Array(await song.blob.arrayBuffer());
      renderProgress(7, 'Starting Whisper. On the first run, the selected model may need to download…');
      const result = await window.echoDesktop.alignLyrics({
        audioData,
        fileName: song.fileName || `${song.title || 'song'}.mp3`,
        lyrics: knownLyrics,
        language: $('#lyrics-align-language', modal)?.value || 'auto',
        model: $('#lyrics-align-model', modal)?.value || 'tiny'
      });
      if (!result?.lrc || !Number(result.matchedLines)) throw new Error('No confident lyric timestamps were returned.');
      editor.value = result.lrc.trim();
      const offset = $('#lyrics-offset', modal);
      const rate = $('#lyrics-rate', modal);
      if (offset) offset.value = '0';
      if (rate) rate.value = '100';
      const offsetValue = $('#lyrics-offset-value', modal);
      const rateValue = $('#lyrics-rate-value', modal);
      if (offsetValue) offsetValue.textContent = '0 ms';
      if (rateValue) rateValue.textContent = '100.0%';
      const detected = result.languageDetected ? ` Detected audio language: ${result.languageDetected}.` : '';
      renderProgress(100, `Finished · ${result.matchedLines} of ${result.totalLines} lyric lines matched.`, 'complete');
      status.insertAdjacentHTML('beforeend', `<div class="lyric-align-result">${escapeHtml(`Review the new timestamps in the lyrics box.${detected} Unmatched lines remain plain text. Save changes only after checking the preview.`)}</div>`);
      toast(`Aligned ${result.matchedLines} of ${result.totalLines} lyric lines. Review before saving.`);
    } catch (error) {
      status.textContent = error.message || 'Local lyric alignment failed.';
      if (/Install-Echo-Lyric-Aligner\.bat/.test(status.textContent)) {
        status.insertAdjacentHTML('beforeend', ' <span>After setup, close and reopen Echo.</span>');
      }
      toast('Could not align these lyrics. See the message in the Lyrics editor.');
    } finally {
      if (typeof stopProgress === 'function') stopProgress();
      button.disabled = false;
    }
  }

  function stampCurrentLine() {
    const editor = $('#lyrics-editor');
    if (!editor) return;
    const start = editor.selectionStart;
    const end = editor.selectionEnd;
    const text = editor.value;
    const lineStart = text.lastIndexOf('\n', Math.max(0, start - 1)) + 1;
    let lineEnd = text.indexOf('\n', start);
    if (lineEnd < 0) lineEnd = text.length;
    const line = text.slice(lineStart, lineEnd).replace(/^\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?\]\s*/, '');
    if (!line.trim()) { toast('Place the cursor on a lyric line first.'); return; }
    const editorSong = findSong(state.currentEditorSongId);
    const offset = (Number($('#lyrics-offset')?.value ?? editorSong?.lyricsOffsetMs) || 0) / 1000;
    const rate = Math.max(0.85, Math.min(1.15, (Number($('#lyrics-rate')?.value ?? editorSong?.lyricsRate) || 100) / 100));
    const baseTime = Math.max(0, (audio.currentTime - offset) / rate);
    const timestamp = formatLrcTime(baseTime);
    const updated = `${text.slice(0, lineStart)}${timestamp} ${line}${text.slice(lineEnd)}`;
    editor.value = updated;
    const cursor = lineStart + timestamp.length + 1 + line.length;
    editor.setSelectionRange(cursor, cursor);
    editor.focus();
  }

  function openPlaylistDialog(playlist = null) {
    const editing = !!playlist;
    const modal = showModal(`
      <div class="modal-head"><div><h2>${editing ? 'Edit playlist' : 'Create a playlist'}</h2><p>${editing ? 'Give this collection a new name.' : 'Make a collection for a mood, artist, or moment.'}</p></div><button class="icon-button" data-action="close-modal"><svg><use href="#i-close"/></svg></button></div>
      <form id="playlist-form"><div class="field"><label for="playlist-name">Playlist name</label><input id="playlist-name" maxlength="80" value="${escapeHtml(playlist?.name || '')}" placeholder="e.g. Late Night" required /></div><div class="field"><label for="playlist-description">Description</label><input id="playlist-description" maxlength="160" value="${escapeHtml(playlist?.description || '')}" placeholder="Optional" /></div><div class="modal-actions"><button class="button secondary-button" type="button" data-action="close-modal">Cancel</button><button class="button primary-button" type="submit">${editing ? 'Save playlist' : 'Create playlist'}</button></div></form>`);
    $('#playlist-form', modal).addEventListener('submit', async event => {
      event.preventDefault();
      const name = $('#playlist-name', modal).value.trim();
      if (!name) return;
      const item = playlist || { id: makeId(), name, description: '', trackIds: [], createdAt: Date.now() };
      item.name = name; item.description = $('#playlist-description', modal).value.trim();
      await savePlaylist(item);
      if (!editing && state.pendingBulkPlaylistAdd) {
        const selectedIds = [...state.selectedSongIds].filter(id => findSong(id));
        const existing = new Set(item.trackIds || []);
        const additions = selectedIds.filter(id => !existing.has(id));
        item.trackIds = [...(item.trackIds || []), ...additions];
        await savePlaylist(item);
        state.pendingBulkPlaylistAdd = false;
        state.selectedSongIds.clear();
        state.selectionMode = false;
        closeModal();
        state.currentPlaylistId = item.id; state.currentView = 'library';
        renderView(); toast(`${item.name} created and ${additions.length} selected song${additions.length === 1 ? '' : 's'} added.`);
        return;
      }
      closeModal();
      if (!editing) { state.currentPlaylistId = item.id; state.currentView = 'library'; }
      renderView(); toast(editing ? 'Playlist updated.' : 'Playlist created.');
    });
  }

  function openAddToPlaylist(songId, fixedPlaylistId = null) {
    const song = findSong(songId);
    if (!song) return;
    if (!state.playlists.length) { toast('Create a playlist first.'); openPlaylistDialog(); return; }
    const modal = showModal(`
      <div class="modal-head"><div><h2>Add to playlist</h2><p>Choose where “${escapeHtml(song.title)}” belongs.</p></div><button class="icon-button" data-action="close-modal"><svg><use href="#i-close"/></svg></button></div>
      <div class="queue-list">${state.playlists.map(playlist => `<button class="queue-row" style="border:0;text-align:left;color:inherit;cursor:pointer" data-action="confirm-add-playlist" data-song-id="${song.id}" data-playlist-id="${playlist.id}"><span class="playlist-glyph">${playlistCoverMarkup(playlist, true)}</span><span class="queue-meta"><strong>${escapeHtml(playlist.name)}</strong><span>${playlist.trackIds.length} songs</span></span><span style="color:#b77aff">＋</span></button>`).join('')}</div>
      <div class="modal-actions"><button class="button secondary-button" data-action="close-modal">Cancel</button><button class="button secondary-button" data-action="new-playlist">New playlist</button></div>`);
    if (fixedPlaylistId) modal.dataset.fixedPlaylistId = fixedPlaylistId;
  }

  function openAddSelectedToPlaylist() {
    const selectedIds = [...state.selectedSongIds].filter(id => findSong(id));
    if (!selectedIds.length) { toast('Select at least one song first.'); return; }
    if (!state.playlists.length) {
      state.pendingBulkPlaylistAdd = true;
      toast('Create a playlist and Echo will add the selected songs to it.');
      openPlaylistDialog();
      return;
    }
    showModal(`
      <div class="modal-head"><div><h2>Add ${selectedIds.length} selected songs</h2><p>Choose a playlist. Songs already in it will be skipped.</p></div><button class="icon-button" data-action="close-modal"><svg><use href="#i-close"/></svg></button></div>
      <div class="queue-list">${state.playlists.map(playlist => `<button class="queue-row bulk-playlist-choice" style="border:0;text-align:left;color:inherit;cursor:pointer" data-action="confirm-add-selected-playlist" data-playlist-id="${playlist.id}"><span class="playlist-glyph">${playlistCoverMarkup(playlist, true)}</span><span class="queue-meta"><strong>${escapeHtml(playlist.name)}</strong><span>${playlist.trackIds.length} songs</span></span><span class="bulk-add-symbol">＋</span></button>`).join('')}</div>
      <div class="modal-actions"><button class="button secondary-button" data-action="close-modal">Cancel</button><button class="button secondary-button" data-action="new-playlist">New playlist</button></div>`);
  }

  async function addSelectedSongsToPlaylist(playlistId) {
    const playlist = state.playlists.find(item => item.id === playlistId);
    if (!playlist) { toast('That playlist could not be found.'); return; }
    const selectedIds = [...state.selectedSongIds].filter(id => findSong(id));
    const existing = new Set(playlist.trackIds || []);
    const additions = selectedIds.filter(id => !existing.has(id));
    playlist.trackIds = [...(playlist.trackIds || []), ...additions];
    await savePlaylist(playlist);
    state.selectedSongIds.clear();
    state.selectionMode = false;
    closeModal();
    renderView();
    toast(additions.length ? `${additions.length} song${additions.length === 1 ? '' : 's'} added to ${playlist.name}.` : 'All selected songs were already in that playlist.');
  }

  async function deleteSelectedSongs() {
    const ids = [...state.selectedSongIds].filter(id => findSong(id));
    if (!ids.length) { toast('Select at least one song first.'); return; }
    if (!confirm(`Remove ${ids.length} selected song${ids.length === 1 ? '' : 's'} from your Echo library? This deletes Echo's stored copies, not the original files on your drive.`)) return;

    await new Promise((resolve, reject) => {
      const tx = state.db.transaction('songs', 'readwrite');
      const store = tx.objectStore('songs');
      ids.forEach(id => store.delete(id));
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error || new Error('Could not delete selected songs.'));
      tx.onabort = () => reject(tx.error || new Error('The delete operation was cancelled.'));
    });

    const removed = new Set(ids);
    state.songs = state.songs.filter(song => !removed.has(song.id));
    for (const playlist of state.playlists) {
      const filtered = playlist.trackIds.filter(id => !removed.has(id));
      if (filtered.length !== playlist.trackIds.length) {
        playlist.trackIds = filtered;
        await savePlaylist(playlist);
      }
    }
    state.queueIds = state.queueIds.filter(id => !removed.has(id));
    if (removed.has(state.currentSongId)) {
      audio.pause(); audio.removeAttribute('src'); audio.load();
      if (state.activeAudioUrl) URL.revokeObjectURL(state.activeAudioUrl);
      state.activeAudioUrl = null; state.currentSongId = null;
    }
    state.selectedSongIds.clear();
    state.selectionMode = false;
    closeModal(); renderSidebar(); renderView(); updatePlayerUI();
    toast(`${ids.length} song${ids.length === 1 ? '' : 's'} removed from your Echo library.`);
  }

  function openQueue() {
    const ids = getPlayableQueue();
    const modal = showModal(`
      <div class="modal-head"><div><h2>Playing queue</h2><p>${ids.length} tracks · ${state.shuffle ? 'fixed shuffled order' : 'current listening order'} · drag the grip to arrange this session</p></div><button class="icon-button" data-action="close-modal"><svg><use href="#i-close"/></svg></button></div>
      <div class="queue-list">${ids.length ? ids.map((id, index) => {
        const song = findSong(id); if (!song) return '';
        return `<div class="queue-row ${id === state.currentSongId ? 'current' : ''}" data-queue-id="${id}" data-index="${index}"><button class="queue-drag-handle" draggable="true" title="Drag to reorder" aria-label="Drag ${escapeHtml(song.title)} to reorder">⠿</button>${artMarkup(song, 'queue-thumb')}<div class="queue-meta"><strong>${escapeHtml(song.title)}</strong><span>${escapeHtml(song.artist)}</span></div><button class="icon-button small" data-action="remove-queue" data-index="${index}" title="Remove from queue">×</button></div>`;
      }).join('') : '<div class="queue-empty">Your queue is empty. Play a track or add songs using the + button.</div>'}</div>
      <div class="modal-actions"><button class="button secondary-button" data-action="clear-queue">Clear queue</button><button class="button primary-button" data-action="close-modal">Done</button></div>`, true);
    modal.dataset.modalType = 'queue';
  }

  function playList(ids) {
    if (!ids.length) { toast('There are no songs to play here yet.'); return; }
    state.queueIds = [...ids];
    playSong(ids[0], ids);
  }

  async function addToQueue(id) {
    if (!findSong(id)) return;
    if (!state.queueIds.includes(id)) state.queueIds.push(id);
    if (state.shuffleQueueBase && !state.shuffleQueueBase.includes(id)) state.shuffleQueueBase.push(id);
    toast('Added to queue.');
  }

  async function removeSong(id) {
    const song = findSong(id);
    if (!song || !confirm(`Remove “${song.title}” from your Echo library? This deletes the stored local copy from Echo Desktop, not the original file on your drive.`)) return;
    await dbRequest('songs', 'readwrite', store => store.delete(id));
    state.songs = state.songs.filter(item => item.id !== id);
    state.selectedSongIds.delete(id);
    for (const playlist of state.playlists) {
      playlist.trackIds = playlist.trackIds.filter(songId => songId !== id);
      await savePlaylist(playlist);
    }
    state.queueIds = state.queueIds.filter(songId => songId !== id);
    if (state.currentSongId === id) {
      audio.pause(); audio.removeAttribute('src'); audio.load();
      if (state.activeAudioUrl) URL.revokeObjectURL(state.activeAudioUrl);
      state.activeAudioUrl = null; state.currentSongId = null;
    }
    closeModal(); renderSidebar(); renderView(); updatePlayerUI();
    toast('Track removed from your Echo library.');
  }

  async function deletePlaylist(id) {
    const playlist = state.playlists.find(item => item.id === id);
    if (!playlist || !confirm(`Delete playlist “${playlist.name}”? Your audio files will not be deleted.`)) return;
    await dbRequest('playlists', 'readwrite', store => store.delete(id));
    state.playlists = state.playlists.filter(item => item.id !== id);
    state.currentPlaylistId = null; state.currentView = 'home';
    renderView(); toast('Playlist deleted.');
  }

  function navigate(view) {
    state.currentView = view;
    state.currentPlaylistId = null;
    if (view === 'search' && state.searchTerm) $('#global-search').value = state.searchTerm;
    renderView();
  }

  // Capture artwork clicks on the stable host, not on the replaceable button.
  // This survives any player/library re-render and also catches clicks on the Expand chip.
  $('#now-art').addEventListener('click', event => {
    const artworkButton = event.target.closest?.('.now-art-open');
    if (!artworkButton) return;
    event.preventDefault();
    event.stopPropagation();
    openArtworkFullscreen(artworkButton.dataset.songId || state.currentSongId);
  }, true);

  document.addEventListener('click', async event => {
    const viewButton = event.target.closest('[data-view]');
    if (viewButton) { navigate(viewButton.dataset.view); return; }
    const actionButton = event.target.closest('[data-action]');
    if (!actionButton) return;
    const action = actionButton.dataset.action;
    const id = actionButton.dataset.id;
    switch (action) {
      case 'import-songs': $('#audio-input').click(); break;
      case 'import-folder': $('#folder-input').click(); break;
      case 'toggle-selection':
        state.selectionMode = !state.selectionMode;
        if (!state.selectionMode) state.selectedSongIds.clear();
        renderView();
        break;
      case 'select-all-songs':
        if (state.songs.length && state.songs.every(song => state.selectedSongIds.has(song.id))) state.selectedSongIds.clear();
        else state.songs.forEach(song => state.selectedSongIds.add(song.id));
        renderView();
        break;
      case 'add-selected-to-playlist': openAddSelectedToPlaylist(); break;
      case 'delete-selected-songs': await deleteSelectedSongs(); break;
      case 'new-playlist': closeModal(); openPlaylistDialog(); break;
      case 'open-playlist': state.currentPlaylistId = id; state.currentView = 'library'; renderView(); break;
      case 'play-song': playSong(id); break;
      case 'play-row-song': { const context = (actionButton.dataset.context || '').split(',').filter(Boolean); if (id === state.currentSongId) { if (audio.paused) togglePlay(); else audio.pause(); } else playSong(id, context); break; }
      case 'play-list': {
        let ids = [];
        if (actionButton.dataset.ids === 'liked') ids = state.songs.filter(song => song.liked).map(song => song.id);
        else if (actionButton.dataset.ids === 'playlist') ids = (state.playlists.find(item => item.id === state.currentPlaylistId)?.trackIds || []).filter(songId => findSong(songId));
        playList(ids); break;
      }
      case 'toggle-play': togglePlay(); break;
      case 'next': nextTrack(true); break;
      case 'previous': previousTrack(); break;
      case 'toggle-shuffle': toggleShuffle(); break;
      case 'cycle-repeat': state.repeat = (state.repeat + 1) % 3; actionButton.classList.toggle('selected', state.repeat > 0); actionButton.title = ['Repeat off', 'Repeat all', 'Repeat one'][state.repeat]; toast(actionButton.title); break;
      case 'toggle-current-like': toggleLike(); break;
      case 'add-to-queue': addToQueue(id); break;
      case 'remove-from-playlist': {
        const playlist = state.playlists.find(item => item.id === actionButton.dataset.playlistId);
        if (playlist) {
          playlist.trackIds = playlist.trackIds.filter(songId => songId !== id);
          await savePlaylist(playlist);
          renderSidebar(); renderView();
          toast('Track removed from playlist.');
        }
        break;
      }
      case 'add-to-playlist': {
        if (state.pendingPlaylistId) {
          const playlist = state.playlists.find(item => item.id === state.pendingPlaylistId);
          if (playlist && !playlist.trackIds.includes(id)) { playlist.trackIds.push(id); await savePlaylist(playlist); toast(`Added to ${playlist.name}.`); }
          else toast('That track is already in this playlist.');
          state.pendingPlaylistId = null;
          renderView();
        } else openAddToPlaylist(id);
        break;
      }
      case 'edit-song': openSongEditor(id); break;
      case 'edit-lyrics-current': if (currentSong()) openSongEditor(state.currentSongId); else toast('Play or select a track first.'); break;
      case 'fetch-metadata': await fetchMetadataOnline(); break;
      case 'apply-metadata-match': await applyMetadataMatch(actionButton.dataset.index); break;
      case 'fetch-lyrics': await fetchLyricsOnline(); break;
      case 'apply-lyrics-match': applyLyricsMatch(actionButton.dataset.index); break;
      case 'auto-align-lyrics': await autoAlignKnownLyrics(); break;
      case 'remove-song': await removeSong(id); break;
      case 'stamp-lyric': stampCurrentLine(); break;
      case 'reset-lyrics-timing': { const offset = $('#lyrics-offset'); const rate = $('#lyrics-rate'); if (offset) offset.value = '0'; if (rate) rate.value = '100'; $('#lyrics-offset-value').textContent = '0 ms'; $('#lyrics-rate-value').textContent = '100.0%'; toast('Lyric timing reset. Save changes to keep it.'); break; }
      case 'clear-lyrics': $('#lyrics-editor').value = ''; break;
      case 'close-modal': closeModal(); break;
      case 'open-queue': openQueue(); break;
      case 'toggle-lyrics': openLyricsFullscreen(); break;
      case 'fullscreen-artwork': openArtworkFullscreen(); break;
      case 'toggle-visualizer':
        state.settings.visualizerEnabled = !state.settings.visualizerEnabled;
        applySettings();
        syncArtworkVisualizerControls();
        await saveSettings();
        toast(`Artwork visualizer ${state.settings.visualizerEnabled ? 'enabled' : 'disabled'}.`);
        break;
      case 'fullscreen-lyrics': openLyricsFullscreen(); break;
      case 'toggle-lyrics-timeline': { state.lyricsTimelineVisible = !state.lyricsTimelineVisible; $('.lyrics-fullscreen')?.classList.toggle('timeline-hidden', !state.lyricsTimelineVisible); const toggle = $('.lyrics-timeline-toggle'); if (toggle) { toggle.innerHTML = `<svg><use href="#i-clock"/></svg>${state.lyricsTimelineVisible ? 'Hide timeline' : 'Show timeline'}`; toggle.setAttribute('aria-pressed', String(state.lyricsTimelineVisible)); } break; }
      case 'follow-lyrics': { state.fullscreenLyricsAutoFollow = true; state.lastFullscreenLyricKey = ''; renderLyrics(); break; }
      case 'seek-lyric': { const targetTime = Number(actionButton.dataset.time); if (Number.isFinite(targetTime)) { audio.currentTime = Math.max(0, Math.min(Number.isFinite(audio.duration) ? audio.duration : targetTime, targetTime)); updatePlayerUI(); } break; }
      case 'rename-playlist': openPlaylistDialog(state.playlists.find(item => item.id === id)); break;
      case 'delete-playlist': deletePlaylist(id); break;
      case 'confirm-add-selected-playlist':
        await addSelectedSongsToPlaylist(actionButton.dataset.playlistId);
        break;
      case 'confirm-add-playlist': {
        const playlist = state.playlists.find(item => item.id === actionButton.dataset.playlistId);
        const songId = actionButton.dataset.songId;
        if (playlist && !playlist.trackIds.includes(songId)) { playlist.trackIds.push(songId); await savePlaylist(playlist); closeModal(); renderView(); toast('Added to playlist.'); }
        else { closeModal(); toast('That track is already in this playlist.'); }
        break;
      }
      case 'browse-add-to-playlist': {
        state.currentPlaylistId = null; state.currentView = 'library';
        state.pendingPlaylistId = id;
        renderView();
        toast('Choose the playlist icon beside each track to add it here.');
        break;
      }
      case 'remove-queue': {
        const ids = getPlayableQueue(); const index = Number(actionButton.dataset.index); const removed = ids.splice(index, 1)[0]; state.queueIds = ids; if (state.shuffleQueueBase) state.shuffleQueueBase = state.shuffleQueueBase.filter(songId => songId !== removed);
        if (removed === state.currentSongId) { if (ids.length) playSong(ids[Math.min(index, ids.length - 1)]); else { audio.pause(); state.currentSongId = null; updatePlayerUI(); } }
        openQueue(); break;
      }
      case 'clear-queue': state.queueIds = currentSong() ? [state.currentSongId] : []; state.shuffleQueueBase = state.shuffle ? [...state.queueIds] : null; openQueue(); break;
      case 'go-library': navigate('library'); break;
      case 'clear-search': state.searchTerm = ''; $('#global-search').value = ''; renderView(); break;
    }
  });

  // Native HTML drag-and-drop reorders queue entries without restarting playback.
  document.addEventListener('dragstart', event => {
    const handle = event.target.closest?.('.queue-drag-handle');
    if (!handle) return;
    const row = handle.closest('.queue-row');
    if (!row || !event.dataTransfer) return;
    state.draggingQueueId = row.dataset.queueId;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', state.draggingQueueId);
    row.classList.add('dragging');
  });

  document.addEventListener('dragover', event => {
    if (!state.draggingQueueId) return;
    const row = event.target.closest?.('.queue-row');
    if (!row || row.dataset.queueId === state.draggingQueueId) return;
    event.preventDefault();
    $$('.queue-row').forEach(item => item.classList.remove('drop-before', 'drop-after'));
    const after = event.clientY > row.getBoundingClientRect().top + row.getBoundingClientRect().height / 2;
    row.classList.add(after ? 'drop-after' : 'drop-before');
  });

  document.addEventListener('drop', event => {
    if (!state.draggingQueueId) return;
    const targetRow = event.target.closest?.('.queue-row');
    if (!targetRow) return;
    event.preventDefault();
    const sourceId = state.draggingQueueId;
    const targetId = targetRow.dataset.queueId;
    const after = targetRow.classList.contains('drop-after');
    const ids = getPlayableQueue().filter(id => id !== sourceId);
    const targetIndex = ids.indexOf(targetId);
    if (targetIndex >= 0) {
      ids.splice(targetIndex + (after ? 1 : 0), 0, sourceId);
      state.queueIds = ids;
      openQueue();
      toast(state.shuffle ? 'Shuffled queue order updated.' : 'Queue order updated.');
    }
    state.draggingQueueId = null;
  });

  document.addEventListener('dragend', () => {
    state.draggingQueueId = null;
    $$('.queue-row').forEach(row => row.classList.remove('dragging', 'drop-before', 'drop-after'));
  });

  // File inputs must be wired explicitly: opening the picker alone does not import files.
  async function handleAudioInputChange(event) {
    const input = event.currentTarget;
    const files = Array.from(input.files || []);
    // Reset immediately so selecting the same file again triggers another change event.
    input.value = '';
    await importFiles(files);
  }
  $('#audio-input').addEventListener('change', handleAudioInputChange);
  $('#folder-input').addEventListener('change', handleAudioInputChange);

  document.addEventListener('change', event => {
    if (event.target.matches('[data-setting]')) { updateSettingFromControl(event.target, true); }
    else if (event.target.id === 'volume' && state.settings.rememberVolume) { saveSettings().catch(error => console.warn('Volume preference could not be saved:', error)); }
    else if (event.target.id === 'library-sort') {
      state.librarySort = ['dateAdded', 'title', 'mostPlayed'].includes(event.target.value) ? event.target.value : 'dateAdded';
      state.settings.defaultLibrarySort = state.librarySort;
      saveSettings().catch(error => { console.error(error); toast('Could not save the library sort preference.'); });
      renderLibrary();
    } else if (event.target.matches('[data-select-song]')) {
      const id = event.target.dataset.selectSong;
      if (event.target.checked) state.selectedSongIds.add(id);
      else state.selectedSongIds.delete(id);
      renderLibrary();
    }
  });

  // Keep the local audio engine and the Echo bottom transport in sync.
  audio.volume = 0.8;
  audio.addEventListener('play', () => { updatePlayButton(); if ($('#artwork-visualizer')) activateArtworkVisualizer(); });
  audio.addEventListener('pause', () => { updatePlayButton(); if ($('#artwork-visualizer') && state.settings.visualizerEnabled) startArtworkVisualizer(true); });
  audio.addEventListener('loadedmetadata', updatePlayerUI);
  audio.addEventListener('durationchange', updatePlayerUI);
  audio.addEventListener('timeupdate', updatePlayerUI);
  audio.addEventListener('ended', () => nextTrack(false));

  function applyGlobalSearch(value) {
    state.searchTerm = String(value || '');
    if (state.currentView !== 'search' || state.currentPlaylistId) {
      state.currentView = 'search';
      state.currentPlaylistId = null;
      renderSidebar();
    }
    renderSearch();
  }

  const globalSearchInput = $('#global-search');
  globalSearchInput.addEventListener('input', event => applyGlobalSearch(event.currentTarget.value));
  globalSearchInput.addEventListener('search', event => applyGlobalSearch(event.currentTarget.value));
  globalSearchInput.addEventListener('keydown', event => {
    if (event.key === 'Enter') { event.preventDefault(); applyGlobalSearch(event.currentTarget.value); }
    if (event.key === 'Escape' && event.currentTarget.value) {
      event.preventDefault(); event.currentTarget.value = ''; applyGlobalSearch('');
    }
  });

  document.addEventListener('input', event => {
    if (event.target.id === 'lyrics-offset' || event.target.id === 'lyrics-rate') {
      const offsetOutput = $('#lyrics-offset-value');
      const rateOutput = $('#lyrics-rate-value');
      if (offsetOutput && event.target.id === 'lyrics-offset') offsetOutput.textContent = `${Number(event.target.value) || 0} ms`;
      if (rateOutput && event.target.id === 'lyrics-rate') rateOutput.textContent = `${Number(event.target.value) || 100}%`;
      return;
    }
    if (event.target.matches('[data-setting]')) { updateSettingFromControl(event.target, false); return; }
    if (['seek', 'fullscreen-seek', 'fullscreen-lyrics-seek'].includes(event.target.id)) {
      const value = Number(event.target.value) / 1000;
      const progress = Math.max(0, Math.min(100, value * 100));
      event.target.style.setProperty('--progress', `${progress}%`);
      if (Number.isFinite(audio.duration) && audio.duration > 0) {
        state.isSeeking = true;
        audio.currentTime = audio.duration * value;
        $('#current-time').textContent = formatTime(audio.currentTime);
        const fullCurrent = $('#fullscreen-current-time');
        const lyricsCurrent = $('#fullscreen-lyrics-current-time');
        if (fullCurrent) fullCurrent.textContent = formatTime(audio.currentTime);
        if (lyricsCurrent) lyricsCurrent.textContent = formatTime(audio.currentTime);
        for (const seekId of ['seek', 'fullscreen-seek', 'fullscreen-lyrics-seek']) {
          if (seekId === event.target.id) continue;
          const otherSeek = $(`#${seekId}`);
          if (otherSeek) { otherSeek.value = String(Math.round(progress * 10)); otherSeek.style.setProperty('--progress', `${progress}%`); }
        }
        state.isSeeking = false;
      }
    } else if (event.target.id === 'volume') {
      const volume = Math.max(0, Math.min(1, Number(event.target.value) || 0));
      event.target.style.setProperty('--progress', `${volume * 100}%`);
      audio.volume = volume;
      if (state.settings.rememberVolume) state.settings.volume = volume;
      const volumeLabel = $('.settings-volume-value');
      if (volumeLabel) volumeLabel.textContent = `${Math.round(volume * 100)}%`;
    }
  });

  document.addEventListener('keydown', event => {
    const target = event.target;
    const typing = target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target?.isContentEditable;
    const modalOpen = Boolean($('#modal-root').children.length);
    if (event.key === 'Escape') {
      if (modalOpen) { event.preventDefault(); closeModal(); }
      return;
    }
    if (typing || modalOpen || event.altKey) return;

    const command = event.ctrlKey || event.metaKey;
    if (command && event.key.toLowerCase() === 'o') {
      event.preventDefault(); $('#audio-input').click(); return;
    }
    if (command && event.key.toLowerCase() === 'l') {
      event.preventDefault(); navigate('search'); $('#global-search').focus(); return;
    }
    if (command && event.key.toLowerCase() === 'q') {
      event.preventDefault(); openQueue(); return;
    }

    // Let focused buttons, links, selects, and other controls keep their native Space/Arrow behaviour.
    if (target?.closest?.('button, a, select, [role="button"]')) return;
    if (event.code === 'Space') { event.preventDefault(); togglePlay(); }
    if (event.code === 'ArrowRight' && currentSong()) { event.preventDefault(); audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 5); }
    if (event.code === 'ArrowLeft' && currentSong()) { event.preventDefault(); audio.currentTime = Math.max(0, audio.currentTime - 5); }
  });

  async function boot() {
    try {
      $('#volume').style.setProperty('--progress', `${Number($('#volume').value) * 100}%`);
      state.db = await openDatabase();
      // Retire the credential used by the removed 1.7 YouTube experiment.
      await dbRequest('settings', 'readwrite', store => store.delete('youtubeDataApiKey'));
      const savedPreferences = await dbRequest('settings', 'readonly', store => store.get('preferences'));
      state.settings = { ...state.settings, ...(savedPreferences?.value || {}) };
      if (!['midnight', 'amoled'].includes(state.settings.theme)) state.settings.theme = 'midnight';
      state.settings.hinglishLyrics = state.settings.hinglishLyrics !== false;
      if (!['violet', 'blue', 'rose', 'emerald'].includes(state.settings.accent)) state.settings.accent = 'violet';
      const savedVolume = Number(state.settings.volume);
      audio.volume = state.settings.rememberVolume && Number.isFinite(savedVolume) ? Math.max(0, Math.min(1, savedVolume)) : 0.8;
      $('#volume').value = String(audio.volume);
      $('#volume').style.setProperty('--progress', `${audio.volume * 100}%`);
      applySettings();
      await loadLibrary();
      const version = window.echoDesktop?.version || '1.9.7';
      document.title = `Echo Desktop ${version}`;
    } catch (error) {
      console.error(error);
      $('#view-content').innerHTML = emptyState('Could not open local storage', 'Your browser or system may be blocking IndexedDB. Restart the app and try again.', 'Retry', 'retry-db');
    }
  }

  document.addEventListener('click', event => {
    const action = event.target.closest('[data-action="retry-db"]');
    if (action) boot();
    const plus = event.target.closest('[data-action="add-to-queue"]');
    if (plus) event.stopPropagation();
  });

  boot();
})();
