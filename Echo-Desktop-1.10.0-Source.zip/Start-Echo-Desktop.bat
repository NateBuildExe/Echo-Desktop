@echo off
setlocal
cd /d "%~dp0"
title Echo Desktop 1.10.0

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install Node.js 22 LTS or newer from https://nodejs.org/ and restart this file.
  pause
  exit /b 1
)

for /f "tokens=1 delims=." %%v in ('node -p "process.versions.node.split('.')[0]"') do set NODE_MAJOR=%%v
if "%NODE_MAJOR%"=="" set NODE_MAJOR=0
if %NODE_MAJOR% LSS 20 (
  echo Echo requires Node.js 20 or newer. Install Node.js 22 LTS or newer.
  pause
  exit /b 1
)

if not exist "node_modules\electron\dist\electron.exe" (
  echo First-time setup: installing Echo Desktop runtime.
  echo This step needs an internet connection and may take a few minutes.
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo Setup failed. Check your internet connection, then run this file again.
    pause
    exit /b 1
  )
)

echo Starting Echo Desktop...
call npm start
if errorlevel 1 (
  echo.
  echo Echo Desktop stopped with an error. Review the message above.
  pause
)
endlocal
