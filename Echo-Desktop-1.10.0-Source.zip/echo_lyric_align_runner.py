#!/usr/bin/env python3
"""Align user-supplied lyric lines to local audio and emit LRC timestamps.

The recognizer's guessed words are never returned or saved. Only the lyric text
provided to this tool is written into the output file.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


def lyric_lines(path: Path) -> list[str]:
    output: list[str] = []
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = re.sub(r"\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?\]", "", raw).strip()
        line = re.sub(r"<\d{1,2}:\d{2}(?:[.:]\d{1,3})?>", "", line).strip()
        if not line or line.startswith("#"):
            continue
        if re.match(r"^\[(?:ar|ti|al|by|re|ve|length|offset):", line, re.I):
            continue
        # Section headings are not spoken lyrics.
        if re.fullmatch(r"\[(?:verse|chorus|bridge|hook|intro|outro|pre.?chorus)(?:\s+\d+)?\]", line, re.I):
            continue
        output.append(line)
    return output


def emit_progress(percent: int, message: str) -> None:
    print('ECHO_ALIGNMENT_PROGRESS:' + json.dumps({
        'percent': max(0, min(100, int(percent))),
        'message': message,
    }, ensure_ascii=False), flush=True)


def transcribe(model, audio_path: Path, language: str | None, use_vad: bool, progress_start: int, progress_end: int):
    segments_iter, info = model.transcribe(
        str(audio_path),
        language=language,
        beam_size=3,
        word_timestamps=True,
        vad_filter=use_vad,
        condition_on_previous_text=False,
    )
    segments = []
    duration = float(getattr(info, 'duration', 0.0) or 0.0)
    last_bucket = -1
    for segment in segments_iter:
        words = []
        for word in segment.words or []:
            if word.start is not None and word.end is not None:
                words.append({"start": float(word.start), "end": float(word.end), "word": word.word})
        segments.append({
            "start": float(segment.start),
            "end": float(segment.end),
            "text": str(segment.text or "").strip(),
            "words": words,
        })
        if duration > 0:
            ratio = min(1.0, max(0.0, float(segment.end) / duration))
            percent = progress_start + (progress_end - progress_start) * ratio
            bucket = int(percent // 2)
            if bucket > last_bucket:
                last_bucket = bucket
                emit_progress(round(percent), f'Analyzing vocals and timing the audio… {round(ratio * 100)}% of the track scanned')
        elif len(segments) % 20 == 0:
            percent = min(progress_end - 1, progress_start + len(segments) // 20)
            emit_progress(percent, f'Analyzing vocals and timing the audio… {len(segments)} audio segments checked')
    return segments, getattr(info, "language", None)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audio", required=True, type=Path)
    parser.add_argument("--lyrics", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--language", default="auto", choices=("auto", "en", "hi", "ur", "pa"))
    parser.add_argument("--model", default="tiny", choices=("tiny", "base"))
    args = parser.parse_args()

    lines = lyric_lines(args.lyrics)
    if not lines:
        print("No usable lyric lines were found in the editor text.", file=sys.stderr)
        return 2

    emit_progress(5, 'Loading the local alignment libraries…')
    try:
        from faster_whisper import WhisperModel
        from lyric_align import Segment, align
    except ImportError as exc:
        print(
            "The local alignment packages are not installed. Close Echo and run "
            "Install-Echo-Lyric-Aligner.bat, then reopen Echo. "
            f"Details: {exc}",
            file=sys.stderr,
        )
        return 3

    emit_progress(9, f'Loading Whisper {args.model} on the CPU… The first run may download this model.')
    print(f"Loading Whisper {args.model} on CPU (int8)…", file=sys.stderr)
    model = WhisperModel(args.model, device="cpu", compute_type="int8")
    language = None if args.language == "auto" else args.language

    emit_progress(17, 'Whisper is ready. Analyzing the song and estimating vocal timings…')
    print("Analysing vocals with voice-activity detection…", file=sys.stderr)
    raw_segments, detected_language = transcribe(model, args.audio, language, True, 18, 68)
    segments = [Segment.from_dict(item) for item in raw_segments]
    emit_progress(70, 'Matching the audio timing to the lyrics you supplied…')
    aligned = align(segments, lines, pairing="auto", karaoke=False)
    matched = sum(1 for item in aligned if item.matched and item.start is not None)

    # Slow or sustained singing can be mistaken for silence. Retry without VAD
    # only when the first pass fails to place enough supplied lines.
    retry_threshold = max(1, round(len(lines) * 0.35))
    if matched < retry_threshold:
        emit_progress(73, 'Few lines matched on the first pass. Trying a second pass for sustained vocals…')
        print("Few lines matched; retrying without voice-activity filtering for sustained vocals…", file=sys.stderr)
        raw_retry, retry_language = transcribe(model, args.audio, language, False, 74, 90)
        retry_segments = [Segment.from_dict(item) for item in raw_retry]
        retry_aligned = align(retry_segments, lines, pairing="auto", karaoke=False)
        retry_matched = sum(1 for item in retry_aligned if item.matched and item.start is not None)
        if retry_matched > matched:
            aligned, matched, detected_language = retry_aligned, retry_matched, retry_language or detected_language

    emit_progress(93, f'Writing timestamps for {matched} matched lines…')
    # Preserve all supplied lyric text: matched lines get timestamps; unmatched
    # lines remain untimed for manual review instead of being silently dropped.
    output_lines = []
    for item in aligned:
        if item.start is not None and item.matched:
            minutes = int(item.start // 60)
            seconds = item.start - minutes * 60
            output_lines.append(f"[{minutes:02d}:{seconds:05.2f}]{item.line}")
        else:
            output_lines.append(item.line)
    args.output.write_text("\n".join(output_lines) + "\n", encoding="utf-8")
    emit_progress(98, 'Timestamp preview written. Checking the matched-line count…')

    if not matched:
        print("No lyric lines could be confidently matched. Try Base, choose a specific language, or use a different lyric version.", file=sys.stderr)
    print("ECHO_ALIGNMENT_RESULT:" + json.dumps({
        "matchedLines": matched,
        "totalLines": len(lines),
        "languageDetected": detected_language,
    }, ensure_ascii=False), flush=True)
    if matched:
        emit_progress(95, f'Alignment finished: {matched} of {len(lines)} lyric lines matched; preparing the preview…')
    return 0 if matched else 4


if __name__ == "__main__":
    raise SystemExit(main())
