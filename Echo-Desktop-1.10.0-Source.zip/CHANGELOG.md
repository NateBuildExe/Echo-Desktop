# Echo Desktop Changelog

## 1.10.0 — Final planned release
- Fixed the local lyric-align setup flow by placing all Python packages in a project-local virtual environment and making Echo invoke the exact verified interpreter.
- Made the installer select a supported 64-bit Python, explicitly install and verify `faster-whisper` and `lyric-align`, keep its window open until acknowledged, and save a diagnostic log.
- Added live lyric-alignment progress from model loading through audio scanning, line matching, and preview creation. The editor shows a percentage and matched-line result so it is clear when alignment has started and finished.
- Kept fullscreen lyrics scrollable while clipping the native scrollbar track, including Chromium scrollbars.
- SoundCloud search is not enabled in this build: the official API requires registered app credentials, and oEmbed cannot search for tracks. No unofficial scraping or embedded third-party credentials were added.
- Kept Electron 45.3.2, npm dependencies, IndexedDB database name/schema, and local origin unchanged.

## 1.9.9
- Added streamed lyric-alignment progress and the fullscreen scrollbar clipping layer.
- Documented the absence of SoundCloud keyword search without official API app credentials.

## 1.9.7
- Added multi-provider synced lyrics lookup using the YouLy+ / LyricsPlus backend, KuGou through Better Lyrics API, and LRCLIB fallback.
- Normalized LyricsPlus structured KPOE-style millisecond lyric timestamps and KuGou LRC-style responses into Echo's lyric editor format.
- Added provider labels and synchronization-quality labels to lyric search results; word/syllable source matches rank before line-synced and plain-text matches.
- Added the primary LyricsPlus host and published mirrors as sequential fallbacks. A failed host does not block KuGou or LRCLIB results.
- Kept lyric fetching separate from metadata and audio import; only title, artist, album, and duration are sent for lookup. Audio files are not uploaded.
- Kept the existing IndexedDB name/schema, local origin, and Electron 45.3.2 unchanged.

## 1.9.6
- Fixed Search results not rendering (the view referenced an undefined query variable) and attached direct input/search/Enter handling to the persistent search field.
- Added robust multi-term local search across title, artist, album, album artist, genre, and filename, with accent normalization and Hinglish aliases for Devanagari metadata.
- Stabilized shuffle as one prepared queue order used by the queue panel, Next, and Previous. Previous now returns to the previous queue item even when more than three seconds have elapsed.
- Prevented clicking the already-current paused track's thumbnail from rebuilding the shuffled order; it now resumes playback in place.
- Added scroll-in-place handling for full-screen lyrics and automatic centering within the lyrics viewport. Manual wheel, touch, or scrollbar interaction pauses auto-follow; Follow active resumes it.
- Retained clickable timestamped lyric lines and synchronized full-screen lyrics timeline with Show/Hide timeline control.
- Added per-track lyric timing offset (±15 seconds) and rate/drift adjustment (85–115%) without rewriting the original LRC data. Manual timestamp stamping accounts for the selected correction; a reset control restores defaults.
- Ensured library and playlist rows play only from the thumbnail play button.
- Widened the metadata editor and alternate-query field; added title-only MusicBrainz lookups for the main/alternate title and unconditional US Apple/iTunes storefront fallback.
- Preserved IndexedDB name/schema, local origin, and Electron 45.3.2.

## 1.9.5
- Moved artwork click handling to the permanent Now Playing container in capture phase, so image-button replacement cannot disconnect the fullscreen action. Added a dedicated fixed overlay root above the entire app.
- Re-layered the blurred visualizer over the lower artwork area and delayed initial drawing until the fullscreen canvas is measured.
- Added Roman Hinglish transliteration for Devanagari lyric display, with a Settings toggle. Saved lyric text and LRC timestamps are preserved.
- Ranked timestamped lyric results above plain text and clearly labelled plain results as unsynchronized.
- Corrected the playlist grid so duration and row actions occupy separate fixed-width columns, with tighter responsive layouts.
- Moved Settings directly beneath Your Library in the primary left navigation.


## 1.9.8
- Added optional local alignment of existing lyric text against locally imported audio with `lyric-align` / `faster-whisper`.
- Added a bundled Python runner so Auto language mode uses actual faster-whisper language detection instead of inheriting the aligner CLI Japanese default.
- Added Tiny (fast) and Base (balanced) model choices, a retry without voice-activity filtering for sustained singing, and preservation of unmatched lyric lines as untimed text.
- Added language choice: Auto, English, Hindi, Urdu, Punjabi.
- Alignment results are staged for review; low-confidence lines remain unmatched rather than receiving guessed timestamps.
- Added optional setup script; no audio upload.
- Does not generate missing copyrighted lyrics; provider search and user-supplied text remain the source of lyric words.
