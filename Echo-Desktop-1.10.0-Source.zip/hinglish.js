(function attachEchoHinglish(root) {
  'use strict';

  // A practical Hindi-to-Roman transliterator for lyric display. Original
  // lyrics are never modified; only the text rendered by the UI is converted.
  const vowels = {
    'अ': 'a', 'आ': 'aa', 'इ': 'i', 'ई': 'i', 'उ': 'u', 'ऊ': 'u',
    'ऋ': 'ri', 'ॠ': 'ri', 'ऌ': 'li', 'ए': 'e', 'ऐ': 'ai', 'ओ': 'o', 'औ': 'au'
  };
  const matras = {
    'ा': 'aa', 'ि': 'i', 'ी': 'i', 'ु': 'u', 'ू': 'u', 'ृ': 'ri',
    'ॄ': 'ri', 'े': 'e', 'ै': 'ai', 'ो': 'o', 'ौ': 'au', 'ॅ': 'e', 'ॉ': 'o'
  };
  const consonants = {
    'क': 'k', 'ख': 'kh', 'ग': 'g', 'घ': 'gh', 'ङ': 'ng', 'च': 'ch', 'छ': 'chh',
    'ज': 'j', 'झ': 'jh', 'ञ': 'ny', 'ट': 't', 'ठ': 'th', 'ड': 'd', 'ढ': 'dh',
    'ण': 'n', 'त': 't', 'थ': 'th', 'द': 'd', 'ध': 'dh', 'न': 'n', 'प': 'p',
    'फ': 'ph', 'ब': 'b', 'भ': 'bh', 'म': 'm', 'य': 'y', 'र': 'r', 'ल': 'l',
    'व': 'v', 'श': 'sh', 'ष': 'sh', 'स': 's', 'ह': 'h', 'ळ': 'l'
  };
  const nuktaOverrides = { 'क': 'q', 'ख': 'kh', 'ग': 'gh', 'ज': 'z', 'ड': 'r', 'ढ': 'rh', 'फ': 'f' };
  const digits = { '०': '0', '१': '1', '२': '2', '३': '3', '४': '4', '५': '5', '६': '6', '७': '7', '८': '8', '९': '9' };

  // Everyday spellings take priority over mechanical transliteration. This
  // keeps common lyric words in the familiar Hinglish form (hi, nahi, dil).
  const commonWords = {
    'ही': 'hi', 'नहीं': 'nahi', 'नही': 'nahi', 'है': 'hai', 'हैं': 'hain',
    'हूँ': 'hoon', 'हूं': 'hoon', 'हो': 'ho', 'मैं': 'main', 'मेरा': 'mera',
    'मेरी': 'meri', 'मेरे': 'mere', 'तुम': 'tum', 'तुमसे': 'tumse', 'तुम्हें': 'tumhein',
    'तुझे': 'tujhe', 'तुझसे': 'tujhse', 'मुझे': 'mujhe', 'मुझसे': 'mujhse',
    'हम': 'hum', 'हमसे': 'humse', 'हमें': 'humein', 'तू': 'tu', 'तेरा': 'tera',
    'तेरी': 'teri', 'तेरे': 'tere', 'प्यार': 'pyaar', 'दिल': 'dil', 'ज़िंदगी': 'zindagi',
    'जिंदगी': 'zindagi', 'ज़िन्दगी': 'zindagi', 'जिन्दगी': 'zindagi', 'दुनिया': 'duniya',
    'मोहब्बत': 'mohabbat', 'इश्क': 'ishq', 'इश्क़': 'ishq', 'रात': 'raat',
    'रातें': 'raatein', 'रातों': 'raaton', 'आँख': 'aankh', 'आंख': 'aankh',
    'आँखें': 'aankhein', 'आंखें': 'aankhein', 'आँखों': 'aankhon', 'आंखों': 'aankhon',
    'साँस': 'saans', 'सांस': 'saans', 'ख्वाब': 'khwaab', 'ख़्वाब': 'khwaab',
    'सपने': 'sapne', 'अपना': 'apna', 'अपने': 'apne', 'अपनी': 'apni', 'याद': 'yaad',
    'यादें': 'yaadein', 'बात': 'baat', 'बातें': 'baatein', 'क्यों': 'kyun',
    'कहाँ': 'kahan', 'कहां': 'kahan', 'कौन': 'kaun', 'क्या': 'kya', 'कैसे': 'kaise',
    'जैसे': 'jaise', 'ऐसे': 'aise', 'वैसे': 'waise', 'कभी': 'kabhi', 'अभी': 'abhi',
    'हमेशा': 'hamesha', 'अगर': 'agar', 'मगर': 'magar', 'लेकिन': 'lekin', 'रहना': 'rehna',
    'रहने': 'rehne', 'रहे': 'rahe', 'रही': 'rahi', 'रहा': 'raha', 'जाना': 'jaana',
    'जाने': 'jaane', 'जाऊँ': 'jaaun', 'जाऊं': 'jaaun', 'आना': 'aana', 'आए': 'aaye',
    'होना': 'hona', 'होगा': 'hoga', 'होगी': 'hogi', 'करना': 'karna', 'करूँ': 'karun',
    'करूं': 'karun', 'करता': 'karta', 'करती': 'karti', 'करते': 'karte', 'कहना': 'kehna',
    'कहूँ': 'kahun', 'कहूं': 'kahun', 'सुनना': 'sunna', 'सुनो': 'suno', 'बोलना': 'bolna',
    'बोलो': 'bolo', 'चलना': 'chalna', 'चलो': 'chalo', 'फिर': 'phir', 'भी': 'bhi',
    'ना': 'na', 'बस': 'bas', 'तो': 'to', 'पर': 'par', 'और': 'aur', 'से': 'se',
    'को': 'ko', 'की': 'ki', 'के': 'ke', 'का': 'ka', 'में': 'mein', 'तक': 'tak',
    'साथ': 'saath', 'बिना': 'bina', 'लिए': 'liye', 'नमस्ते': 'namaste',
    'खुशी': 'khushi', 'ज़रा': 'zara', 'जरा': 'zara', 'वक्त': 'waqt', 'समय': 'samay'
  };

  function transliterateWord(word) {
    if (Object.hasOwn(commonWords, word)) return commonWords[word];
    let output = '';
    const chars = Array.from(word);
    for (let i = 0; i < chars.length; i++) {
      const ch = chars[i];
      if (Object.hasOwn(consonants, ch)) {
        let consonant = consonants[ch];
        if (chars[i + 1] === '़') {
          consonant = nuktaOverrides[ch] || consonant;
          i++;
        }
        output += consonant;
        const next = chars[i + 1];
        if (Object.hasOwn(matras, next)) {
          output += matras[next];
          i++;
        } else if (next === '्') {
          i++;
        } else {
          output += 'a';
        }
        continue;
      }
      if (Object.hasOwn(vowels, ch)) output += vowels[ch];
      else if (ch === 'ं' || ch === 'ँ') output += 'n';
      else if (ch === 'ः') output += 'h';
      else if (ch === '़' || ch === '्' || ch === '‍' || ch === '‌') continue;
      else if (Object.hasOwn(digits, ch)) output += digits[ch];
      else if (ch === '।') output += '.';
      else output += ch;
    }
    // Drop the final inherent schwa in common Hindi word forms.
    return output.replace(/a$/i, '');
  }

  function toHinglish(value) {
    const source = String(value ?? '');
    if (!/[\u0900-\u097F]/.test(source)) return source;
    return source.replace(/[\u0900-\u097F]+/g, token => transliterateWord(token));
  }

  const api = Object.freeze({ toHinglish });
  root.echoHinglish = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
