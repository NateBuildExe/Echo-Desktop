const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { EventEmitter } = require('node:events');
const Module = require('node:module');

const project = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(project, 'index.html'), 'utf8');
const appJs = fs.readFileSync(path.join(project, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(project, 'styles.css'), 'utf8');
const mainJs = fs.readFileSync(path.join(project, 'main.js'), 'utf8');
const preloadJs = fs.readFileSync(path.join(project, 'preload.js'), 'utf8');
const installGuide = fs.readFileSync(path.join(project, 'INSTALLATION-GUIDE.txt'), 'utf8');
const alignRunner = fs.readFileSync(path.join(project, 'echo_lyric_align_runner.py'), 'utf8');
const metadataJs = fs.readFileSync(path.join(project, 'metadata-service.js'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(project, 'package.json'), 'utf8'));
const hinglish = require(path.join(project, 'hinglish.js'));
assert.equal(hinglish.toHinglish('तुमसे ही प्यार करना'), 'tumse hi pyaar karna');
assert.equal(hinglish.toHinglish('मैं तुमसे प्यार करता हूँ'), 'main tumse pyaar karta hoon');
assert.equal(hinglish.toHinglish('[00:01.20] नहीं है'), '[00:01.20] nahi hai', 'timestamps and punctuation should survive display transliteration');
assert.equal(hinglish.toHinglish('नमस्ते दुनिया'), 'namaste duniya');
assert.equal(hinglish.toHinglish('Hello world'), 'Hello world', 'non-Devanagari text should remain untouched');

for (const id of ['audio-engine', 'audio-input', 'folder-input', 'global-search', 'now-title', 'lyrics-display', 'seek', 'volume', 'sidebar-playlists']) {
  assert.match(html, new RegExp(`id=["']${id}["']`), `missing UI node #${id}`);
}
assert.doesNotMatch(html, /youtube|music\.youtube\.com/i, 'YouTube UI should be removed');
assert.doesNotMatch(appJs, /YouTube Music|YT\.Player|EchoYouTube|youtube-search/i, 'renderer should no longer contain online playback code');
assert.match(appJs, /delete\('youtubeDataApiKey'\)/, 'the obsolete 1.7 API key should be retired from local settings');
assert.doesNotMatch(css, /youtube-view|youtube-player|online-player-note/i, 'old online-player styling should be removed');
assert.match(appJs, /data-action="fetch-metadata"/);
assert.match(appJs, /data-action="fetch-lyrics"/);
assert.ok(appJs.includes('wider MusicBrainz and Apple Music catalog'));
assert.match(appJs, /id=\"metadata-extra-query\"/);
assert.match(appJs, /fetchMetadataArtwork\(\{ releaseId: match\.releaseId/);
assert.match(metadataJs, /ITUNES_ROOT/);
assert.match(metadataJs, /LYRICSPLUS_ROOTS/);
assert.match(metadataJs, /KUGOU_LYRICS_ROOT/);
assert.match(metadataJs, /v2\/lyrics\/get/);
assert.match(metadataJs, /kugou\/getLyrics/);
assert.match(metadataJs, /searchLrcLibLyrics/);
assert.match(appJs, /Searching YouLy\+ \/ LyricsPlus, KuGou and LRCLIB/);
assert.match(appJs, /Word\/syllable-timed source · Echo imports line start times/);

assert.match(metadataJs, /searchAppleCatalog/);
assert.match(metadataJs, /recording\/\$\{encodeURIComponent\(summary\.id\)\}/);
assert.match(metadataJs, /releases\+artist-credits\+genres\+tags/);
assert.match(appJs, /\$\('#audio-input'\)\.addEventListener\('change', handleAudioInputChange\)/, 'audio picker must invoke the import flow');
assert.match(appJs, /\$\('#folder-input'\)\.addEventListener\('change', handleAudioInputChange\)/, 'folder picker must invoke the import flow');
assert.match(appJs, /async function handleAudioInputChange/);
assert.match(appJs, /const audioMimeType =/);
assert.match(appJs, /pendingBulkPlaylistAdd/);
assert.match(appJs, /data-action="toggle-selection"/);
assert.match(appJs, /data-action="add-selected-to-playlist"/);
assert.match(appJs, /data-action="delete-selected-songs"/);
assert.match(appJs, /value="mostPlayed"/);
assert.match(appJs, /value="dateAdded"/);
assert.match(appJs, /value="title"/);
assert.match(appJs, /apply-metadata-match/);
assert.match(appJs, /apply-lyrics-match/);
assert.match(appJs, /parseLrc\(song\.lyricsText\)/);
assert.match(appJs, /state\.pendingArtworkBlob/);
assert.match(appJs, /state\.currentEditorSongId/);
assert.match(appJs, /data-queue-id=/);
assert.match(appJs, /queue-drag-handle/);
assert.match(appJs, /document\.addEventListener\('dragstart'/);
assert.match(appJs, /document\.addEventListener\('dragover'/);
assert.match(appJs, /document\.addEventListener\('drop'/);
assert.doesNotMatch(appJs, /move-queue-up/);
assert.match(appJs, /class="now-art-open" type="button"/, 'the artwork tile should expose a stable button click target');
assert.match(appJs, /data-song-id=\"\$\{escapeHtml\(song\.id\)\}\"/, 'artwork button must carry the active song id');
assert.match(appJs, /\$\('#now-art'\)\.addEventListener\('click',[\s\S]*?\}, true\);/, 'artwork click must be delegated from the stable parent in capture phase');
assert.doesNotMatch(appJs, /\$\('\.now-art-open',\s*artHost\)\.addEventListener/, 'artwork click should not depend on a replaceable child listener');
assert.match(appJs, /root\.classList\.add\('fullscreen-root'\)/, 'fullscreen must use a dedicated top-level root');
assert.match(css, /#modal-root\.fullscreen-root\{position:fixed;inset:0;z-index:10000/, 'fullscreen root must cover the viewport above the app');
assert.match(css, /\.now-art-open\{cursor:pointer!important/, 'artwork should use a normal pointer cursor, not zoom-in');
assert.match(html, /data-action="fullscreen-lyrics"/);
assert.match(html, /data-view="settings"/, 'Settings should be reachable from left navigation');
assert.match(html, /<script src="hinglish\.js"><\/script>/, 'Hinglish transliteration must load before the app renderer');
assert.ok(html.indexOf('data-view="settings"') < html.indexOf('class="nav-separator"'), 'Settings should sit in the primary navigation before the separator');
assert.match(appJs, /function renderNowArtwork\(song\)/, 'artwork should have an isolated renderer');
assert.match(appJs, /renderNowArtwork\(song\)/, 'player updates should preserve the artwork control rather than rebuilding it');
assert.match(appJs, /renderedArtworkBlob === artworkBlob/, 'artwork should only redraw when the song or cover changes');
assert.match(appJs, /data-setting="hinglishLyrics"/, 'Hinglish lyrics preference should be configurable');
assert.match(appJs, /lyricDisplayText\(line\.text\)/, 'synced lyrics should render in Hinglish when enabled');
assert.match(appJs, /lyricDisplayText\(excerpt\)/, 'online lyric match previews should also display in Hinglish');
assert.match(appJs, /Plain lyrics · not synchronized/, 'plain-only results should be clearly marked unsynchronized');
assert.match(metadataJs, /syncRank = \{ word: 0, line: 1, plain: 2, none: 3 \}/, 'lyric providers should be ranked by sync precision');
assert.match(metadataJs, /searchLyricsPlus\(normalizedInput\)/, 'LyricsPlus provider should be queried');
assert.match(metadataJs, /searchKugouLyrics\(normalizedInput\)/, 'KuGou provider should be queried');
assert.match(metadataJs, /searchLrcLibLyrics\(normalizedInput\)/, 'LRCLIB should remain the final fallback');
assert.match(appJs, /has-remove-action/, 'playlist rows need a separate responsive layout for the remove action');
assert.match(css, /\.track-row\.has-remove-action/, 'playlist duration and controls must have non-overlapping columns');
assert.match(css, /grid-template-columns:22px 38px minmax\(0,1\.35fr\) minmax\(72px,\.8fr\) 52px 110px/, 'playlist actions must have a dedicated fixed-width column');
assert.match(css, /\.now-art-open:hover \.now-art-image\{transform:none!important;filter:none!important\}/, 'artwork hover should not animate or flicker');
assert.match(css, /\.artwork-visualizer-layer\{z-index:3/, 'visualizer must overlay the bottom of the artwork instead of hiding behind the cover');

assert.match(html, /i-settings/, 'Settings icon should be present');
assert.match(appJs, /function renderSettings\(\)/);
assert.match(appJs, /saveSettings\(\)/);
assert.match(appJs, /key: 'preferences'/, 'preferences should be persisted in the existing settings store');
assert.match(appJs, /fullscreen-seek/, 'artwork full-screen view should have a seek control');
assert.match(appJs, /fullscreen-timeline-pill/);
assert.match(appJs, /function ensureVisualizerAudioGraph/);
assert.match(appJs, /createMediaElementSource\(audio\)/, 'visualizer should analyse the local audio element');
assert.match(appJs, /function startArtworkVisualizer/);
assert.match(appJs, /visualizerStyle === 'wave'/);
assert.match(css, /\.settings-page-grid/);
assert.match(css, /\.fullscreen-timeline-pill/);
assert.match(css, /#artwork-visualizer/);
assert.match(css, /\.hero\{height:252px/);
assert.match(appJs, /function openArtworkFullscreen/);
assert.match(appJs, /function openLyricsFullscreen/);
assert.match(appJs, /renderFullscreenLyrics\(song, lyrics, active\)/);
assert.match(appJs, /data-action=\"seek-lyric\"/);
assert.match(appJs, /lyricsOffsetMs/);
assert.match(appJs, /lyricsRate/);
assert.match(appJs, /Timing drift \/ speed/);
assert.match(appJs, /Below 100% moves later lines progressively earlier/);
assert.match(appJs, /data-action="reset-lyrics-timing"/);
assert.match(appJs, /scrollHost\.scrollTo\(\{ top: targetTop, behavior: 'smooth' \}\)/, 'fullscreen lyrics auto-follow should scroll inside its own viewport');
assert.match(appJs, /addEventListener\('touchmove'/, 'touch scrolling should suspend auto-follow');
assert.match(appJs, /fullscreen-lyrics-scroll.*pointerdown|fullscreen-lyrics-scroll'\)\?\.addEventListener\('pointerdown'/, 'dragging the scrollbar should disable auto-follow');
assert.match(appJs, /fullscreen-lyrics-timeline/);
assert.match(appJs, /fullscreen-lyrics-seek/);
assert.match(appJs, /fullscreen-lyrics-play-btn/);
assert.match(appJs, /fullscreenLyricsAutoFollow/);
assert.match(css, /\.fullscreen-lyric-line\.is-empty/);
assert.match(css, /\.lyrics-display\{min-height:185px/);
assert.match(css, /\.fullscreen-stage\{/);
assert.match(css, /\.fullscreen-lyric-line\.is-active/);
assert.match(css, /\.queue-drag-handle/);
assert.match(preloadJs, /echo:metadata-search/);
assert.match(preloadJs, /echo:metadata-artwork/);
assert.match(preloadJs, /echo:lyrics-search/);
assert.match(preloadJs, /echo:lyrics-align/);
assert.match(preloadJs, /onAlignmentProgress/);
assert.match(preloadJs, /echo:lyrics-align-progress/);
assert.match(mainJs, /ipcMain\.handle\('echo:lyrics-align'/);
assert.match(mainJs, /echo:lyrics-align-progress/);
assert.match(mainJs, /ECHO_ALIGNMENT_PROGRESS:/);
assert.match(appJs, /async function autoAlignKnownLyrics\(\)/);
assert.match(appJs, /onAlignmentProgress/);
assert.match(appJs, /Finished · \${result\.matchedLines} of \${result\.totalLines} lyric lines matched/);
assert.match(appJs, /role=\"progressbar\"/);
assert.match(appJs, /data-action=\"auto-align-lyrics\"/);
assert.match(mainJs, /echo_lyric_align_runner\.py/);
assert.match(mainJs, /\.echo-lyric-venv/ , 'Windows alignment must use Echo private venv');
assert.match(mainJs, /import faster_whisper; import lyric_align/, 'preflight must verify alignment imports in the same interpreter');
assert.match(mainJs, /const pythonCommand = localPython/, 'the runner must use the verified Python interpreter');
const alignInstaller = fs.readFileSync(path.join(project, 'Install-Echo-Lyric-Aligner.bat'), 'utf8');
assert.match(alignInstaller, /-m venv/ , 'installer must create an isolated environment');
assert.match(alignInstaller, /lyric-align\[asr\]==0\.4\.2/);
assert.match(alignInstaller, /"faster-whisper"/ , 'installer must explicitly install faster-whisper');
assert.match(alignInstaller, /import faster_whisper; import lyric_align/, 'installer must verify both packages');
assert.match(alignInstaller, /Echo-Lyric-Aligner-Setup\.log/ , 'installer must write a diagnostic log');
assert.match(alignInstaller, /pause >nul/ , 'installer must remain open until acknowledged');

assert.ok(alignRunner.includes('language = None if args.language == \"auto\" else args.language'), 'Auto detect must pass None to faster-whisper');
assert.match(alignRunner, /WhisperModel\(args\.model, device=\"cpu\", compute_type=\"int8\"\)/);
assert.match(alignRunner, /retrying without voice-activity filtering/);
assert.match(alignRunner, /word_timestamps=True/);
assert.match(alignRunner, /voice-activity filtering/);
assert.match(alignRunner, /unmatched/);
assert.match(installGuide, /Fast · Tiny/);
assert.match(installGuide, /Balanced · Base/);
assert.match(alignRunner, /item\.line/);
assert.match(appJs, /id=\"lyrics-align-model\"/);
assert.ok(appJs.includes("model: $('#lyrics-align-model', modal)?.value || 'tiny'"), 'alignment model selection must be passed to the local runner');
assert.match(installGuide, /faster-whisper/);
assert.match(css, /scrollbar-width:none!important/);
assert.match(css, /fullscreen-lyrics-scroll-clip/);
assert.match(css, /width:calc\(100% \+ 32px\)/);
assert.match(css, /overflow:hidden;position:relative/);
assert.match(css, /::-webkit-scrollbar\{display:none!important/);
assert.match(mainJs, /ipcMain\.handle\('echo:metadata-search'/);
assert.match(mainJs, /ipcMain\.handle\('echo:lyrics-search'/);
assert.match(mainJs, /reference\?\.artworkUrl/);
assert.match(mainJs, /frame-src 'none'/);
assert.doesNotMatch(mainJs, /youtube|googleapis\.com/i);
assert.equal(pkg.version, '1.10.0');
assert.equal(pkg.devDependencies.electron, '45.3.2', 'keep the same Electron version so existing node_modules can be reused');
assert.match(preloadJs, /version: '1\.10\.0'/);
assert.match(appJs, /class=\"now-art-open\" type=\"button\"/, 'the full cover should be a click target');
assert.match(appJs, /async function activateArtworkVisualizer/);
assert.match(appJs, /data-action=\"toggle-visualizer\"/);
assert.match(appJs, /artwork-visualizer-status/);
assert.match(appJs, /fullscreen-artwork-placeholder/, 'full-screen view should still open when a song has no cover art');
assert.match(css, /\.now-art-open\{/, 'the cover image should be a visible expand button');
assert.match(css, /\.fullscreen-visualizer-toggle/);
assert.match(appJs, /function toast\(message, duration = 2900\)/, 'toast should support persistent progress updates');
assert.match(appJs, /Importing \$\{index \+ 1\} of \$\{files.length\}/, 'bulk imports should show progress');
assert.match(appJs, /fileModifiedAt/, 'imports should use last-modified metadata to reduce filename collisions');
assert.match(appJs, /window.setTimeout\(\(\) => finish\(0\), 12000\)/, 'duration probing should time out for damaged files');
assert.match(appJs, /now-like'\)\.disabled = !song/, 'like action should be disabled when nothing is playing');
assert.match(appJs, /state.settings.defaultLibrarySort = state.librarySort/, 'manual sort choice should become the saved default');
assert.match(appJs, /event.key.toLowerCase\(\) === 'o'/, 'Ctrl+O should import songs');
assert.match(appJs, /event.key.toLowerCase\(\) === 'l'/, 'Ctrl+L should focus library search');
assert.match(appJs, /event.key.toLowerCase\(\) === 'q'/, 'Ctrl+Q should open the queue');
assert.match(appJs, /globalSearchInput\.addEventListener\('input'/, 'global search must bind directly to input events');
assert.match(appJs, /globalSearchInput\.addEventListener\('search'/, 'clear/search events must also refresh results');
assert.match(appJs, /function normalizeLibrarySearch/);
assert.match(appJs, /const body = terms\.length/, 'search view must use the normalized query term list');
assert.doesNotMatch(appJs, /const body = term\s/, 'search view must not reference an undefined term variable');
assert.match(appJs, /function buildShuffledQueue/);
assert.match(appJs, /state.shuffleQueueBase/);
assert.match(appJs, /function toggleShuffle/);
assert.doesNotMatch(appJs.slice(appJs.indexOf('function nextTrack'), appJs.indexOf('function previousTrack')), /Math\.random/, 'next track must follow the prepared fixed shuffle order');
assert.match(appJs.slice(appJs.indexOf('function previousTrack'), appJs.indexOf('async function ensureVisualizerAudioGraph')), /playSong\(ids\[index - 1\]\)/, 'Previous should return to the preceding fixed queue item');
assert.doesNotMatch(appJs.slice(appJs.indexOf('function previousTrack'), appJs.indexOf('async function ensureVisualizerAudioGraph')), /audio\.currentTime > 3/, 'Previous should not just restart the current song after three seconds');
assert.match(appJs, /if \(id === state\.currentSongId\) \{ if \(audio\.paused\) togglePlay\(\); else audio\.pause\(\); \}/, 'restarting the current row must not rebuild the shuffled order');
assert.match(appJs, /data-action=\"play-row-song\"/, 'track row must expose an explicit thumbnail play button');
assert.doesNotMatch(appJs, /handleRowClick/, 'clicking a row title must not start playback');
assert.match(appJs, /data-action=\"toggle-lyrics-timeline\"/);
assert.match(appJs, /data-action=\"follow-lyrics\"/);
assert.match(appJs, /metadata-editor-modal/);
assert.match(metadataJs, /limit: '50'/, 'metadata catalogue search should examine more results');
assert.match(metadataJs, /extraQuery/);
assert.match(metadataJs, /Always add title-only searches for the main and first alternate title/);
assert.match(metadataJs, /Always check the US storefront in addition to India/);
assert.match(mainJs, /extraQuery: String\(input\?\.extraQuery \|\| ''\)/);
assert.match(appJs, /target\?\.closest\?\.\('button, a, select, \[role="button"\]'\)/, 'keyboard shortcuts must not hijack focused controls');
assert.match(appJs, /<h2>Keyboard shortcuts<\/h2>/, 'shortcuts should be documented in Settings');
assert.match(appJs, /navigator\.storage\?\.estimate/, 'Settings should show an on-device storage estimate when supported');
assert.match(appJs, /id="storage-usage"/, 'storage usage status should be visible in Settings');

for (const [file, source] of [['app.js', appJs], ['metadata-service.js', metadataJs], ['main.js', mainJs], ['preload.js', preloadJs], ['hinglish.js', fs.readFileSync(path.join(project, 'hinglish.js'), 'utf8')]]) {
  new (require('node:vm').Script)(source, { filename: file });
}

(async () => {
  const originalFetch = global.fetch;
  const requested = [];
  global.fetch = async (url, options = {}) => {
    const parsed = new URL(String(url));
    requested.push({ url: parsed, options });

    if (parsed.hostname === 'musicbrainz.org' && parsed.pathname === '/ws/2/recording') {
      if (parsed.searchParams.get('query')?.includes('Catalog Only Song')) {
        return { ok: true, status: 200, headers: { get: () => null }, text: async () => JSON.stringify({ recordings: [] }) };
      }
      return {
        ok: true, status: 200,
        headers: { get: () => null },
        text: async () => JSON.stringify({ recordings: [{
          id: '12345678-1234-1234-1234-123456789abc',
          title: 'Night Drive', score: 100,
          'first-release-date': '2022-04-01',
          'artist-credit': [{ name: 'Nova', joinphrase: '' }]
        }] })
      };
    }
    if (parsed.hostname === 'musicbrainz.org' && parsed.pathname === '/ws/2/recording/12345678-1234-1234-1234-123456789abc') {
      return {
        ok: true, status: 200,
        headers: { get: () => null },
        text: async () => JSON.stringify({
          id: '12345678-1234-1234-1234-123456789abc', title: 'Night Drive',
          'first-release-date': '2022-04-01',
          'artist-credit': [{ name: 'Nova', joinphrase: '' }],
          genres: [{ name: 'synth-pop', count: 8 }, { name: 'electronic', count: 2 }],
          tags: [{ name: 'seen live', count: 20 }],
          releases: [{ id: '22345678-1234-1234-1234-123456789abc', title: 'After Hours', date: '2022-04-01', country: 'GB', status: 'Official' }]
        })
      };
    }
    if (parsed.hostname === 'itunes.apple.com') {
      const catalogOnly = parsed.searchParams.get('term')?.includes('Catalog Only Song');
      return {
        ok: true, status: 200,
        headers: { get: () => null },
        text: async () => JSON.stringify({ resultCount: 1, results: [{
          trackId: catalogOnly ? 888 : 777, trackName: catalogOnly ? 'Catalog Only Song' : 'Night Drive (Radio Edit)', artistName: catalogOnly ? 'The Testers' : 'Nova',
          collectionName: catalogOnly ? 'Catalog Sessions' : 'Night Drive Singles', releaseDate: catalogOnly ? '2024-08-01T00:00:00Z' : '2023-02-03T00:00:00Z',
          primaryGenreName: 'Electronic',
          artworkUrl100: 'https://is1-ssl.mzstatic.com/image/thumb/Music123/100x100bb.jpg',
          trackTimeMillis: 201000
        }] })
      };
    }
    if (parsed.hostname === 'coverartarchive.org') {
      return {
        ok: true, status: 200,
        headers: { get: key => key.toLowerCase() === 'content-type' ? 'image/jpeg' : null },
        arrayBuffer: async () => Buffer.from([0xff, 0xd8, 0xff, 0xd9])
      };
    }
    if (parsed.hostname.endsWith('.mzstatic.com')) {
      return {
        ok: true, status: 200,
        headers: { get: key => key.toLowerCase() === 'content-type' ? 'image/png' : null },
        arrayBuffer: async () => Buffer.from([0x89, 0x50, 0x4e, 0x47])
      };
    }
    if (parsed.hostname === 'lyricsplus.prjktla.my.id' && parsed.pathname === '/v2/lyrics/get') {
      return {
        ok: false, status: 503,
        headers: { get: () => null },
        text: async () => 'Primary host temporarily unavailable'
      };
    }
    if (parsed.hostname === 'lyricsplus.binimum.org' && parsed.pathname === '/v2/lyrics/get') {
      return {
        ok: true, status: 200,
        headers: { get: () => null },
        text: async () => JSON.stringify({
          type: 'WORD',
          metadata: { title: 'Night Drive', artist: 'Nova', album: 'After Hours', totalDuration: '3:21.000', source: 'Apple Music' },
          lyrics: [
            { time: 0, duration: 2200, text: 'Provider first line', syllabus: [{ time: 0, duration: 1000, text: 'Provider' }, { time: 1000, duration: 1200, text: 'first line' }] },
            { time: 4200, duration: 2000, text: 'Provider second line', syllabus: [{ time: 4200, duration: 2000, text: 'Provider second line' }] }
          ]
        })
      };
    }
    if (parsed.hostname === 'api.betterlyrics.org' && parsed.pathname === '/kugou/getLyrics') {
      return {
        ok: true, status: 200,
        headers: { get: () => null },
        text: async () => JSON.stringify({ provider: 'kugou', lyrics: '[00:01.20]Kugou first line\n[00:05.10]Kugou second line' })
      };
    }
    if (parsed.hostname === 'lrclib.net') {
      return {
        ok: true, status: 200,
        headers: { get: () => null },
        text: async () => JSON.stringify([
          { id: 41, trackName: 'Night Drive', artistName: 'Nova', albumName: 'After Hours', duration: 201, instrumental: false, syncedLyrics: '', plainLyrics: 'First line\nSecond line' },
          { id: 42, trackName: 'Night Drive', artistName: 'Nova', albumName: 'After Hours', duration: 201, instrumental: false, syncedLyrics: '[00:00.00]First line\n[00:04.20]Second line', plainLyrics: 'First line\nSecond line' }
        ])
      };
    }
    throw new Error(`Unexpected URL in test: ${url}`);
  };

  try {
    const service = require(path.join(project, 'metadata-service.js'));
    const metadata = await service.searchMetadata({ title: 'Night Drive', artist: 'Nova', extraQuery: 'Night Drive Remix' });
    assert.ok(requested.some(item => item.url.hostname === 'musicbrainz.org' && item.url.searchParams.get('query')?.includes('Night Drive Remix')), 'alternate title should expand MusicBrainz search');
    assert.ok(requested.some(item => item.url.hostname === 'itunes.apple.com' && item.url.searchParams.get('term')?.includes('Night Drive Remix')), 'alternate title should expand Apple catalogue search');
    assert.ok(metadata.length >= 2, 'MusicBrainz and Apple catalog matches should be combined');
    const musicBrainzMatch = metadata.find(item => item.provider === 'MusicBrainz');
    const appleMatch = metadata.find(item => item.provider === 'Apple/iTunes catalog');
    assert.ok(musicBrainzMatch, 'recording lookup should produce a MusicBrainz match');
    assert.ok(appleMatch, 'iTunes fallback should produce an Apple catalog match');
    assert.equal(musicBrainzMatch.title, 'Night Drive');
    assert.equal(musicBrainzMatch.artist, 'Nova');
    assert.equal(musicBrainzMatch.album, 'After Hours');
    assert.equal(musicBrainzMatch.albumArtist, 'Nova');
    assert.equal(musicBrainzMatch.year, '2022');
    assert.equal(musicBrainzMatch.genre, 'synth-pop');
    assert.equal(appleMatch.provider, 'Apple/iTunes catalog');
    assert.equal(appleMatch.album, 'Night Drive Singles');
    assert.equal(appleMatch.albumArtist, 'Nova');
    assert.equal(appleMatch.year, '2023');
    assert.match(appleMatch.artworkUrl, /600x600bb\.jpg$/);

    const searchRequest = requested.find(item => item.url.hostname === 'musicbrainz.org' && item.url.pathname === '/ws/2/recording');
    assert.ok(searchRequest);
    assert.match(searchRequest.url.searchParams.get('query'), /recording:/);
    assert.match(searchRequest.url.searchParams.get('query'), /artist:/);
    assert.equal(searchRequest.url.searchParams.has('inc'), false, 'search should not request lookup-only subqueries');
    assert.match(searchRequest.options.headers['User-Agent'], /Echo Desktop\/1\.9\.7/);
    const lookupRequest = requested.find(item => item.url.hostname === 'musicbrainz.org' && item.url.pathname.includes('/recording/'));
    assert.ok(lookupRequest, 'full recording lookup should follow the search summary');
    assert.match(lookupRequest.url.searchParams.get('inc'), /releases/);

    const catalogOnly = await service.searchMetadata({ title: 'Catalog Only Song', artist: 'The Testers' });
    assert.equal(catalogOnly.length, 1, 'Apple catalog should still return metadata when MusicBrainz has no match');
    assert.equal(catalogOnly[0].provider, 'Apple/iTunes catalog');
    assert.equal(catalogOnly[0].album, 'Catalog Sessions');

    const artwork = await service.fetchMetadataArtwork(musicBrainzMatch.releaseId);
    assert.equal(artwork.mimeType, 'image/jpeg');
    assert.equal(Buffer.from(artwork.base64, 'base64').length, 4);
    const appleArtwork = await service.fetchMetadataArtwork({ artworkUrl: appleMatch.artworkUrl });
    assert.equal(appleArtwork.mimeType, 'image/png');
    assert.equal(Buffer.from(appleArtwork.base64, 'base64').length, 4);
    assert.equal(await service.fetchMetadataArtwork({ artworkUrl: 'http://malicious.invalid/image.png' }), null, 'non-HTTPS artwork URLs must be rejected');

    const lyrics = await service.searchLyrics({ title: 'Night Drive', artist: 'Nova', album: 'After Hours', duration: 201 });
    assert.ok(lyrics.length >= 4, 'all available lyric provider results should be returned');
    const lyricsPlusMatch = lyrics.find(match => match.source === 'YouLy+ / LyricsPlus');
    const kugouMatch = lyrics.find(match => match.provider === 'KuGou');
    const lrclibSynced = lyrics.find(match => match.id === 'lrclib-42');
    const lrclibPlain = lyrics.find(match => match.id === 'lrclib-41');
    assert.ok(lyricsPlusMatch, 'YouLy+ / LyricsPlus results should be normalized');
    assert.ok(kugouMatch, 'KuGou synced results should be normalized');
    assert.ok(lrclibSynced && lrclibPlain, 'LRCLIB should remain as a fallback provider');
    assert.equal(lyrics[0], lyricsPlusMatch, 'word/syllable-timed source should rank before line-synced fallbacks');
    assert.equal(lyricsPlusMatch.syncLevel, 'word');
    assert.equal(lyricsPlusMatch.duration, 201, 'LyricsPlus totalDuration should normalize into seconds');
    assert.match(lyricsPlusMatch.syncedLyrics, /\[00:04\.20\]/, 'LyricsPlus millisecond timestamps must normalize to LRC timestamps');
    assert.equal(lyricsPlusMatch.syncedLyrics.split(/\r?\n/).length, 2, 'LyricsPlus line breaks must be preserved');
    assert.equal(kugouMatch.syncLevel, 'line');
    assert.match(kugouMatch.syncedLyrics, /\[00:05\.10\]/);
    assert.equal(lrclibSynced.syncLevel, 'line');
    assert.equal(lrclibPlain.syncLevel, 'plain');
    const lyricsPlusPrimaryRequest = requested.find(item => item.url.hostname === 'lyricsplus.prjktla.my.id');
    const lyricsPlusRequest = requested.find(item => item.url.hostname === 'lyricsplus.binimum.org');
    assert.ok(lyricsPlusPrimaryRequest, 'the primary YouLy+ / LyricsPlus host should be queried first');
    assert.ok(lyricsPlusRequest, 'a published LyricsPlus mirror should be queried when the primary is unavailable');
    assert.ok(requested.indexOf(lyricsPlusPrimaryRequest) < requested.indexOf(lyricsPlusRequest), 'LyricsPlus should try its primary host before the mirror');
    assert.ok(lyricsPlusRequest, 'LyricsPlus backend should be queried');
    assert.equal(lyricsPlusRequest.url.pathname, '/v2/lyrics/get');
    assert.equal(lyricsPlusRequest.url.searchParams.get('title'), 'Night Drive');
    assert.equal(lyricsPlusRequest.url.searchParams.get('artist'), 'Nova');
    assert.equal(lyricsPlusRequest.url.searchParams.get('duration'), '201');
    assert.equal(lyricsPlusRequest.options.headers['X-Client-Package'], 'Echo Desktop (personal local music library)');
    const kugouRequest = requested.find(item => item.url.hostname === 'api.betterlyrics.org');
    assert.equal(kugouRequest.url.pathname, '/kugou/getLyrics');
    assert.equal(kugouRequest.url.searchParams.get('s'), 'Night Drive');
    assert.equal(kugouRequest.url.searchParams.get('a'), 'Nova');
    const lyricsUrl = requested.find(item => item.url.hostname === 'lrclib.net').url;
    assert.equal(lyricsUrl.origin + lyricsUrl.pathname, 'https://lrclib.net/api/search');
    assert.equal(lyricsUrl.searchParams.get('track_name'), 'Night Drive');
    assert.equal(lyricsUrl.searchParams.get('artist_name'), 'Nova');
    assert.equal(lyricsUrl.searchParams.get('album_name'), 'After Hours');
  } finally {
    global.fetch = originalFetch;
  }

  // Exercise the loopback asset server and verify that only the narrow metadata IPC surface is registered.
  class FakeApp extends EventEmitter {
    requestSingleInstanceLock() { return true; }
    whenReady() { return Promise.resolve(); }
    quit() { this.emit('before-quit'); }
  }
  class FakeWebContents extends EventEmitter {
    constructor() { super(); this.lastUrl = ''; this.destroyed = false; }
    setWindowOpenHandler(handler) { this.openHandler = handler; }
    loadURL(url) { this.lastUrl = url; global.__echoLoadedUrl = url; return Promise.resolve(); }
    isDestroyed() { return this.destroyed; }
  }
  class FakeWindow extends EventEmitter {
    constructor() {
      super();
      this.webContents = new FakeWebContents();
      this.destroyed = false;
      global.__echoMainWindow = this;
    }
    loadURL(url) { global.__echoLoadedUrl = url; }
    isMinimized() { return false; }
    isDestroyed() { return this.destroyed; }
    restore() {}
    focus() {}
  }
  const fakeApp = new FakeApp();
  const openedExternal = [];
  const handlers = new Map();
  const electronStub = {
    app: fakeApp,
    BrowserWindow: Object.assign(FakeWindow, { getAllWindows: () => global.__echoMainWindow ? [global.__echoMainWindow] : [] }),
    dialog: { showErrorBox(title, message) { throw new Error(`${title}: ${message}`); } },
    shell: { openExternal(url) { openedExternal.push(url); } },
    ipcMain: { handle(channel, callback) { handlers.set(channel, callback); } }
  };
  const originalLoad = Module._load;
  Module._load = function(request, parent, isMain) {
    if (request === 'electron') return electronStub;
    return originalLoad.call(this, request, parent, isMain);
  };
  try {
    require(path.join(project, 'main.js'));
  } finally {
    Module._load = originalLoad;
  }

  await new Promise(resolve => setTimeout(resolve, 100));
  const origin = 'http://127.0.0.1:43127';
  for (const file of ['/', '/index.html', '/styles.css', '/app.js', '/preload.js', '/metadata-service.js', '/hinglish.js']) {
    const response = await fetch(origin + file);
    assert.equal(response.status, 200, `${file} should be served`);
    assert.ok((await response.text()).length > 0, `${file} should not be empty`);
    if (file === '/index.html') assert.match(response.headers.get('content-security-policy'), /frame-src 'none'/);
    if (file === '/metadata-service.js') assert.match(response.headers.get('content-type'), /javascript/);
  }
  assert.equal((await fetch(origin + '/missing-file')).status, 404);
  assert.equal((await fetch(origin + '/', { method: 'POST' })).status, 405);
  assert.equal(global.__echoLoadedUrl, `${origin}/index.html`);
  assert.deepEqual([...handlers.keys()].sort(), ['echo:lyrics-align', 'echo:lyrics-search', 'echo:metadata-artwork', 'echo:metadata-search']);

  // On non-Windows CI, mock Python so the alignment IPC can be exercised without downloading models.
  if (process.platform !== 'win32') {
    const mockPythonDir = fs.mkdtempSync(path.join(os.tmpdir(), 'echo-mock-python-'));
    const mockPython = path.join(mockPythonDir, 'python3');
    const mockPythonSource = [
      '#!/usr/bin/env node',
      "const fs = require('node:fs');",
      'const args = process.argv.slice(2);',
      "if (args[0] === '-c') process.exit(0);",
      "const output = args[args.indexOf('--output') + 1];",
      "fs.writeFileSync(output, '[00:01.25]First supplied line\\nSecond supplied line\\n', 'utf8');",
      "console.log('ECHO_ALIGNMENT_PROGRESS:' + JSON.stringify({ percent: 55, message: 'Mock audio scan in progress' }));",
      "console.log('ECHO_ALIGNMENT_RESULT:' + JSON.stringify({ matchedLines: 1, totalLines: 2, languageDetected: 'en' }));"
    ].join('\n');
    fs.writeFileSync(mockPython, mockPythonSource, 'utf8');
    fs.chmodSync(mockPython, 0o755);
    const savedPath = process.env.PATH;
    process.env.PATH = `${mockPythonDir}${path.delimiter}${savedPath || ''}`;
    try {
      const emittedProgress = [];
      const sender = { isDestroyed: () => false, send: (channel, value) => emittedProgress.push({ channel, value }) };
      const alignment = await handlers.get('echo:lyrics-align')({ sender }, {
        audioData: new Uint8Array([1, 2, 3, 4]),
        fileName: 'mock-song.mp3',
        lyrics: 'First supplied line\nSecond supplied line',
        language: 'auto',
        model: 'tiny'
      });
      assert.match(alignment.lrc, /\[00:01\.25\]First supplied line/);
      assert.match(alignment.lrc, /Second supplied line/, 'unmatched supplied lyrics must remain in the editor output');
      assert.equal(alignment.matchedLines, 1);
      assert.equal(alignment.totalLines, 2);
      assert.equal(alignment.languageDetected, 'en');
      assert.ok(emittedProgress.some(item => item.channel === 'echo:lyrics-align-progress' && item.value.message === 'Mock audio scan in progress'), 'Python progress must stream back to the renderer');
      assert.ok(emittedProgress.some(item => item.value.status === 'complete' && item.value.percent === 100), 'the main process must report completed preview creation');
    } finally {
      process.env.PATH = savedPath;
      fs.rmSync(mockPythonDir, { recursive: true, force: true });
    }
  }
  await assert.rejects(() => handlers.get('echo:lyrics-align')({}, { lyrics: '  ' }), /Paste or fetch lyrics first/);
  assert.equal(global.__echoMainWindow.webContents.openHandler({ url: 'https://musicbrainz.org' }).action, 'deny');
  assert.deepEqual(openedExternal, ['https://musicbrainz.org/']);

  fakeApp.emit('before-quit');
  await new Promise(resolve => setTimeout(resolve, 80));
  console.log('Echo Desktop 1.10.0 checks passed: LyricsPlus primary/mirror failover and millisecond timing, KuGou line-synced LRC and LRCLIB fallback, live local search wiring, fixed shuffled queue order, full-screen lyrics timeline and scrollbar clipping, live alignment progress, lyric timing offsets, metadata broad search, explicit track play controls, artwork fullscreen/visualizer, lyrics transliteration, library and playlist UI, isolated IPC, CSP, loopback routes, and Electron security settings.');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
