'use strict';

const MUSICBRAINZ_ROOT = 'https://musicbrainz.org/ws/2';
const LRCLIB_ROOT = 'https://lrclib.net/api';
const LYRICSPLUS_ROOTS = [
  // YouLy+ / LyricsPlus primary host and published fallback mirrors.
  'https://lyricsplus.prjktla.my.id',
  'https://lyricsplus.binimum.org',
  'https://lyricsplus-seven.vercel.app',
  'https://lyricsplus.prjktla.workers.dev'
];
const KUGOU_LYRICS_ROOT = 'https://api.betterlyrics.org/kugou/getLyrics';
const ITUNES_ROOT = 'https://itunes.apple.com/search';
const USER_AGENT = 'Echo Desktop/1.9.7 (personal local music library)';
const MAX_RESPONSE_BYTES = 8 * 1024 * 1024;
let lastMusicBrainzRequestAt = 0;
let musicBrainzQueue = Promise.resolve();

function cleanText(value, maxLength = 180) {
  return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, maxLength);
}

function safeLucene(value) {
  return cleanText(value, 160).replace(/[\\+\-!(){}\[\]^"~*?:|&]/g, ' ').replace(/\s+/g, ' ').trim();
}

function cleanLyrics(value) {
  return String(value ?? '')
    .replace(/\r\n?/g, '\n')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')
    .slice(0, 200000)
    .trim();
}

function normalize(value) {
  return cleanText(value, 180).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

function textScore(actual, expected) {
  const a = normalize(actual);
  const b = normalize(expected);
  if (!a || !b) return 0;
  if (a === b) return 100;
  if (a.includes(b) || b.includes(a)) return 70;
  const aTokens = new Set(a.split(' '));
  const bTokens = new Set(b.split(' '));
  const overlap = [...bTokens].filter(token => aTokens.has(token)).length;
  return Math.round((overlap / Math.max(aTokens.size, bTokens.size)) * 55);
}

function artistCreditText(credit) {
  if (!Array.isArray(credit)) return '';
  return credit.map(part => {
    if (typeof part === 'string') return part;
    return `${part?.name || part?.artist?.name || ''}${part?.joinphrase || ''}`;
  }).join('').trim();
}

function firstGenre(genres, tags) {
  const source = Array.isArray(genres) && genres.length ? genres : tags;
  if (!Array.isArray(source)) return '';
  const usable = source
    .filter(tag => tag && typeof tag.name === 'string')
    .sort((a, b) => (Number(b.count) || 0) - (Number(a.count) || 0));
  return cleanText(usable[0]?.name || '', 60);
}

async function fetchJson(url, serviceName, timeoutMs = 18000, extraHeaders = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: 'GET',
      redirect: 'follow',
      signal: controller.signal,
      headers: {
        'Accept': 'application/json',
        'User-Agent': USER_AGENT,
        ...extraHeaders
      }
    });
    if (!response.ok) {
      if (response.status === 404) return null;
      if (response.status === 429 || response.status === 503) {
        const retryAfter = response.headers.get('retry-after');
        throw new Error(`${serviceName} is temporarily limiting requests${retryAfter ? `; try again in ${retryAfter} seconds` : ''}.`);
      }
      throw new Error(`${serviceName} request failed (HTTP ${response.status}).`);
    }
    const text = await response.text();
    if (Buffer.byteLength(text, 'utf8') > MAX_RESPONSE_BYTES) throw new Error(`${serviceName} returned an unexpectedly large response.`);
    try { return JSON.parse(text); }
    catch { throw new Error(`${serviceName} returned an unreadable response.`); }
  } catch (error) {
    if (error.name === 'AbortError') throw new Error(`${serviceName} took too long to respond. Check your connection and try again.`);
    if (error instanceof TypeError) throw new Error(`Could not reach ${serviceName}. Check your internet connection.`);
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

async function withMusicBrainzThrottle(task) {
  const run = musicBrainzQueue.then(async () => {
    const wait = Math.max(0, 1100 - (Date.now() - lastMusicBrainzRequestAt));
    if (wait) await new Promise(resolve => setTimeout(resolve, wait));
    lastMusicBrainzRequestAt = Date.now();
    return task();
  });
  musicBrainzQueue = run.catch(() => {});
  return run;
}

function musicBrainzSearchUrl(query) {
  const params = new URLSearchParams({ query, fmt: 'json', limit: '50' });
  return `${MUSICBRAINZ_ROOT}/recording?${params}`;
}

async function searchMusicBrainz(title, artist, extraQuery = '') {
  const safeArtist = safeLucene(artist);
  const terms = [...new Set([title, ...String(extraQuery || '').split(/[;|\n]+/)].map(safeLucene).filter(Boolean))].slice(0, 4);
  if (!terms.length) return [];

  // Run a wider catalogue search: primary title + optional alternate spellings.
  // Merge summaries before enriching them so one exact query cannot hide other releases.
  const queries = [];
  for (const term of terms) {
    if (safeArtist && !/^unknown artist$/i.test(artist)) queries.push(`recording:"${term}" AND artist:"${safeArtist}"`);
  }
  if (!safeArtist || /^unknown artist$/i.test(artist)) queries.push(`recording:"${terms[0]}"`);
  const recordingsById = new Map();
  let lastError = null;
  for (const query of [...new Set(queries)]) {
    try {
      const data = await withMusicBrainzThrottle(() => fetchJson(musicBrainzSearchUrl(query), 'MusicBrainz'));
      for (const recording of (Array.isArray(data?.recordings) ? data.recordings : [])) {
        const key = recording.id || `${recording.title}|${artistCreditText(recording['artist-credit'])}`;
        if (!recordingsById.has(key)) recordingsById.set(key, recording);
      }
    } catch (error) {
      lastError = error;
      break; // Do not hammer a rate-limited service.
    }
  }
  // Always add title-only searches for the main and first alternate title.
  // Artist-only constraints can suppress legitimate regional, remix, or featured releases.
  for (const term of (recordingsById.size < 10 ? terms.slice(0, 2) : [])) {
    try {
      const data = await withMusicBrainzThrottle(() => fetchJson(musicBrainzSearchUrl(`recording:"${term}"`), 'MusicBrainz'));
      for (const recording of (Array.isArray(data?.recordings) ? data.recordings : [])) {
        const key = recording.id || `${recording.title}|${artistCreditText(recording['artist-credit'])}`;
        if (!recordingsById.has(key)) recordingsById.set(key, recording);
      }
    } catch (error) { if (!recordingsById.size) lastError = error; }
  }
  const recordings = [...recordingsById.values()];
  if (!recordings.length) { if (lastError) throw lastError; return []; }

  const candidates = [];
  const lookupTargets = recordings.slice(0, 8);
  for (const summary of lookupTargets) {
    const recordingTitle = cleanText(summary.title, 160);
    const summaryArtist = artistCreditText(summary['artist-credit']) || artist;
    const summaryTitleScore = Math.max(...terms.map(term => textScore(recordingTitle, term)));
    const summaryScore = summaryTitleScore + (artist ? textScore(summaryArtist, artist) * 0.5 : 0);
    let recording = summary;

    if (/^[0-9a-f-]{36}$/i.test(String(summary.id || ''))) {
      try {
        const params = new URLSearchParams({ fmt: 'json', inc: 'releases+artist-credits+genres+tags' });
        const detail = await withMusicBrainzThrottle(() => fetchJson(`${MUSICBRAINZ_ROOT}/recording/${encodeURIComponent(summary.id)}?${params}`, 'MusicBrainz'));
        if (detail && typeof detail === 'object') recording = detail;
      } catch {
        // Keep the usable search summary when an enrichment lookup is unavailable.
      }
    }

    const finalTitle = cleanText(recording.title || recordingTitle, 160);
    const finalArtist = artistCreditText(recording['artist-credit']) || summaryArtist || artist;
    const genres = Array.isArray(recording.genres) ? recording.genres : [];
    const tags = Array.isArray(recording.tags) ? recording.tags : [];
    const releases = Array.isArray(recording.releases) ? recording.releases : [];
    const bestTitleScore = Math.max(...terms.map(term => textScore(finalTitle, term)));
    const baseScore = bestTitleScore + (artist ? textScore(finalArtist, artist) * 0.5 : 0) + Math.max(0, Math.min(10, Number(summary.score) / 10 || 0));

    if (!releases.length) {
      candidates.push({
        id: `${recording.id || finalTitle}-no-release`, provider: 'MusicBrainz', recordingId: recording.id || '', releaseId: '', artworkUrl: '',
        title: finalTitle, artist: finalArtist, album: '', year: String(recording['first-release-date'] || '').slice(0, 4),
        genre: firstGenre(genres, tags), country: '', status: '', score: Math.round(baseScore || summaryScore)
      });
      continue;
    }

    for (const release of releases.slice(0, 7)) {
      candidates.push({
        id: `${recording.id || ''}-${release.id || release.title}`,
        provider: 'MusicBrainz',
        recordingId: recording.id || '',
        releaseId: /^[0-9a-f-]{36}$/i.test(String(release.id || '')) ? release.id : '',
        artworkUrl: '',
        title: finalTitle,
        artist: artistCreditText(recording['artist-credit']) || artistCreditText(release['artist-credit']) || finalArtist,
        albumArtist: artistCreditText(release['artist-credit']) || finalArtist,
        album: cleanText(release.title, 160),
        year: String(release.date || recording['first-release-date'] || '').slice(0, 4),
        genre: firstGenre(genres, tags),
        country: cleanText(release.country || '', 8),
        status: cleanText(release.status || '', 24),
        score: Math.round(baseScore + (release.status === 'Official' ? 8 : 0))
      });
    }
  }

  const seen = new Set();
  return candidates
    .sort((a, b) => b.score - a.score)
    .filter(candidate => {
      const key = `${normalize(candidate.title)}|${normalize(candidate.artist)}|${normalize(candidate.album)}|${candidate.releaseId}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 20);
}

function largerAppleArtworkUrl(value) {
  const raw = cleanText(value, 1000);
  try {
    const url = new URL(raw);
    if (url.protocol !== 'https:' || !url.hostname.toLowerCase().endsWith('.mzstatic.com')) return '';
    url.pathname = url.pathname.replace(/\b100x100bb\b/i, '600x600bb');
    return url.href;
  } catch {
    return '';
  }
}

async function searchAppleCatalog(title, artist, extraQuery = '') {
  const alternateTerms = String(extraQuery || '').split(/[;|\n]+/).map(value => cleanText(value, 160)).filter(Boolean).slice(0, 3);
  const titleTerms = [title, ...alternateTerms];
  const terms = [...new Set([[title, artist].filter(value => value && !/^unknown artist$/i.test(value)).join(' '), ...alternateTerms, title].filter(Boolean))];
  const resultsById = new Map();
  let lastError = null;
  for (const [index, term] of terms.entries()) {
    const params = new URLSearchParams({ term, entity: 'song', media: 'music', country: 'IN', limit: '50' });
    try {
      const data = await fetchJson(`${ITUNES_ROOT}?${params}`, 'Apple Music catalog');
      for (const item of (Array.isArray(data?.results) ? data.results : [])) {
        const key = item.trackId || `${item.trackName}|${item.artistName}|${item.collectionName}`;
        if (!resultsById.has(key)) resultsById.set(key, item);
      }
    } catch (error) { lastError = error; if (index === 0 && terms.length === 1) throw error; }
  }
  // Always check the US storefront in addition to India. Popular India results can
  // otherwise prevent the fallback from ever running even when the requested release is absent.
  const fallbackTerms = [
    [title, artist].filter(value => value && !/^unknown artist$/i.test(value)).join(' '),
    title,
    ...alternateTerms.slice(0, 1)
  ].filter(Boolean);
  for (const term of [...new Set(fallbackTerms)]) {
    const params = new URLSearchParams({ term, entity: 'song', media: 'music', country: 'US', limit: '50' });
    try {
      const data = await fetchJson(`${ITUNES_ROOT}?${params}`, 'Apple Music catalog');
      for (const item of (Array.isArray(data?.results) ? data.results : [])) {
        const key = item.trackId || `${item.trackName}|${item.artistName}|${item.collectionName}`;
        if (!resultsById.has(key)) resultsById.set(key, item);
      }
    } catch (error) { lastError = lastError || error; }
  }
  const results = [...resultsById.values()];
  if (!results.length && lastError) throw lastError;
  return results.map((item, index) => {
    const trackTitle = cleanText(item.trackName, 160);
    const trackArtist = cleanText(item.artistName, 160);
    const album = cleanText(item.collectionName, 160);
    const releaseDate = cleanText(item.releaseDate, 30);
    const score = Math.max(...titleTerms.map(term => textScore(trackTitle, term))) + (artist ? textScore(trackArtist, artist) * 0.5 : 0);
    return {
      id: `itunes-${item.trackId || index}`,
      provider: 'Apple/iTunes catalog',
      recordingId: '', releaseId: '',
      artworkUrl: largerAppleArtworkUrl(item.artworkUrl100 || item.artworkUrl60 || ''),
      title: trackTitle,
      artist: trackArtist,
      albumArtist: cleanText(item.collectionArtistName || trackArtist, 160),
      album,
      year: releaseDate.slice(0, 4),
      genre: cleanText(item.primaryGenreName || '', 60),
      country: '', status: '',
      duration: Math.round((Number(item.trackTimeMillis) || 0) / 1000),
      score: Math.round(score)
    };
  }).filter(item => item.title && item.artist)
    .sort((a, b) => b.score - a.score)
    .slice(0, 20);
}

async function searchMetadata(input = {}) {
  const title = cleanText(input.title, 160);
  const artist = cleanText(input.artist, 160);
  const extraQuery = cleanText(input.extraQuery, 500);
  if (!title) throw new Error('Enter a song title before fetching metadata.');

  const results = await Promise.allSettled([
    searchMusicBrainz(title, artist, extraQuery),
    searchAppleCatalog(title, artist, extraQuery)
  ]);
  const musicBrainzMatches = results[0].status === 'fulfilled' ? results[0].value : [];
  const appleMatches = results[1].status === 'fulfilled' ? results[1].value : [];
  const combined = [...musicBrainzMatches, ...appleMatches];
  const seen = new Set();
  const matches = combined
    .sort((a, b) => b.score - a.score)
    .filter(candidate => {
      const key = `${normalize(candidate.title)}|${normalize(candidate.artist)}|${normalize(candidate.album)}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 20);

  if (!matches.length) {
    const messages = results.map(result => result.status === 'rejected' ? result.reason?.message : '').filter(Boolean);
    if (messages.length) throw new Error(`No metadata matches were found. ${messages.join(' · ')}`);
  }
  return matches;
}

async function fetchMetadataArtwork(reference) {
  let url = '';
  if (typeof reference === 'string') {
    const id = cleanText(reference, 50);
    if (/^[0-9a-f-]{36}$/i.test(id)) {
      url = `https://coverartarchive.org/release/${encodeURIComponent(id)}/front-500`;
    }
  } else if (reference && typeof reference === 'object') {
    const releaseId = cleanText(reference.releaseId, 50);
    if (/^[0-9a-f-]{36}$/i.test(releaseId)) {
      url = `https://coverartarchive.org/release/${encodeURIComponent(releaseId)}/front-500`;
    } else {
      const artworkUrl = cleanText(reference.artworkUrl, 1000);
      try {
        const parsed = new URL(artworkUrl);
        if (parsed.protocol === 'https:' && parsed.hostname.toLowerCase().endsWith('.mzstatic.com')) url = parsed.href;
      } catch { /* ignore invalid external image URLs */ }
    }
  }
  if (!url) return null;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 18000);
  try {
    const response = await fetch(url, {
      method: 'GET', redirect: 'follow', signal: controller.signal,
      headers: { 'User-Agent': USER_AGENT, 'Accept': 'image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8' }
    });
    if (!response.ok) return null;
    const contentType = response.headers.get('content-type') || '';
    if (!/^image\/(jpeg|png|webp|gif)$/i.test(contentType)) return null;
    const buffer = Buffer.from(await response.arrayBuffer());
    if (!buffer.length || buffer.length > MAX_RESPONSE_BYTES) return null;
    return { mimeType: contentType.split(';')[0], base64: buffer.toString('base64') };
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

function lyricsPlusTimeMs(value, fallback = null) {
  if (value === null || value === undefined || value === '') return fallback;
  if (typeof value === 'string' && /^\d{1,2}:\d{2}(?:[.:]\d{1,3})?$/.test(value.trim())) {
    const match = value.trim().match(/^(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?$/);
    if (!match) return fallback;
    return (Number(match[1]) * 60 + Number(match[2])) * 1000 + Number((match[3] || '0').padEnd(3, '0'));
  }
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) return fallback;
  // LyricsPlus V2/KPOE line and word time values are milliseconds.
  return Math.round(number);
}

function lyricsPlusDurationSeconds(value) {
  if (value === null || value === undefined || value === '') return 0;
  if (typeof value === 'string') {
    const match = value.trim().match(/^(\d+):(\d{2})(?:[.:](\d{1,3}))?$/);
    if (match) return Number(match[1]) * 60 + Number(match[2]) + Number(`0.${(match[3] || '0').padEnd(3, '0')}`);
  }
  const number = Number(value);
  if (!Number.isFinite(number) || number <= 0) return 0;
  return number > 10000 ? number / 1000 : number;
}

function formatLrcTimestamp(milliseconds) {
  const safe = Math.max(0, Math.round(Number(milliseconds) || 0));
  const minutes = Math.floor(safe / 60000);
  const seconds = (safe % 60000) / 1000;
  return `[${String(minutes).padStart(2, '0')}:${seconds.toFixed(2).padStart(5, '0')}]`;
}

function getLyricsPlusEntries(payload) {
  if (Array.isArray(payload?.lyrics)) return payload.lyrics;
  if (Array.isArray(payload?.data?.lyrics)) return payload.data.lyrics;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.lines)) return payload.lines;
  if (Array.isArray(payload?.Body?.Content)) return payload.Body.Content;
  return [];
}

function lyricEntryText(entry) {
  const direct = cleanLyrics(entry?.text || entry?.Text || entry?.line || entry?.wordsText || '');
  if (direct) return direct.replace(/\s+/g, ' ').trim();
  const fragments = Array.isArray(entry?.syllabus) ? entry.syllabus : Array.isArray(entry?.words) ? entry.words : [];
  if (!fragments.length) return '';
  let text = '';
  fragments.forEach((fragment, index) => {
    const part = String(fragment?.text ?? fragment?.Text ?? '').replace(/[\r\n]+/g, ' ');
    if (!part) return;
    const joinsPrevious = Boolean(fragment?.part || fragment?.isPartOfWord || fragment?.IsPartOfWord);
    if (index > 0 && text && !joinsPrevious && !/\s$/.test(text) && !/^\s/.test(part)) text += ' ';
    text += part;
  });
  return text.replace(/\s+/g, ' ').trim();
}

function lyricsPlusToMatch(payload, input, index = 0) {
  const entries = getLyricsPlusEntries(payload).filter(Boolean);
  const metadata = payload?.metadata || payload?.data?.metadata || {};
  const type = String(payload?.type || payload?.Type || payload?.Body?.Type || '').toLowerCase();
  const wordTimed = type.includes('syllable') || type.includes('word') || entries.some(entry => Array.isArray(entry?.syllabus) || Array.isArray(entry?.words));
  const lines = [];
  const plainLines = [];
  for (const entry of entries) {
    const text = lyricEntryText(entry);
    if (!text) continue;
    plainLines.push(text);
    const timeValue = entry?.time ?? entry?.timestamp ?? entry?.startTime ?? entry?.startTimeMs ?? entry?.StartTime;
    const startMs = lyricsPlusTimeMs(timeValue, null);
    if (startMs !== null) lines.push({ startMs, text });
  }
  lines.sort((a, b) => a.startMs - b.startMs);
  const syncedLyrics = lines.length
    ? lines.map(line => `${formatLrcTimestamp(line.startMs)}${line.text}`).join('\n')
    : '';
  const duration = lyricsPlusDurationSeconds(metadata.durationMs || payload?.durationMs || metadata.totalDuration || metadata.duration || payload?.duration || input.duration);
  const title = cleanText(metadata.title || payload?.title || input.title, 160);
  const artist = cleanText(metadata.artist || payload?.artist || input.artist, 160);
  const album = cleanText(metadata.album || payload?.album || input.album, 160);
  const durationDifference = Number(input.duration) > 0 && duration > 0 ? Math.abs(Number(input.duration) - duration) : null;
  const upstreamSource = cleanText(metadata.source || metadata.provider || payload?.source || '', 60);
  const provider = upstreamSource ? `YouLy+ / LyricsPlus · ${upstreamSource}` : 'YouLy+ / LyricsPlus';
  const score = textScore(title, input.title) + (input.artist ? textScore(artist, input.artist) * 0.5 : 0) + (durationDifference !== null ? (durationDifference <= 2 ? 30 : Math.max(-25, 10 - durationDifference * 2)) : 0);
  return {
    id: `lyricsplus-${index}-${normalize(title)}-${normalize(artist)}`,
    provider,
    source: 'YouLy+ / LyricsPlus',
    syncLevel: syncedLyrics ? (wordTimed ? 'word' : 'line') : (plainLines.length ? 'plain' : 'none'),
    title, artist, album, duration, durationDifference,
    instrumental: Boolean(payload?.instrumental || payload?.isInstrumental),
    syncedLyrics,
    plainLyrics: plainLines.join('\n'),
    score: Math.round(score)
  };
}

async function searchLyricsPlus(input) {
  const params = new URLSearchParams({
    title: input.title,
    artist: input.artist || '',
    album: input.album || '',
    duration: String(Math.max(0, Number(input.duration) || 0)),
    source: 'apple,lyricsplus,musixmatch,spotify,qq,deezer,musixmatch-word'
  });
  const headers = { 'X-Client-Package': 'Echo Desktop (personal local music library)' };
  for (let index = 0; index < LYRICSPLUS_ROOTS.length; index += 1) {
    const root = LYRICSPLUS_ROOTS[index];
    try {
      const payload = await fetchJson(`${root}/v2/lyrics/get?${params}`, 'YouLy+ / LyricsPlus', 3500, headers);
      if (!payload) continue;
      const match = lyricsPlusToMatch(payload, input, index);
      if (match.syncedLyrics || match.plainLyrics || match.instrumental) return [match];
    } catch {
      // A failed primary host or mirror must not block KuGou or LRCLIB.
    }
  }
  return [];
}

async function searchKugouLyrics(input) {
  const params = new URLSearchParams({
    s: input.title,
    a: input.artist || '',
    al: input.album || '',
    d: String(Math.max(0, Math.round(Number(input.duration) || 0)))
  });
  try {
    const payload = await fetchJson(`${KUGOU_LYRICS_ROOT}?${params}`, 'KuGou lyrics', 9000);
    if (!payload) return [];
    const raw = typeof payload === 'string' ? payload : (payload.lyrics || payload.data?.lyrics || payload.data?.lyric || payload.content || '');
    const syncedLyrics = cleanLyrics(raw);
    if (!syncedLyrics) return [];
    const hasTimestamps = /\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?\]/.test(syncedLyrics);
    const durationDifference = Number(input.duration) > 0 && Number(payload.duration) > 0 ? Math.abs(Number(input.duration) - Number(payload.duration)) : null;
    return [{
      id: `kugou-${normalize(input.title)}-${normalize(input.artist)}`,
      provider: 'KuGou', source: 'KuGou', syncLevel: hasTimestamps ? 'line' : 'plain',
      title: cleanText(payload.title || input.title, 160),
      artist: cleanText(payload.artist || input.artist, 160),
      album: cleanText(payload.album || input.album, 160),
      duration: Number(payload.duration) || Number(input.duration) || 0,
      durationDifference, instrumental: false,
      syncedLyrics: hasTimestamps ? syncedLyrics : '',
      plainLyrics: hasTimestamps ? '' : syncedLyrics,
      score: Math.round(textScore(payload.title || input.title, input.title) + (input.artist ? textScore(payload.artist || input.artist, input.artist) * 0.5 : 0) + (durationDifference !== null ? (durationDifference <= 2 ? 30 : Math.max(-25, 10 - durationDifference * 2)) : 0))
    }];
  } catch {
    return [];
  }
}

async function searchLrcLibLyrics(input) {
  const params = new URLSearchParams({ track_name: input.title });
  if (input.artist && !/^unknown artist$/i.test(input.artist)) params.set('artist_name', input.artist);
  if (input.album) params.set('album_name', input.album);
  const data = await fetchJson(`${LRCLIB_ROOT}/search?${params}`, 'LRCLIB', 10000);
  const records = Array.isArray(data) ? data : [];
  const duration = Number(input.duration) || 0;
  return records.map((record, index) => {
    const durationDifference = duration > 0 && Number(record.duration) > 0 ? Math.abs(duration - Number(record.duration)) : null;
    let score = textScore(record.trackName || record.name, input.title);
    if (input.artist) score += textScore(record.artistName, input.artist) * 0.5;
    if (input.album && record.albumName) score += textScore(record.albumName, input.album) * 0.2;
    if (durationDifference !== null) score += durationDifference <= 2 ? 30 : Math.max(-25, 10 - durationDifference * 2);
    const syncedLyrics = cleanLyrics(record.syncedLyrics || '');
    return {
      id: `lrclib-${Number(record.id) || index}`,
      provider: 'LRCLIB', source: 'LRCLIB',
      syncLevel: /\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?\]/.test(syncedLyrics) ? 'line' : 'plain',
      title: cleanText(record.trackName || record.name || '', 160),
      artist: cleanText(record.artistName || '', 160),
      album: cleanText(record.albumName || '', 160),
      duration: Number(record.duration) || 0,
      durationDifference,
      instrumental: Boolean(record.instrumental),
      syncedLyrics,
      plainLyrics: cleanLyrics(record.plainLyrics || ''),
      score: Math.round(score)
    };
  });
}

async function searchLyrics(input = {}) {
  const normalizedInput = {
    title: cleanText(input.title, 160),
    artist: cleanText(input.artist, 160),
    album: cleanText(input.album, 160),
    duration: Math.max(0, Math.min(3600, Number(input.duration) || 0))
  };
  if (!normalizedInput.title) throw new Error('Enter a song title before fetching lyrics.');

  const providers = await Promise.allSettled([
    searchLyricsPlus(normalizedInput),
    searchKugouLyrics(normalizedInput),
    searchLrcLibLyrics(normalizedInput)
  ]);
  const matches = providers.flatMap(result => result.status === 'fulfilled' ? result.value : []);
  const syncRank = { word: 0, line: 1, plain: 2, none: 3 };
  const unique = new Map();
  for (const match of matches) {
    const content = match.syncedLyrics || match.plainLyrics;
    const signature = normalize(content).slice(0, 5000);
    const key = signature || `${match.provider}:${normalize(match.title)}:${normalize(match.artist)}`;
    const existing = unique.get(key);
    if (!existing || (syncRank[match.syncLevel] ?? 3) < (syncRank[existing.syncLevel] ?? 3)) unique.set(key, match);
  }
  return [...unique.values()]
    .filter(match => match.syncedLyrics || match.plainLyrics || match.instrumental)
    .sort((a, b) => (syncRank[a.syncLevel] ?? 3) - (syncRank[b.syncLevel] ?? 3) || b.score - a.score)
    .slice(0, 12);
}

module.exports = { searchMetadata, fetchMetadataArtwork, searchLyrics };
