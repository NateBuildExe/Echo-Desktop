# Echo Desktop 1.10.0 — test checklist

## Automated checks
- [x] JavaScript syntax checks pass for renderer, main process, preload, metadata service, Hinglish helper, and tests.
- [x] `npm test` passes with mocked MusicBrainz, Apple/iTunes, YouLy+ / LyricsPlus (including primary-host failover), KuGou, and LRCLIB responses.
- [x] Archive extraction and package integrity checked.

## Search
- [ ] Search by an exact song title; results update while typing.
- [ ] Press Enter and confirm results remain visible.
- [ ] Search using multiple words in a different order (for example artist + title).
- [ ] Search by album, filename and genre.
- [ ] Search a Hindi/Devanagari title using the Roman Hinglish spelling, when the helper can transliterate it.
- [ ] Clear the search with the X/Escape or Clear search action and confirm the library remains intact.

## Shuffle and queue
- [ ] Start a playlist or a library list.
- [ ] Enable Shuffle and open Queue; note the full order shown.
- [ ] Press Next several times; the order should not reshuffle.
- [ ] Press Previous after the current song has played for more than three seconds; it should return to the prior queue entry.
- [ ] Open Queue again and confirm the same shuffled order and current-song highlight.
- [ ] Drag a queue item and confirm the displayed order and Next/Previous follow the manual reorder.
- [ ] Turn Shuffle off and confirm the original pre-shuffle order is restored.

## Full-screen lyrics
- [ ] Open fullscreen lyrics with a track that has timestamped lyrics.
- [ ] Scroll to the first line and to the last line; manual scrolling should not snap back while playback continues.
- [ ] Click a past and an upcoming line; playback should seek to the selected timestamp.
- [ ] Select Follow active and confirm automatic centering resumes.
- [ ] Hide and show the rounded timeline.
- [ ] Test timeline play/pause and seeking; confirm the main player and lyrics timeline remain synchronized.
- [ ] Confirm plain-text lyrics display but do not pretend to be timestamp-seekable.

## Lyrics timing
- [ ] Open Edit and set a negative timing offset; confirm lyrics display earlier.
- [ ] Set a positive offset; confirm lyrics display later.
- [ ] Try rate below 100% and above 100%; confirm timing drift changes progressively through the song.
- [ ] Reset timing and save; confirm 0 ms and 100% persist.
- [ ] Confirm original lyrics text and LRC timestamps remain unchanged by correction controls.
- [ ] Use Stamp current playback time with a non-default offset/rate and verify the resulting line aligns with the current playback time.

## Metadata search
- [ ] Search a title/artist combination available in MusicBrainz.
- [ ] Search using an alternate title or transliteration in the expanded alternate-query field.
- [ ] Check that results include the title-only lookup and Apple/iTunes candidates when available.
- [ ] Verify an Apple/iTunes US storefront-only result can appear.
- [ ] Review candidate metadata/artwork before saving.

## Row playback
- [ ] Click a song title; playback should not start.
- [ ] Click an artist/album field; playback should not start.
- [ ] Click blank row space; playback should not start.
- [ ] Click the visible thumbnail play button; the song should start.
- [ ] Click the current track's thumbnail while playing; it should pause.
- [ ] Click it again while paused; it should resume without rebuilding shuffle.
- [ ] Repeat from a playlist.


## Synced lyrics providers (new in 1.9.7)
- [ ] Fetch lyrics for a song known to have a YouLy+ / LyricsPlus result.
- [ ] Confirm LyricsPlus uses the primary `lyricsplus.prjktla.my.id` host and can fall back to `lyricsplus.binimum.org` if the primary is unavailable.
- [ ] Confirm the result label shows the upstream source when supplied (for example Apple or Musixmatch).
- [ ] Confirm word/syllable-timed results are ranked above line-synced and plain results.
- [ ] Confirm Echo imports the line start times from the LyricsPlus result and does not claim word-by-word highlighting.
- [ ] Fetch a song with a KuGou result and confirm its LRC timestamps appear as a line-synced candidate.
- [ ] Confirm LRCLIB remains available when LyricsPlus or KuGou does not return a match.
- [ ] Simulate one provider being unavailable and confirm the other providers can still return candidates.
- [ ] Confirm only title, artist, album, and duration are sent for lookup; local audio is never uploaded.

## Regression
- [ ] Import a single track, multiple tracks, and a folder.
- [ ] Play, pause, seek, volume, Previous, and Next.
- [ ] Full-screen artwork opens and the visualizer is visible.
- [ ] Metadata and lyrics fetch still work online.
- [ ] Existing library, playlists, artwork, lyrics, and settings persist after restart.
- [ ] Local playback still works with internet disconnected.

Automated tests use mocked service responses; Windows UI, native file dialogs, live catalogue results, and audio behavior require manual PC testing.


## 1.9.9 local lyric alignment
- [ ] Without the optional engine installed, Auto-sync shows a clear setup message and does not alter the lyrics editor.
- [ ] During Auto-sync, a progress percentage and phase message appear; the final result reports matched lines / total lines.
- [ ] Install the optional aligner using Install-Echo-Lyric-Aligner.bat (64-bit Python 3.9+).
- [ ] Align a provider result with missing timestamps; verify a new LRC is staged but not saved until Save changes.
- [ ] Align an LRC with wrong timestamps; confirm previous timestamps are replaced by the new preview.
- [ ] Test Auto, Hindi, Urdu, and Punjabi language choices where applicable.
- [ ] Confirm unmatched lines stay untimed and are not silently interpolated.
- [ ] Confirm no audio is sent to the metadata/lyrics web services by the alignment feature.
- [ ] Confirm fullscreen lyrics remain scrollable with no visible scrollbar.
- [ ] Confirm no-lyrics input shows guidance to fetch or provide lyrics and does not attempt to generate missing copyrighted lyrics.


## 1.9.9 local alignment and lyrics display
- [ ] Install optional local alignment with Install-Echo-Lyric-Aligner.bat.
- [ ] Run Auto detect on a supplied English lyric file and confirm detected language appears.
- [ ] Try explicit Hindi, Urdu, and Punjabi language settings with lyrics in their original scripts.
- [ ] Try Tiny on an older PC; try Base only if the match rate is low and hardware permits.
- [ ] Confirm alignment replaces timestamps only after review and Save changes.
- [ ] Confirm unmatched source lines remain visible as untimed text in the editor.
- [ ] Try a slow/sustained vocal and confirm the no-VAD retry message appears when the first pass matches too few lines.
- [ ] Confirm local playback continues offline after model download.
- [ ] Scroll full-screen lyrics with the mouse wheel / touchpad and confirm scrollbar thumb is hidden.
- [ ] Confirm full-screen lyrics can still be scrolled to the first and last lyric line.


## 1.9.9 additions
- Auto-sync displays a live progress bar and phase message while the Python model loads, audio is scanned, lyrics are matched, and the preview is written. Confirm the status changes during a real alignment run and ends with the matched/total line count.
- Full-screen lyrics can still be scrolled with wheel/touch/trackpad, but the scrollbar should not be visible.
- SoundCloud is not yet integrated; official API app credentials are required for track search.


## 1.10.0 Python installer verification
- [ ] Close Echo and run `Install-Echo-Lyric-Aligner.bat` from the project folder.
- [ ] Confirm the window reports each of the four steps and does not close until a key is pressed.
- [ ] Confirm `.echo-lyric-venv\Scripts\python.exe` exists.
- [ ] Confirm the installer reports successful imports for both `faster_whisper` and `lyric_align`.
- [ ] Confirm `Echo-Lyric-Aligner-Setup.log` is created and contains the selected Python version and package import paths.
- [ ] Reopen Echo and run Align timestamps; confirm it no longer reports `No module named 'faster_whisper'`.
- [ ] Confirm Echo uses the same `.echo-lyric-venv` interpreter shown in the setup log.

The Python installer cannot be executed on non-Windows CI. The source tests check the wiring and installer contents; a real Windows installation is still required to validate package downloads and Windows runtime compatibility.
