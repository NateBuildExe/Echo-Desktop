const { app, BrowserWindow, dialog, shell, ipcMain } = require('electron');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const os = require('node:os');
const { spawn, spawnSync } = require('node:child_process');
const metadataService = require('./metadata-service');

const APP_PORT = 43127; // Stable origin: IndexedDB data survives app restarts.
const ROOT = path.resolve(__dirname);
const LOCAL_ORIGIN = `http://127.0.0.1:${APP_PORT}`;
let localServer = null;

ipcMain.handle('echo:metadata-search', (_event, input) => metadataService.searchMetadata({
  title: String(input?.title || '').slice(0, 160),
  artist: String(input?.artist || '').slice(0, 160),
  extraQuery: String(input?.extraQuery || '').slice(0, 500)
}));
ipcMain.handle('echo:metadata-artwork', (_event, reference) => metadataService.fetchMetadataArtwork(
  typeof reference === 'string' ? reference.slice(0, 50) : {
    releaseId: String(reference?.releaseId || '').slice(0, 50),
    artworkUrl: String(reference?.artworkUrl || '').slice(0, 1000)
  }
));
ipcMain.handle('echo:lyrics-search', (_event, input) => metadataService.searchLyrics({
  title: String(input?.title || '').slice(0, 160),
  artist: String(input?.artist || '').slice(0, 160),
  album: String(input?.album || '').slice(0, 160),
  duration: Math.max(0, Math.min(3600, Number(input?.duration) || 0))
}));
ipcMain.handle('echo:lyrics-align', async (event, input) => {
  const sendProgress = (percent, message, status = 'working') => {
    const payload = { percent: Math.max(0, Math.min(100, Math.round(Number(percent) || 0))), message: String(message || '').slice(0, 240), status };
    try { if (event.sender && !event.sender.isDestroyed()) event.sender.send('echo:lyrics-align-progress', payload); } catch { /* renderer may have closed */ }
  };
  sendProgress(1, 'Starting the local lyric aligner…');
  const lyrics = String(input?.lyrics || '').slice(0, 120000);
  if (!lyrics.trim()) throw new Error('Paste or fetch lyrics first. Echo aligns text you already have; it does not generate missing song lyrics.');

  const audioData = input?.audioData;
  let audioBuffer;
  if (Buffer.isBuffer(audioData)) audioBuffer = audioData;
  else if (audioData instanceof ArrayBuffer) audioBuffer = Buffer.from(audioData);
  else if (ArrayBuffer.isView(audioData)) audioBuffer = Buffer.from(audioData.buffer, audioData.byteOffset, audioData.byteLength);
  else throw new Error('The imported audio data could not be read. Re-import this song and try again.');
  if (!audioBuffer.length) throw new Error('The selected song has no readable audio data.');
  if (audioBuffer.length > 120 * 1024 * 1024) throw new Error('This audio file is over 120 MB. Try a smaller or compressed copy for local alignment.');

  const extension = path.extname(String(input?.fileName || 'song.mp3')).toLowerCase();
  const allowedExtensions = new Set(['.mp3', '.m4a', '.wav', '.flac', '.ogg', '.opus', '.aac', '.wma']);
  const safeExtension = allowedExtensions.has(extension) ? extension : '.mp3';
  const language = String(input?.language || 'auto').toLowerCase();
  const allowedLanguages = new Set(['auto', 'en', 'hi', 'ur', 'pa']);
  if (!allowedLanguages.has(language)) throw new Error('Choose Auto, English, Hindi, Urdu or Punjabi for lyric alignment.');
  const model = String(input?.model || 'tiny').toLowerCase();
  if (!['tiny', 'base'].includes(model)) throw new Error('Choose the Fast (Tiny) or Balanced (Base) local alignment model.');

  const runnerPath = path.join(ROOT, 'echo_lyric_align_runner.py');
  if (!fs.existsSync(runnerPath)) throw new Error('The local lyric alignment helper is missing. Re-extract the latest Echo source ZIP and try again.');
  sendProgress(4, 'Checking Echo’s private Python alignment environment…');
  // Windows always uses the project-local virtual environment created by the
  // installer. This prevents `py` and `pip --user` from targeting different
  // Python installations. The same executable is used for the import check
  // and the actual alignment process.
  const localPython = process.platform === 'win32'
    ? path.join(ROOT, '.echo-lyric-venv', 'Scripts', 'python.exe')
    : 'python3';
  if (process.platform === 'win32' && !fs.existsSync(localPython)) {
    throw new Error('Echo’s local lyric-alignment environment is not installed. Close Echo and run Install-Echo-Lyric-Aligner.bat from the Echo folder. The installer creates a private .echo-lyric-venv folder and verifies faster-whisper before it finishes.');
  }
  const pythonCommand = localPython;
  const pythonCheck = spawnSync(pythonCommand, ['-c', 'import sys; import faster_whisper; import lyric_align; print(sys.version.split()[0])'], {
    encoding: 'utf8', windowsHide: true, timeout: 30000
  });
  if (pythonCheck.error || pythonCheck.status !== 0) {
    const detail = String(pythonCheck.stderr || pythonCheck.error?.message || '').trim().slice(-700);
    throw new Error(`Echo could not import the lyric-alignment packages from its configured Python environment. Close Echo, run Install-Echo-Lyric-Aligner.bat, and reopen Echo.${detail ? ` Details: ${detail}` : ''}`);
  }

  sendProgress(7, 'Preparing a temporary local copy of the selected song…');
  const tempDir = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'echo-lyric-align-'));
  const audioPath = path.join(tempDir, `audio${safeExtension}`);
  const lyricsPath = path.join(tempDir, 'known-lyrics.txt');
  const outputPath = path.join(tempDir, 'aligned.lrc');
  try {
    await Promise.all([
      fs.promises.writeFile(audioPath, audioBuffer),
      fs.promises.writeFile(lyricsPath, lyrics, 'utf8')
    ]);
    const args = [runnerPath, '--audio', audioPath, '--lyrics', lyricsPath, '--output', outputPath, '--language', language, '--model', model];
    sendProgress(10, 'Launching the local Whisper engine… The first run may download the selected model.');
    const result = await new Promise((resolve, reject) => {
      const child = spawn(pythonCommand, args, { cwd: tempDir, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
      let stdout = '';
      let stderr = '';
      let stdoutPending = '';
      let settled = false;
      const timer = setTimeout(() => {
        child.kill();
        if (!settled) { settled = true; reject(new Error('Local lyric alignment took too long and was stopped. Try the Tiny model, a shorter song, or a faster computer.')); }
      }, 30 * 60 * 1000);
      const append = (current, chunk) => (current + chunk.toString()).slice(-16000);
      const parseProgressLine = line => {
        const prefix = 'ECHO_ALIGNMENT_PROGRESS:';
        if (!line.startsWith(prefix)) return;
        try {
          const update = JSON.parse(line.slice(prefix.length));
          sendProgress(update.percent, update.message || 'Aligning lyrics…', 'working');
        } catch { /* ignore malformed progress messages */ }
      };
      child.stdout.on('data', chunk => {
        const text = chunk.toString();
        stdout = append(stdout, chunk);
        stdoutPending += text;
        const lines = stdoutPending.split(/\r?\n/);
        stdoutPending = lines.pop() || '';
        lines.forEach(parseProgressLine);
      });
      child.stderr.on('data', chunk => { stderr = append(stderr, chunk); });
      child.once('error', error => {
        clearTimeout(timer);
        if (!settled) { settled = true; reject(new Error(`Could not start Python: ${error.message}. Run Install-Echo-Lyric-Aligner.bat and reopen Echo.`)); }
      });
      child.once('close', code => {
        clearTimeout(timer);
        if (stdoutPending) parseProgressLine(stdoutPending);
        if (settled) return;
        settled = true;
        if (code !== 0) reject(new Error((stderr || stdout || `The local aligner exited with code ${code}.`).trim().slice(-2400)));
        else resolve({ stdout, stderr });
      });
    });
    sendProgress(97, 'The audio analysis is finished. Preparing the timestamp preview…');
    const lrc = await fs.promises.readFile(outputPath, 'utf8').catch(() => '');
    const resultLine = result.stdout.split(/\r?\n/).find(line => line.startsWith('ECHO_ALIGNMENT_RESULT:'));
    let alignmentStats = {};
    if (resultLine) {
      try { alignmentStats = JSON.parse(resultLine.slice('ECHO_ALIGNMENT_RESULT:'.length)); } catch { /* fallback to LRC counting */ }
    }
    const timedLines = lrc.split(/\r?\n/).filter(line => /^\s*\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?\]/.test(line)).length;
    const totalLines = Number(alignmentStats.totalLines) || lyrics.split(/\r?\n/).filter(line => {
      const value = line.replace(/\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?\]/g, '').trim();
      return value && !/^\[(?:verse|chorus|bridge|hook|intro|outro|pre.?chorus)(?:\s+\d+)?\]$/i.test(value);
    }).length;
    const matchedLines = Number(alignmentStats.matchedLines) || timedLines;
    if (!lrc.trim() || !timedLines) {
      const log = `${result.stderr}\n${result.stdout}`.trim();
      throw new Error(log.includes('0/') ? 'The aligner could not confidently match the supplied lyrics to this recording. Try Base instead of Tiny, choose the correct language, or use another lyric version.' : 'The aligner did not produce confident timestamps. Try a different language or a clearer lyric version.');
    }
    const finalMatchedLines = Math.min(matchedLines, totalLines);
    sendProgress(100, `Alignment preview ready: ${finalMatchedLines} of ${totalLines} lines matched.`, 'complete');
    return { lrc, matchedLines: finalMatchedLines, totalLines, model, languageDetected: alignmentStats.languageDetected || null, log: `${result.stderr}\n${result.stdout}`.trim().slice(-3000) };
  } catch (error) {
    sendProgress(0, error.message || 'Local lyric alignment failed.', 'error');
    throw error;
  } finally {
    await fs.promises.rm(tempDir, { recursive: true, force: true }).catch(() => {});
  }
});

const singleInstance = app.requestSingleInstanceLock();
if (!singleInstance) {
  app.quit();
} else {
  app.on('second-instance', () => {
    const window = BrowserWindow.getAllWindows()[0];
    if (window) {
      if (window.isMinimized()) window.restore();
      window.focus();
    }
  });
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return ({
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.ico': 'image/x-icon'
  })[ext] || 'application/octet-stream';
}

function startLocalServer() {
  return new Promise((resolve, reject) => {
    localServer = http.createServer((request, response) => {
      if (request.method !== 'GET' && request.method !== 'HEAD') {
        response.writeHead(405, { Allow: 'GET, HEAD' }).end('Method not allowed');
        return;
      }

      let pathname;
      try {
        pathname = decodeURIComponent(new URL(request.url, LOCAL_ORIGIN).pathname);
      } catch {
        response.writeHead(400).end('Bad request');
        return;
      }

      const relativePath = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
      const filePath = path.resolve(ROOT, relativePath);
      if (!filePath.startsWith(`${ROOT}${path.sep}`) || !fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
        response.writeHead(404, { 'Cache-Control': 'no-store' }).end('Not found');
        return;
      }

      response.writeHead(200, {
        'Content-Type': contentType(filePath),
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
        'Content-Security-Policy': [
          "default-src 'self' blob: data:",
          "img-src 'self' blob: data:",
          "media-src 'self' blob:",
          "style-src 'self' 'unsafe-inline'",
          "script-src 'self'",
          "connect-src 'self'",
          "frame-src 'none'",
          "font-src 'self' data:",
          "object-src 'none'",
          "base-uri 'none'",
          "frame-ancestors 'none'"
        ].join('; ')
      });

      if (request.method === 'HEAD') {
        response.end();
        return;
      }
      fs.createReadStream(filePath).pipe(response);
    });

    localServer.once('error', error => {
      if (error.code === 'EADDRINUSE') {
        reject(new Error(`Echo's local storage address (port ${APP_PORT}) is already in use. Close any other Echo Desktop instance and try again.`));
      } else reject(error);
    });
    localServer.listen(APP_PORT, '127.0.0.1', () => resolve(LOCAL_ORIGIN));
  });
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1040,
    minHeight: 680,
    backgroundColor: '#09090d',
    title: 'Echo Desktop',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => {
    try {
      const parsed = new URL(url);
      if (parsed.protocol === 'https:') shell.openExternal(parsed.href);
    } catch { /* reject invalid external destinations */ }
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    // Keep the application window on its own local UI origin.
    if (!url.startsWith(`${LOCAL_ORIGIN}/`)) event.preventDefault();
  });
  win.loadURL(`${LOCAL_ORIGIN}/index.html`);
}

if (singleInstance) {
  app.whenReady().then(async () => {
    try {
      await startLocalServer();
      createWindow();
      app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
      });
    } catch (error) {
      dialog.showErrorBox('Echo Desktop could not start', error.message || String(error));
      app.quit();
    }
  });

  app.on('before-quit', () => {
    if (localServer) localServer.close();
  });

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });
}
