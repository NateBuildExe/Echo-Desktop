const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('echoDesktop', Object.freeze({
  platform: process.platform,
  version: '1.10.0',
  mode: 'offline-local-library-with-online-metadata-and-lyrics',
  fetchMetadata: input => ipcRenderer.invoke('echo:metadata-search', input),
  fetchMetadataArtwork: reference => ipcRenderer.invoke('echo:metadata-artwork', reference),
  fetchLyrics: input => ipcRenderer.invoke('echo:lyrics-search', input),
  alignLyrics: input => ipcRenderer.invoke('echo:lyrics-align', input),
  onAlignmentProgress: callback => {
    if (typeof callback !== 'function') return () => {};
    const listener = (_event, progress) => callback(progress);
    ipcRenderer.on('echo:lyrics-align-progress', listener);
    return () => ipcRenderer.removeListener('echo:lyrics-align-progress', listener);
  }
}));
